import os
from dotenv import load_dotenv

load_dotenv()

RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost/")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./messages.db")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "admin123")
POI_BACKEND_URL = os.getenv("POI_BACKEND_URL", "http://10.197.211.192:8080")