import uuid
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import databases
import httpx
from config import DATABASE_URL, POI_BACKEND_URL

database = databases.Database(DATABASE_URL)

# ==================== 辅助函数 ====================
def _convert_created_at(row: dict) -> dict:
    """
    将消息中的 created_at 字段从 UTC 时间转换为北京时间（UTC+8）。
    如果字段不存在或为空，直接返回原字典。
    """
    if "created_at" in row and row["created_at"]:
        # 判断 created_at 的类型（可能是字符串或 datetime 对象）
        if isinstance(row["created_at"], str):
            # 如果是字符串，解析为 datetime 对象
            # 注意：SQLite 返回的格式通常是 "YYYY-MM-DD HH:MM:SS"
            try:
                utc_time = datetime.strptime(row["created_at"], "%Y-%m-%d %H:%M:%S")
                local_time = utc_time + timedelta(hours=8)
                row["created_at"] = local_time.strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                # 如果格式不匹配，不做转换
                pass
        elif isinstance(row["created_at"], datetime):
            # 如果已经是 datetime 对象，直接加 8 小时
            row["created_at"] = row["created_at"] + timedelta(hours=8)
    return row

# ==================== 消息 CRUD ====================
async def insert_message(
    msg_type: str,
    from_user_id: str,          # 发送者 ID（字符串，支持 UUID）
    to_id: str,                 # 接收者 ID（字符串，支持 UUID 或群组 ID 字符串）
    to_type: str,               # 'user' 或 'group'
    content: str,
    content_type: str = "text",
    poi_id: Optional[int] = None,
    extra: Optional[dict] = None,
) -> str:
    """插入一条消息，返回 msg_uuid"""
    msg_uuid = str(uuid.uuid4())
    extra_json = json.dumps(extra) if extra else None
    query = """
        INSERT INTO messages (msg_uuid, msg_type, from_user_id, to_id, to_type, content_type, content, poi_id, extra)
        VALUES (:msg_uuid, :msg_type, :from_user_id, :to_id, :to_type, :content_type, :content, :poi_id, :extra)
    """
    values = {
        "msg_uuid": msg_uuid,
        "msg_type": msg_type,
        "from_user_id": from_user_id,
        "to_id": to_id,
        "to_type": to_type,
        "content_type": content_type,
        "content": content,
        "poi_id": poi_id,
        "extra": extra_json,
    }
    await database.execute(query, values)
    return msg_uuid

async def get_unread_messages(user_id: str) -> List[Dict]:
    """获取指定用户的未读消息（to_type='user', is_read=0），并按时间正序返回"""
    query = """
        SELECT * FROM messages
        WHERE to_type = 'user' AND to_id = :user_id AND is_read = 0
        ORDER BY created_at ASC
    """
    rows = await database.fetch_all(query, values={"user_id": user_id})
    # 将每条消息的 created_at 从 UTC 转为北京时间
    return [_convert_created_at(dict(row)) for row in rows]

async def mark_messages_read(msg_uuids: List[str]):
    """将一批消息标记为已读"""
    if not msg_uuids:
        return
    for uid in msg_uuids:
        query = "UPDATE messages SET is_read = 1 WHERE msg_uuid = :uuid"
        await database.execute(query, values={"uuid": uid})

async def get_private_history(user1: str, user2: str, limit: int = 50, offset: int = 0) -> List[Dict]:
    """获取两人之间的私聊历史记录，按时间倒序（最新的在前）"""
    query = """
        SELECT * FROM messages
        WHERE msg_type = 'private' AND (
            (from_user_id = :user1 AND to_id = :user2) OR
            (from_user_id = :user2 AND to_id = :user1)
        )
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    """
    rows = await database.fetch_all(query, values={"user1": user1, "user2": user2, "limit": limit, "offset": offset})
    return [_convert_created_at(dict(row)) for row in rows]

async def get_group_history(group_id: int, limit: int = 50, offset: int = 0) -> List[Dict]:
    """获取某个群组的聊天历史，按时间倒序（最新的在前）"""
    query = """
        SELECT * FROM messages
        WHERE msg_type = 'group' AND to_id = :group_id
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    """
    rows = await database.fetch_all(query, values={"group_id": group_id, "limit": limit, "offset": offset})
    return [_convert_created_at(dict(row)) for row in rows]

async def get_system_notifications(user_id: str, limit: int = 50, offset: int = 0) -> List[Dict]:
    """获取指定用户的系统通知历史，按时间倒序（最新的在前）"""
    query = """
        SELECT * FROM messages
        WHERE msg_type = 'system' AND to_id = :user_id
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    """
    rows = await database.fetch_all(query, values={"user_id": user_id, "limit": limit, "offset": offset})
    return [_convert_created_at(dict(row)) for row in rows]

# ==================== 群组管理 ====================
async def add_group_member(group_id: int, user_id: str):
    """将用户加入群组（如果已存在则忽略）"""
    await database.execute(
        "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (:gid, :uid)",
        {"gid": group_id, "uid": user_id}
    )

async def get_group_members(group_id: int) -> List[str]:
    """获取群组的所有成员 ID 列表"""
    rows = await database.fetch_all(
        "SELECT user_id FROM group_members WHERE group_id = :gid",
        {"gid": group_id}
    )
    return [row["user_id"] for row in rows]

# ==================== 角色与用户同步 ====================
async def get_user_ids_by_role(role: str) -> List[str]:
    """根据角色返回用户 ID 列表"""
    if role == 'collector':
        group_id = 1
    elif role == 'verifier':
        group_id = 2
    elif role == 'all':
        rows = await database.fetch_all("SELECT DISTINCT user_id FROM group_members")
        return [row["user_id"] for row in rows]
    else:
        raise ValueError("无效角色")
    rows = await database.fetch_all(
        "SELECT user_id FROM group_members WHERE group_id = :gid",
        {"gid": group_id}
    )
    return [row["user_id"] for row in rows]

async def sync_users_from_poi():
    """
    从 POI 后端获取所有用户，根据角色填充 group_members 表。
    此函数会先清空 group_members，然后重新插入。
    """
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{POI_BACKEND_URL}/api/users/ids")
            if resp.status_code != 200:
                print(f"同步用户失败: HTTP {resp.status_code}")
                return False
            data = resp.json()
            if not data.get("success"):
                print("POI 返回失败状态")
                return False
            users = data.get("data", [])
            if not users:
                print("没有用户数据")
                return False

            # 清空旧数据
            await database.execute("DELETE FROM group_members")

            # 按角色分类
            collector_ids = [u["id"] for u in users if u.get("role") == "collector"]
            verifier_ids = [u["id"] for u in users if u.get("role") == "verifier"]
            admin_ids = [u["id"] for u in users if u.get("role") == "admin"]

            # 插入采集者（群组1）
            for uid in collector_ids:
                await database.execute(
                    "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (1, :uid)",
                    {"uid": uid}
                )
            # 插入核验者（群组2）
            for uid in verifier_ids:
                await database.execute(
                    "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (2, :uid)",
                    {"uid": uid}
                )
            # 管理员同时加入两个群组
            for uid in admin_ids:
                await database.execute(
                    "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (1, :uid)",
                    {"uid": uid}
                )
                await database.execute(
                    "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (2, :uid)",
                    {"uid": uid}
                )

            print(f"同步用户成功: 采集者 {len(collector_ids)} 人, 核验者 {len(verifier_ids)} 人, 管理员 {len(admin_ids)} 人")
            return True
    except Exception as e:
        print(f"同步用户异常: {e}")
        return False