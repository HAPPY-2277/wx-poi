# test_ws.py
import asyncio
import websockets

async def test():
    uri = "ws://127.0.0.1:8000/ws/456"
    async with websockets.connect(uri) as ws:
        print("连接成功，等待消息...")
        msg = await ws.recv()
        print("收到消息:", msg)

asyncio.run(test())