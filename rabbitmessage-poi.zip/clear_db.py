import sqlite3

DB_PATH = "./messages.db"

def clear_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    # 需要清空的表
    tables = ["messages", "group_members", "groups", "disputes"]
    for table in tables:
        cursor.execute(f"DELETE FROM {table}")
        print(f"已清空表 {table}")
    # 可选：重置自增序列
    cursor.execute("DELETE FROM sqlite_sequence")
    conn.commit()
    conn.close()
    print("数据库清空完成，表结构保留。")

if __name__ == "__main__":
    clear_database()