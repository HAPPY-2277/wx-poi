import asyncio
import json
import aio_pika
from websocket_manager import manager

async def consume_notifications():
    # 注意：连接地址填写 localhost 即可（因为消费者和 RabbitMQ 在同一台电脑）
    connection = await aio_pika.connect_robust("amqp://guest:guest@localhost:5672/")
    async with connection:
        channel = await connection.channel()
        # 声明队列（持久化）
        queue = await channel.declare_queue("poi_notifications", durable=True)
        # 限制预取数量
        await channel.set_qos(prefetch_count=1)
        print("RabbitMQ 消费者已启动，等待消息...")
        async with queue.iterator() as q_iter:
            async for message in q_iter:
                async with message.process():
                    try:
                        data = json.loads(message.body.decode())
                        target_user = data.get("target_user_id")
                        content = data.get("content")
                        if target_user and content:
                            await manager.send_to_user(target_user, content)
                    except Exception as e:
                        print(f"处理消息出错: {e}")