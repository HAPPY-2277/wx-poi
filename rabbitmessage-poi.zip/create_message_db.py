import sqlite3
import os

DB_PATH = "./messages.db"

def create_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # 1. 消息表（包含 created_at 时间戳）
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            msg_uuid       VARCHAR(36) NOT NULL UNIQUE,
            msg_type       VARCHAR(20) NOT NULL,
            from_user_id   INTEGER NOT NULL,
            to_id          INTEGER NOT NULL,
            to_type        VARCHAR(10) NOT NULL,
            content_type   VARCHAR(20) DEFAULT 'text',
            content        TEXT NOT NULL,
            poi_id         INTEGER,
            extra          TEXT,
            is_read        BOOLEAN DEFAULT 0,
            created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 索引
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_type, to_id, created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_unread ON messages(to_type, to_id, is_read)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_uuid ON messages(msg_uuid)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_user_sent ON messages(from_user_id, created_at)")

    # 2. 群组表
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS groups (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name   VARCHAR(50) NOT NULL,
            group_type   VARCHAR(20) NOT NULL,
            owner_id     INTEGER,
            created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 插入默认群组（如果不存在）
    cursor.execute("INSERT OR IGNORE INTO groups (id, group_name, group_type) VALUES (1, '采集者交流群', 'collector')")
    cursor.execute("INSERT OR IGNORE INTO groups (id, group_name, group_type) VALUES (2, '核验者交流群', 'verifier')")

    # 3. 群组成员表
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS group_members (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id     INTEGER NOT NULL,
            user_id      INTEGER NOT NULL,
            joined_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(group_id, user_id)
        )
    """)

    # 4. 争议表
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS disputes (
            id                 INTEGER PRIMARY KEY AUTOINCREMENT,
            dispute_uuid       VARCHAR(36) NOT NULL UNIQUE,
            poi_id             INTEGER NOT NULL,
            collector_id       INTEGER NOT NULL,
            verifier_id        INTEGER NOT NULL,
            reason             TEXT NOT NULL,
            status             VARCHAR(20) DEFAULT 'pending',
            third_party_id     INTEGER,
            third_party_result TEXT,
            created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resolved_at        TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()
    print(f"数据库已创建：{os.path.abspath(DB_PATH)}")

if __name__ == "__main__":
    create_database()