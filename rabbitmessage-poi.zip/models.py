from pydantic import BaseModel
from typing import Optional, List,Union

class SendMessageRequest(BaseModel):
    msg_type: str          # private / group / system
    from_user_id: Union[int, str]
    to_id: Union[str,int]             # 用户ID 或 群组ID
    to_type: str           # user / group
    content: str
    content_type: str = "text"
    poi_id: Optional[int] = None
    extra: Optional[dict] = None

class MarkReadRequest(BaseModel):
    msg_uuids: List[str]

class SystemNotifyRequest(BaseModel):
    target_role: str   # 'all', 'collector', 'verifier'
    title: str = "系统通知"
    content: str