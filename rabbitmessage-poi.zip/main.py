# 标准库导入
# 1. 导入部分（添加 APIRouter）
import asyncio
import json
from contextlib import asynccontextmanager
from typing import List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import database
import ocr
from config import ADMIN_TOKEN
from models import SendMessageRequest, MarkReadRequest, SystemNotifyRequest
from rabbit_consumer import consume_notifications
from websocket_manager import manager

# 2. 定义 periodic_sync 必须在 lifespan 之前
async def periodic_sync():
    while True:
        try:
            await asyncio.sleep(5)
            print("执行定时同步...")
            await database.sync_users_from_poi()
        except Exception as e:
            print(f"定时同步异常: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await database.database.connect()
    # 启动时同步用户（可选，也可以定时同步）
    asyncio.create_task(database.sync_users_from_poi())
    asyncio.create_task(consume_notifications())
    # 在 lifespan 中启动：
    asyncio.create_task(periodic_sync())
    yield
    await database.database.disconnect()

app = FastAPI(lifespan=lifespan)

# 文字识别
router = APIRouter(prefix="/api/ocr", tags=["OCR"])
class OcrRequest(BaseModel):
    image_data: str

class OcrResponse(BaseModel):
    success: bool
    words: List[str] = []
    message: str = ""

@router.post("/recognize", response_model=OcrResponse)
async def recognize_poi_text(req: OcrRequest):
    if not req.image_data:
        raise HTTPException(status_code=400, detail="缺少 image_data")
    words = ocr.recognize_text_from_base64(req.image_data)
    if words:
        return OcrResponse(success=True, words=words, message="识别成功")
    return OcrResponse(success=False, words=[], message="未识别到文字或识别失败")

# 6. 挂载 OCR 路由
app.include_router(router)

# WebSocket 端点
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    await manager.connect(user_id, websocket)
    try:
        while True:
            # 保持连接，接收客户端消息（可选）
            data = await websocket.receive_text()
            # 可以处理客户端发来的 ping 或其他指令
            # 例如 ping 回复 pong
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(user_id)

# HTTP API：发送消息
@app.post("/api/messages/send")
async def send_message(req: SendMessageRequest):
    # 存储到数据库
    from_user_id_str = str(req.from_user_id)
    to_id_str = str(req.to_id)
    msg_uuid = await database.insert_message(
        msg_type=req.msg_type,
        from_user_id=from_user_id_str,
        to_id=to_id_str,
        to_type=req.to_type,
        content=req.content,
        content_type=req.content_type,
        poi_id=req.poi_id,
        extra=req.extra,
    )

    # 实时推送
    if req.msg_type == "private" and req.to_type == "user":
        await manager.send_to_user(req.to_id, f"{req.from_user_id}说: {req.content}")
    elif req.msg_type == "group" and req.to_type == "group":
        members = await database.get_group_members(req.to_id)
        for member_id in members:
            if member_id != req.from_user_id:
                await manager.send_to_user(member_id, f"[群聊] {req.from_user_id}: {req.content}")
    return {"code": 0, "msg_uuid": msg_uuid}
# HTTP API：获取未读消息
@app.get("/api/messages/unread/{user_id}")
async def unread_messages(user_id: str):
    msgs = await database.get_unread_messages(user_id)
    return {"code": 0, "data": msgs}

# HTTP API：标记已读
@app.post("/api/messages/read")
async def mark_read(req: MarkReadRequest):
    await database.mark_messages_read(req.msg_uuids)
    return {"code": 0}

# HTTP API：私聊历史
@app.get("/api/messages/history/private")
async def private_history(user1: str, user2: str, limit: int = 50, offset: int = 0):
    msgs = await database.get_private_history(user1, user2, limit, offset)
    return {"code": 0, "data": msgs}
# 访问 https://www.jetbrains.com/help/pycharm/ 获取 PyCharm 帮助

@app.get("/api/messages/history/group")
async def group_history(group_id: int, limit: int = 50, offset: int = 0):
    msgs = await database.get_group_history(group_id, limit, offset)
    return {"code": 0, "data": msgs}


@app.post("/api/admin/notify")
async def system_notify(
        req: SystemNotifyRequest,
        x_admin_token: str = Header(..., alias="X-Admin-Token")
):
    # 验证管理员身份
    if x_admin_token != ADMIN_TOKEN:
        raise HTTPException(status_code=403, detail="无效令牌")

    # 获取目标用户列表
    try:
        user_ids = await database.get_user_ids_by_role(req.target_role)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if not user_ids:
        return {"code": 0, "message": "没有目标用户", "data": None}

    full_content = f"{req.title}: {req.content}"
    count = 0
    for uid in user_ids:
        # 插入消息（系统发送，from_user_id=0）
        await database.insert_message(
            msg_type="system",
            from_user_id=0,
            to_id=uid,
            to_type="user",
            content=full_content,
            content_type="text"
        )
        # 实时推送（如果用户在线）
        await manager.send_to_user(uid, f"系统通知: {full_content}")
        count += 1

    return {"code": 0, "message": f"已发送给 {count} 个用户"}

from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/admin/sync_users")
async def manual_sync(x_admin_token: str = Header(..., alias="X-Admin-Token")):
    if x_admin_token != ADMIN_TOKEN:
        raise HTTPException(status_code=403, detail="无效令牌")
    success = await database.sync_users_from_poi()
    if success:
        return {"code": 0, "message": "用户同步成功"}
    else:
        raise HTTPException(status_code=500, detail="同步失败，请查看日志")

async def periodic_sync():
    while True:
        await asyncio.sleep(3600)  # 3600秒 = 1小时
        await database.sync_users_from_poi()


@app.get("/api/messages/system/{user_id}")
async def get_system_notifications(user_id: str, limit: int = 50, offset: int = 0):
    """
    拉取系统通知历史记录（分页）
    """
    msgs = await database.get_system_notifications(user_id, limit, offset)
    return {"code": 0, "data": msgs}

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    return JSONResponse(
        status_code=422,
        content={"detail": exc.errors(), "body": exc.body}
    )

from fastapi import Request

@app.middleware("http")
async def log_request_body(request: Request, call_next):
    if request.method == "POST" and "/api/messages/send" in request.url.path:
        body = await request.body()
        print("请求体原始内容:", body)
    response = await call_next(request)
    return response