import base64
import requests
import json

# 1. 读取本地图片并转为 base64
image_path = "test.jpg"   # 替换为你的图片路径
with open(image_path, "rb") as f:
    image_base64 = base64.b64encode(f.read()).decode("utf-8")

# 2. 调用自己的 OCR 接口
url = "http://localhost:8000/api/ocr/recognize"
payload = {"image_data": image_base64}
headers = {"Content-Type": "application/json"}

response = requests.post(url, json=payload, headers=headers)
print("状态码:", response.status_code)
print("响应内容:", json.dumps(response.json(), indent=2, ensure_ascii=False))