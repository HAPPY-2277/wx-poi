import os
import base64
from aip import AipOcr
from dotenv import load_dotenv

load_dotenv()

APP_ID = os.getenv("BAIDU_APP_ID")
API_KEY = os.getenv("BAIDU_API_KEY")
SECRET_KEY = os.getenv("BAIDU_SECRET_KEY")

def get_ocr_client():
    if not all([APP_ID, API_KEY, SECRET_KEY]):
        raise ValueError("请在 .env 文件中配置完整的百度 OCR 密钥")
    return AipOcr(APP_ID, API_KEY, SECRET_KEY)

def recognize_text_from_base64(image_base64: str) -> list:
    try:
        image_bytes = base64.b64decode(image_base64)
    except Exception as e:
        print(f"Base64 解码失败: {e}")
        return []
    client = get_ocr_client()
    result = client.basicGeneral(image_bytes)
    if "error_code" in result:
        print(f"OCR 错误: {result['error_msg']} (code:{result['error_code']})")
        return []
    return [item["words"] for item in result.get("words_result", [])]