import asyncio
import httpx
import sqlite3
from config import POI_BACKEND_URL

async def fetch_users():
    """从 POI 后端获取用户列表并打印"""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{POI_BACKEND_URL}/api/users/ids")
            print(f"状态码: {resp.status_code}")
            if resp.status_code == 200:
                data = resp.json()
                print("POI 后端返回完整数据:")
                print(data)
                # 提取用户 ID 和角色
                users = data.get("data", [])
                if users:
                    print("\n用户列表:")
                    for u in users:
                        print(f"  ID: {u.get('id')}, 角色: {u.get('role')}")
                else:
                    print("没有用户数据")
            else:
                print(f"请求失败: {resp.text}")
    except Exception as e:
        print(f"请求异常: {e}")

def show_db_users():
    """查询本地 group_members 表中的用户 ID"""
    try:
        conn = sqlite3.connect("./messages.db")
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM group_members")
        rows = cursor.fetchall()
        print("\n本地数据库 group_members 中的用户 ID:")
        if rows:
            for row in rows:
                print(f"  {row[0]}")
        else:
            print("  (空)")
        conn.close()
    except Exception as e:
        print(f"数据库查询失败: {e}")

if __name__ == "__main__":
    asyncio.run(fetch_users())
    show_db_users()