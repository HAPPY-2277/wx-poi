import sqlite3

DB_PATH = "./messages.db"

def insert_test_user_ids():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    # 插入测试用的整数 user_id，group_id 1 表示采集者群，2 表示核验者群
    test_ids = [1001, 1002, 1003]
    for uid in test_ids:
        cursor.execute("INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (1, ?)", (uid,))
    conn.commit()
    print("已插入测试用户 ID:", test_ids)
    conn.close()

def print_user_ids():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        # 查询 group_members 表中所有不重复的用户 ID
        cursor.execute("SELECT DISTINCT user_id FROM group_members")
        rows = cursor.fetchall()
        if rows:
            print("=== 当前数据库中的用户 ID 列表 ===")
            for row in rows:
                print(row[0])
            print(f"共 {len(rows)} 个用户")
        else:
            print("group_members 表中暂无用户数据。")
            print("请先运行同步 API 或手动插入用户。")
        conn.close()
    except sqlite3.Error as e:
        print(f"数据库错误: {e}")

if __name__ == "__main__":
    print_user_ids()
    insert_test_user_ids()