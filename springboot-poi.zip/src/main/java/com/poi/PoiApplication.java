package com.poi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import java.net.InetAddress;
import java.net.UnknownHostException;

@SpringBootApplication
public class        PoiApplication {
    private static final Logger logger = LoggerFactory.getLogger(PoiApplication.class);

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(PoiApplication.class, args);
        Environment env = context.getEnvironment();
        
        try {
            String host = InetAddress.getLocalHost().getHostAddress();
            String port = env.getProperty("server.port", "8080");
            String environment = env.getProperty("spring.profiles.active", "default");
            
            logger.info("=============================================");
            logger.info(" 应用已启动成功");
            logger.info(" 环境: {}", environment);
            logger.info(" 端口: {}", port);
            logger.info(" 局域网访问: http://{}:{}", host, port);
            logger.info(" 本地访问: http://localhost:{}", port);
            logger.info(" 主要接口路径:");
            logger.info("   - POST /api/auth/login (登录)");
            logger.info("   - POST /api/auth/register (注册)");
            logger.info("=============================================");
        } catch (UnknownHostException e) {
            logger.error("获取本机 IP 地址失败", e);
        }
    }
}