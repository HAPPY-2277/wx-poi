package com.poi.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DataCleaner {

    private static final Logger logger = LoggerFactory.getLogger(DataCleaner.class);

    private final JdbcTemplate jdbcTemplate;

    private static final List<String> TABLES_TO_CLEAN = Arrays.asList(
            "poi_submission_image",
            "poi_image",
            "poi_submission",
            "poi_task_assignee",
            "poi_task",
            "poi",
            "users"
    );

    public DataCleaner(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void cleanAllData() {
        logger.info("========== 开始清除所有数据库表数据 ==========");
        
        try {
            jdbcTemplate.execute("SET session_replication_role = 'replica'");
            
            for (String table : TABLES_TO_CLEAN) {
                cleanTable(table);
            }
            
            jdbcTemplate.execute("SET session_replication_role = 'origin'");
            
            logger.info("========== 所有数据库表数据清除完成 ==========");
        } catch (Exception e) {
            logger.error("清除数据失败", e);
            throw e;
        }
    }

    private void cleanTable(String tableName) {
        try {
            String countSql = String.format("SELECT COUNT(*) FROM %s", tableName);
            Integer count = jdbcTemplate.queryForObject(countSql, Integer.class);
            int deletedCount = count != null ? count : 0;
            
            String truncateSql = String.format("TRUNCATE TABLE %s CASCADE", tableName);
            jdbcTemplate.execute(truncateSql);
            
            logger.info("表 {} 已清除，共删除 {} 条记录", tableName, deletedCount);
        } catch (Exception e) {
            logger.warn("清除表 {} 失败: {}", tableName, e.getMessage());
        }
    }

    public static void main(String[] args) {
        logger.info("DataCleaner 工具 - 用于清除数据库所有表数据但保留结构");
        logger.info("请通过 Spring 容器启动此工具，或使用 SQL 命令:");
        logger.info("TRUNCATE TABLE poi_submission_image, poi_image, poi_submission, poi_task_assignee, poi_task, poi, users CASCADE;");
    }
}