package com.poi.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * UUID 工具类
 * 提供 UUID 校验和转换功能
 */
public class UuidUtil {

    private static final Logger logger = LoggerFactory.getLogger(UuidUtil.class);

    /**
     * 校验字符串是否为合法 UUID
     */
    public static boolean isValidUuid(String str) {
        if (str == null || str.trim().isEmpty()) {
            return false;
        }
        try {
            UUID.fromString(str);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * 将字符串转换为 UUID
     * 如果不是合法 UUID，抛出 IllegalArgumentException
     */
    public static UUID toUuid(String str) {
        if (str == null || str.trim().isEmpty()) {
            throw new IllegalArgumentException("UUID 字符串不能为空");
        }
        try {
            return UUID.fromString(str);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("无效的 UUID 格式: " + str);
        }
    }

    /**
     * 安全转换字符串为 UUID，失败时返回 null
     */
    public static UUID toUuidOrNull(String str) {
        try {
            return toUuid(str);
        } catch (IllegalArgumentException e) {
            logger.warn("[UUID] 转换失败: {}", str);
            return null;
        }
    }

    /**
     * 校验并记录日志
     */
    public static void validateAndLog(String fieldName, String value) {
        if (!isValidUuid(value)) {
            logger.error("[UUID] {} 格式非法: {}", fieldName, value);
            throw new IllegalArgumentException(fieldName + " 格式不正确，应为 UUID 格式");
        }
        logger.info("[UUID] {} 校验通过: {}", fieldName, value);
    }
}
