package com.poi.util;

import com.poi.annotation.DbType;
import com.poi.annotation.TypeSafe;
import com.poi.exception.TypeSafeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 类型安全工具类
 * 提供统一的类型检查和转换功能
 */
public class TypeSafeUtils {
    
    private static final Logger logger = LoggerFactory.getLogger(TypeSafeUtils.class);
    
    /**
     * 对请求对象进行全面的类型安全检查
     */
    public static void validateAndConvert(Object request, String requestPath) {
        if (request == null) {
            return;
        }
        
        logger.info("[TYPE] 开始类型安全检查: {}", requestPath);
        
        Field[] fields = request.getClass().getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            
            TypeSafe typeSafe = field.getAnnotation(TypeSafe.class);
            if (typeSafe != null) {
                try {
                    validateField(field, request, typeSafe, requestPath);
                } catch (Exception e) {
                    if (e instanceof TypeSafeException) {
                        throw (TypeSafeException) e;
                    }
                    logger.error("[TYPE] 字段检查异常: {}", e.getMessage());
                    throw new TypeSafeException(
                            field.getName(),
                            "VALIDATION_ERROR",
                            null,
                            typeSafe.value().name(),
                            "字段检查失败: " + e.getMessage()
                    );
                }
            }
        }
        
        logger.info("[TYPE] 类型安全检查完成: {}", requestPath);
    }
    
    /**
     * 验证单个字段
     */
    private static void validateField(Field field, Object request, TypeSafe typeSafe, String requestPath) throws IllegalAccessException {
        Object value = field.get(request);
        String fieldName = field.getName();
        String fieldDesc = typeSafe.description().isEmpty() ? fieldName : typeSafe.description();
        
        // 检查必需字段
        if (typeSafe.required() && value == null) {
            logger.warn("[TYPE] 必需字段缺失: {} 路径: {}", fieldName, requestPath);
            throw new TypeSafeException(
                    fieldName,
                    "FIELD_REQUIRED",
                    null,
                    typeSafe.value().name(),
                    "字段 '" + fieldDesc + "' 是必需的"
            );
        }
        
        if (value == null) {
            return; // 非必需字段可以为空
        }
        
        // 根据类型进行检查和转换
        switch (typeSafe.value()) {
            case UUID:
                validateUuid(field, request, fieldName, fieldDesc, value, requestPath);
                break;
            case INTEGER:
                validateInteger(field, request, fieldName, fieldDesc, value, requestPath);
                break;
            case DOUBLE:
                validateDouble(field, request, fieldName, fieldDesc, value, requestPath);
                break;
            case BOOLEAN:
                validateBoolean(field, request, fieldName, fieldDesc, value, requestPath);
                break;
            case STRING:
                // 字符串类型不需要特殊验证
                logger.debug("[TYPE] 字符串字段验证通过: {} = {} 路径: {}", fieldName, value, requestPath);
                break;
        }
    }
    
    /**
     * 验证 UUID 字段
     */
    private static void validateUuid(Field field, Object request, String fieldName, String fieldDesc, Object value, String requestPath) throws IllegalAccessException {
        String originalValue;
        String originalType;
        
        if (value instanceof UUID) {
            // 已经是 UUID 类型，直接通过
            logger.info("[TYPE] UUID 字段已正确: {} = {} (类型: UUID) 路径: {}", fieldName, value, requestPath);
            return;
        }
        
        if (value instanceof String) {
            originalValue = (String) value;
            originalType = "String";
            
            try {
                UUID uuidValue = UUID.fromString(originalValue);
                // 如果字段类型是 String，我们不修改，Repository 层会处理转换
                // 如果字段类型是 UUID，则需要转换
                if (field.getType().equals(UUID.class)) {
                    field.set(request, uuidValue);
                    logger.info("[TYPE] UUID 转换成功: {} = {} (String -> UUID) 路径: {}", fieldName, uuidValue, requestPath);
                } else {
                    logger.info("[TYPE] UUID 格式验证通过: {} = {} (保留为 String) 路径: {}", fieldName, originalValue, requestPath);
                }
            } catch (IllegalArgumentException e) {
                logger.warn("[TYPE] UUID 格式无效: {} = '{}' 类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
                throw new TypeSafeException(
                        fieldName,
                        "INVALID_UUID",
                        originalValue,
                        "UUID",
                        "字段 '" + fieldDesc + "' 格式不正确，应为有效的 UUID 格式"
                );
            }
        } else {
            originalValue = String.valueOf(value);
            originalType = value.getClass().getSimpleName();
            logger.warn("[TYPE] UUID 字段类型不匹配: {} = '{}' 实际类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
            throw new TypeSafeException(
                    fieldName,
                    "TYPE_MISMATCH",
                    originalValue,
                    "String/UUID",
                    "字段 '" + fieldDesc + "' 类型不匹配，应为 String 或 UUID"
            );
        }
    }
    
    /**
     * 验证整数字段
     */
    private static void validateInteger(Field field, Object request, String fieldName, String fieldDesc, Object value, String requestPath) throws IllegalAccessException {
        String originalValue = String.valueOf(value);
        String originalType = value.getClass().getSimpleName();
        
        if (value instanceof Integer) {
            logger.info("[TYPE] 整数字段已正确: {} = {} (类型: Integer) 路径: {}", fieldName, value, requestPath);
            return;
        }
        
        if (value instanceof String) {
            try {
                int intValue = Integer.parseInt((String) value);
                if (field.getType().equals(Integer.class)) {
                    field.set(request, intValue);
                    logger.info("[TYPE] 整数转换成功: {} = {} (String -> Integer) 路径: {}", fieldName, intValue, requestPath);
                } else {
                    logger.info("[TYPE] 整数格式验证通过: {} = {} (保留为 String) 路径: {}", fieldName, originalValue, requestPath);
                }
            } catch (NumberFormatException e) {
                logger.warn("[TYPE] 整数格式无效: {} = '{}' 类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
                throw new TypeSafeException(
                        fieldName,
                        "INVALID_INTEGER",
                        originalValue,
                        "Integer",
                        "字段 '" + fieldDesc + "' 格式不正确，应为有效的整数值"
                );
            }
        } else if (value instanceof Number) {
            int intValue = ((Number) value).intValue();
            if (field.getType().equals(Integer.class)) {
                field.set(request, intValue);
                logger.info("[TYPE] 整数转换成功: {} = {} ({} -> Integer) 路径: {}", fieldName, intValue, originalType, requestPath);
            }
        } else {
            logger.warn("[TYPE] 整数字段类型不匹配: {} = '{}' 实际类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
            throw new TypeSafeException(
                    fieldName,
                    "TYPE_MISMATCH",
                    originalValue,
                    "Integer",
                    "字段 '" + fieldDesc + "' 类型不匹配"
            );
        }
    }
    
    /**
     * 验证双精度字段
     */
    private static void validateDouble(Field field, Object request, String fieldName, String fieldDesc, Object value, String requestPath) throws IllegalAccessException {
        String originalValue = String.valueOf(value);
        String originalType = value.getClass().getSimpleName();
        
        if (value instanceof Double) {
            logger.info("[TYPE] 双精度字段已正确: {} = {} (类型: Double) 路径: {}", fieldName, value, requestPath);
            return;
        }
        
        if (value instanceof String) {
            try {
                double doubleValue = Double.parseDouble((String) value);
                if (field.getType().equals(Double.class)) {
                    field.set(request, doubleValue);
                    logger.info("[TYPE] 双精度转换成功: {} = {} (String -> Double) 路径: {}", fieldName, doubleValue, requestPath);
                } else {
                    logger.info("[TYPE] 双精度格式验证通过: {} = {} (保留为 String) 路径: {}", fieldName, originalValue, requestPath);
                }
            } catch (NumberFormatException e) {
                logger.warn("[TYPE] 双精度格式无效: {} = '{}' 类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
                throw new TypeSafeException(
                        fieldName,
                        "INVALID_DOUBLE",
                        originalValue,
                        "Double",
                        "字段 '" + fieldDesc + "' 格式不正确，应为有效的数值"
                );
            }
        } else if (value instanceof Number) {
            double doubleValue = ((Number) value).doubleValue();
            if (field.getType().equals(Double.class)) {
                field.set(request, doubleValue);
                logger.info("[TYPE] 双精度转换成功: {} = {} ({} -> Double) 路径: {}", fieldName, doubleValue, originalType, requestPath);
            }
        } else {
            logger.warn("[TYPE] 双精度字段类型不匹配: {} = '{}' 实际类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
            throw new TypeSafeException(
                    fieldName,
                    "TYPE_MISMATCH",
                    originalValue,
                    "Double",
                    "字段 '" + fieldDesc + "' 类型不匹配"
            );
        }
    }
    
    /**
     * 验证布尔字段
     */
    private static void validateBoolean(Field field, Object request, String fieldName, String fieldDesc, Object value, String requestPath) throws IllegalAccessException {
        String originalValue = String.valueOf(value);
        String originalType = value.getClass().getSimpleName();
        
        if (value instanceof Boolean) {
            logger.info("[TYPE] 布尔字段已正确: {} = {} (类型: Boolean) 路径: {}", fieldName, value, requestPath);
            return;
        }
        
        if (value instanceof String) {
            String lowerValue = ((String) value).toLowerCase().trim();
            if ("true".equals(lowerValue) || "false".equals(lowerValue)) {
                boolean boolValue = Boolean.parseBoolean(lowerValue);
                if (field.getType().equals(Boolean.class)) {
                    field.set(request, boolValue);
                    logger.info("[TYPE] 布尔转换成功: {} = {} (String -> Boolean) 路径: {}", fieldName, boolValue, requestPath);
                } else {
                    logger.info("[TYPE] 布尔格式验证通过: {} = {} (保留为 String) 路径: {}", fieldName, originalValue, requestPath);
                }
            } else {
                logger.warn("[TYPE] 布尔格式无效: {} = '{}' 类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
                throw new TypeSafeException(
                        fieldName,
                        "INVALID_BOOLEAN",
                        originalValue,
                        "Boolean",
                        "字段 '" + fieldDesc + "' 格式不正确，应为 'true' 或 'false'"
                );
            }
        } else {
            logger.warn("[TYPE] 布尔字段类型不匹配: {} = '{}' 实际类型: {} 路径: {}", fieldName, originalValue, originalType, requestPath);
            throw new TypeSafeException(
                    fieldName,
                    "TYPE_MISMATCH",
                    originalValue,
                    "Boolean",
                    "字段 '" + fieldDesc + "' 类型不匹配"
            );
        }
    }
    
    /**
     * 验证 UUID 列表（如 assigneeIds）
     */
    public static List<String> validateUuidList(List<String> list, String fieldName, String requestPath) {
        if (list == null || list.isEmpty()) {
            return list;
        }
        
        logger.info("[TYPE] 开始验证 UUID 列表: {} 数量: {} 路径: {}", fieldName, list.size(), requestPath);
        
        List<String> invalidUuids = new ArrayList<>();
        List<String> validList = new ArrayList<>();
        
        for (int i = 0; i < list.size(); i++) {
            String uuidStr = list.get(i);
            try {
                UUID.fromString(uuidStr);
                validList.add(uuidStr);
                logger.debug("[TYPE] UUID 列表验证通过: {}[{}] = {}", fieldName, i, uuidStr);
            } catch (IllegalArgumentException e) {
                invalidUuids.add(uuidStr);
                logger.warn("[TYPE] UUID 列表验证失败: {}[{}] = {}", fieldName, i, uuidStr);
            }
        }
        
        if (!invalidUuids.isEmpty()) {
            logger.warn("[TYPE] UUID 列表包含无效值: {} 无效数量: {} 路径: {}", fieldName, invalidUuids.size(), requestPath);
            throw new TypeSafeException(
                    fieldName,
                    "INVALID_UUID_LIST",
                    invalidUuids.toString(),
                    "List<UUID>",
                    "字段 '" + fieldName + "' 包含 " + invalidUuids.size() + " 个无效的 UUID 值"
            );
        }
        
        logger.info("[TYPE] UUID 列表验证完成: {} 全部有效 路径: {}", fieldName, requestPath);
        return validList;
    }
}
