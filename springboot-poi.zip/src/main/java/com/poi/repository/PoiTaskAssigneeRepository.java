package com.poi.repository;

import com.poi.dto.PoiTaskAssignee;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

/**
 * POI 任务分配关系数据访问层
 */
@Repository
public class PoiTaskAssigneeRepository {

    private static final Logger logger = LoggerFactory.getLogger(PoiTaskAssigneeRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public PoiTaskAssigneeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<PoiTaskAssignee> findAssigneesByTaskId(String taskId) {
        logger.info("[DB] 查询任务的采集者: taskId={}", taskId);
        String sql = "SELECT id, task_id, collector_id, created_at FROM poi_task_assignee WHERE task_id = ?";
        UUID taskUuid = UUID.fromString(taskId);
        return jdbcTemplate.query(sql, new PoiTaskAssigneeRowMapper(), taskUuid);
    }

    public List<String> findTaskIdsByCollectorId(String collectorId) {
        logger.info("[DB] 查询采集者的任务ID: collectorId={}", collectorId);
        String sql = "SELECT task_id FROM poi_task_assignee WHERE collector_id = ?";
        UUID collectorUuid = UUID.fromString(collectorId);
        return jdbcTemplate.queryForList(sql, String.class, collectorUuid);
    }

    public boolean existsAssigneeInTask(String taskId, String collectorId) {
        logger.info("[DB] 检查采集者是否在任务中: taskId={}, collectorId={}", taskId, collectorId);
        String sql = "SELECT COUNT(*) FROM poi_task_assignee WHERE task_id = ? AND collector_id = ?";
        UUID taskUuid = UUID.fromString(taskId);
        UUID collectorUuid = UUID.fromString(collectorId);
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, taskUuid, collectorUuid);
        return count != null && count > 0;
    }

    public void insertTaskAssignee(String taskId, String collectorId) {
        logger.info("[DB] 插入任务分配: taskId={}, collectorId={}", taskId, collectorId);
        String sql = "INSERT INTO poi_task_assignee (task_id, collector_id) VALUES (?, ?)";
        UUID taskUuid = UUID.fromString(taskId);
        UUID collectorUuid = UUID.fromString(collectorId);
        jdbcTemplate.update(sql, taskUuid, collectorUuid);
    }

    public void batchInsertTaskAssignees(String taskId, List<String> collectorIds) {
        logger.info("[DB] 批量插入任务分配: taskId={}, count={}", taskId, collectorIds.size());
        String sql = "INSERT INTO poi_task_assignee (task_id, collector_id) VALUES (?, ?)";
        UUID taskUuid = UUID.fromString(taskId);
        List<Object[]> batchArgs = collectorIds.stream()
                .map(id -> new Object[]{taskUuid, UUID.fromString(id)})
                .toList();
        jdbcTemplate.batchUpdate(sql, batchArgs);
    }

    public int countAssigneesByTaskId(String taskId) {
        logger.info("[DB] 统计任务的采集者数量: taskId={}", taskId);
        String sql = "SELECT COUNT(*) FROM poi_task_assignee WHERE task_id = ?";
        UUID taskUuid = UUID.fromString(taskId);
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, taskUuid);
        return count != null ? count : 0;
    }

    private static class PoiTaskAssigneeRowMapper implements RowMapper<PoiTaskAssignee> {
        @Override
        public PoiTaskAssignee mapRow(ResultSet rs, int rowNum) throws SQLException {
            PoiTaskAssignee assignee = new PoiTaskAssignee();
            assignee.setId(rs.getString("id"));
            assignee.setTaskId(rs.getString("task_id"));
            assignee.setCollectorId(rs.getString("collector_id"));
            assignee.setCreatedAt(rs.getObject("created_at", ZonedDateTime.class));
            return assignee;
        }
    }
}