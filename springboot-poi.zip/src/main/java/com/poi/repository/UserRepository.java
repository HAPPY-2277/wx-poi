package com.poi.repository;

import com.poi.dto.UserResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 用户仓库
 * 处理用户相关的数据库操作
 */
@Repository
public class UserRepository {

    private static final Logger logger = LoggerFactory.getLogger(UserRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * 根据用户ID查询角色
     * @param userId 用户UUID
     * @return 用户角色字符串，如果用户不存在返回null
     */
    public String findRoleByUserId(String userId) {
        logger.info("[DB] 根据用户ID查询角色: userId={}", userId);
        String sql = "SELECT role::text FROM users WHERE id = ?";
        try {
            UUID uuid = UUID.fromString(userId);
            String role = jdbcTemplate.queryForObject(sql, String.class, uuid);
            logger.info("[DB] 查询用户角色成功: userId={}, role={}", userId, role);
            return role;
        } catch (IllegalArgumentException e) {
            logger.error("[DB] 用户ID格式非法: userId={}", userId);
            return null;
        }
    }

    /**
     * 根据用户ID检查用户是否存在
     * @param userId 用户UUID字符串
     * @return true 用户存在，false 用户不存在
     */
    public boolean existsByUserId(String userId) {
        logger.info("[DB] 检查用户是否存在: userId={}", userId);
        try {
            UUID uuid = UUID.fromString(userId);
            String sql = "SELECT COUNT(*) FROM users WHERE id = ?";
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, uuid);
            boolean exists = count != null && count > 0;
            logger.info("[DB] 用户存在: {}", exists);
            return exists;
        } catch (IllegalArgumentException e) {
            logger.error("[DB] 用户ID格式非法: userId={}", userId);
            return false;
        }
    }

    /**
     * 检查用户是否存在
     * @param openid 微信 openid
     * @return true 用户存在，false 用户不存在
     */
    public boolean existsByOpenid(String openid) {
        logger.info("[DB] 检查用户是否存在: openid={}", maskSensitiveInfo(openid));
        String sql = "SELECT COUNT(*) FROM users WHERE wechat_openid = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, openid);
        boolean exists = count != null && count > 0;
        logger.info("[DB] 用户存在: {}", exists);
        return exists;
    }

    /**
     * 根据 openid 查询用户信息（id, role, nickname）
     * @param openid 微信 openid
     * @return 用户信息 Map，包含 id、role、nickname 字段；如果用户不存在返回 null
     */
    public java.util.Map<String, Object> findUserInfoByOpenid(String openid) {
        logger.info("[DB] 根据 openid 查询用户信息: {}", maskSensitiveInfo(openid));
        String sql = "SELECT id, role, nickname FROM users WHERE wechat_openid = ?";
        java.util.List<java.util.Map<String, Object>> results = jdbcTemplate.queryForList(sql, openid);
        if (results.isEmpty()) {
            logger.info("[DB] 用户不存在");
            return null;
        }
        java.util.Map<String, Object> userInfo = results.get(0);
        logger.info("[DB] 查询成功: id={}, role={}, nickname={}", 
                userInfo.get("id"), userInfo.get("role"), userInfo.get("nickname"));
        return userInfo;
    }

    /**
     * 更新用户登录状态
     * 只更新登录相关字段：is_online、last_login_at、updated_at
     * @param openid 微信 openid
     */
    public void updateLoginStatus(String openid) {
        logger.info("[DB] 更新用户登录状态: {}", maskSensitiveInfo(openid));
        String sql = "UPDATE users SET is_online = true, last_login_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE wechat_openid = ?";
        int rows = jdbcTemplate.update(sql, openid);
        logger.info("[DB] 更新登录状态成功，影响行数: {}", rows);
    }

    /**
     * 注册新用户
     * @param openid 微信 openid
     * @param nickname 用户昵称
     * @param role 用户角色
     */
    public void registerUser(String openid, String nickname, String role) {
        logger.info("[DB] 注册新用户: openid={}, nickname={}, role={}", maskSensitiveInfo(openid), nickname, role);
        // 注意：role 字段使用 CAST(? AS user_role) 转换为 PostgreSQL 枚举类型
        String sql = "INSERT INTO users (wechat_openid, nickname, role, is_online, last_login_at) VALUES (?, ?, CAST(? AS user_role), true, CURRENT_TIMESTAMP)";
        int rows = jdbcTemplate.update(sql, openid, nickname, role);
        logger.info("[DB] 注册用户成功，影响行数: {}", rows);
    }
    
    /**
     * 脱敏敏感信息
     * @param info 敏感信息
     * @return 脱敏后的信息
     */
    private String maskSensitiveInfo(String info) {
        if (info == null || info.length() <= 6) {
            return info;
        }
        return info.substring(0, 3) + "***" + info.substring(info.length() - 3);
    }

    /**
     * 获取 JdbcTemplate（供其他服务使用）
     */
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    /**
     * 查询所有用户的完整信息
     * @return 用户列表，每个元素包含 id、nickname、role、isOnline、lastLoginAt、createdAt
     */
    public java.util.List<java.util.Map<String, Object>> findAllUsers() {
        logger.info("[DB] 开始查询所有用户完整信息");
        String sql = "SELECT id, nickname, role::text as role, is_online as isOnline, last_login_at as lastLoginAt, created_at as createdAt FROM users ORDER BY created_at ASC";
        java.util.List<java.util.Map<String, Object>> users = jdbcTemplate.queryForList(sql);
        logger.info("[DB] 查询成功，数量={}", users.size());
        return users;
    }

    /**
     * 查询所有采集者的完整信息（role=collector）
     * @return 采集者列表，每个元素包含 id、nickname、role、isOnline、lastLoginAt、createdAt
     */
    public java.util.List<java.util.Map<String, Object>> findCollectors() {
        logger.info("[DB] 开始查询 role=collector 的用户完整信息");
        String sql = "SELECT id, nickname, role::text as role, is_online as isOnline, last_login_at as lastLoginAt, created_at as createdAt FROM users WHERE role::text = 'collector' ORDER BY created_at ASC";
        java.util.List<java.util.Map<String, Object>> collectors = jdbcTemplate.queryForList(sql);
        logger.info("[DB] 查询成功，数量={}", collectors.size());
        return collectors;
    }

    /**
     * 查询所有核验者的完整信息（role=verifier）
     * @return 核验者列表，每个元素包含 id、nickname、role、isOnline、lastLoginAt、createdAt
     */
    public java.util.List<java.util.Map<String, Object>> findVerifiers() {
        logger.info("[DB] 开始查询 role=verifier 的用户完整信息");
        String sql = "SELECT id, nickname, role::text as role, is_online as isOnline, last_login_at as lastLoginAt, created_at as createdAt FROM users WHERE role::text = 'verifier' ORDER BY created_at ASC";
        java.util.List<java.util.Map<String, Object>> verifiers = jdbcTemplate.queryForList(sql);
        logger.info("[DB] 查询成功，数量={}", verifiers.size());
        return verifiers;
    }

    // ================ UserResponse DTO 版本方法（推荐使用） ================

    /**
     * UserResponse RowMapper
     */
    private static class UserResponseRowMapper implements RowMapper<UserResponse> {
        @Override
        public UserResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
            UserResponse user = new UserResponse();
            Object idObj = rs.getObject("id");
            user.setId(idObj != null ? idObj.toString() : null);
            user.setNickname(rs.getString("nickname"));
            user.setRole(rs.getString("role"));
            user.setOnline(rs.getBoolean("isOnline"));
            
            // Handle timestamp conversion safely
            java.sql.Timestamp lastLoginTs = rs.getTimestamp("lastLoginAt");
            if (lastLoginTs != null) {
                user.setLastLoginAt(lastLoginTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            java.sql.Timestamp createdAtTs = rs.getTimestamp("createdAt");
            if (createdAtTs != null) {
                user.setCreatedAt(createdAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            return user;
        }
    }

    /**
     * 查询所有用户完整信息（UserResponse 版本）
     * @return 用户列表
     */
    public List<UserResponse> findAllUsersDto() {
        logger.info("[DB] 开始查询所有用户完整信息（DTO版本）");
        String sql = "SELECT id, nickname, role::text as role, is_online as isOnline, last_login_at as lastLoginAt, created_at as createdAt FROM users ORDER BY created_at ASC";
        List<UserResponse> users = jdbcTemplate.query(sql, new UserResponseRowMapper());
        logger.info("[DB] 查询成功，数量={}", users.size());
        return users;
    }

    /**
     * 查询所有采集者完整信息（UserResponse 版本）
     * @return 采集者列表
     */
    public List<UserResponse> findCollectorsDto() {
        logger.info("[DB] 开始查询 role=collector 的用户完整信息（DTO版本）");
        String sql = "SELECT id, nickname, role::text as role, is_online as isOnline, last_login_at as lastLoginAt, created_at as createdAt FROM users WHERE role::text = 'collector' ORDER BY created_at ASC";
        List<UserResponse> collectors = jdbcTemplate.query(sql, new UserResponseRowMapper());
        logger.info("[DB] 查询成功，数量={}", collectors.size());
        return collectors;
    }

    /**
     * 查询所有核验者完整信息（UserResponse 版本）
     * @return 核验者列表
     */
    public List<UserResponse> findVerifiersDto() {
        logger.info("[DB] 开始查询 role=verifier 的用户完整信息（DTO版本）");
        String sql = "SELECT id, nickname, role::text as role, is_online as isOnline, last_login_at as lastLoginAt, created_at as createdAt FROM users WHERE role::text = 'verifier' ORDER BY created_at ASC";
        List<UserResponse> verifiers = jdbcTemplate.query(sql, new UserResponseRowMapper());
        logger.info("[DB] 查询成功，数量={}", verifiers.size());
        return verifiers;
    }
}