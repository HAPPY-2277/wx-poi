package com.poi.repository;

import com.poi.dto.PoiImageResponse;
import com.poi.dto.PoiSubmissionImageResponse;
import com.poi.util.UuidUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/**
 * POI 图片数据访问层
 */
@Repository
public class PoiImageRepository {

    private static final Logger logger = LoggerFactory.getLogger(PoiImageRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public PoiImageRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * 插入 POI 图片
     */
    public String insert(String poiId, String imageUrl, Integer sortOrder) {
        logger.info("[DB] 插入 POI 图片: poiId={}, imageUrl={}, sortOrder={}", poiId, imageUrl, sortOrder);

        String sql = "INSERT INTO poi_image (poi_id, image_url, sort_order) VALUES (?, ?, ?) RETURNING id";

        UUID poiUuid = UuidUtil.toUuid(poiId);
        String imageId = jdbcTemplate.queryForObject(sql, String.class, poiUuid, imageUrl, sortOrder);
        logger.info("[DB] POI 图片插入成功: imageId={}", imageId);
        return imageId;
    }

    /**
     * 根据 POI ID 查询图片列表
     */
    public List<PoiImageResponse> findByPoiId(String poiId) {
        logger.info("[DB] 根据 POI ID 查询图片: poiId={}", poiId);

        String sql = "SELECT id, poi_id, image_url, sort_order, created_at " +
                     "FROM poi_image WHERE poi_id = ? ORDER BY sort_order ASC, created_at ASC";

        UUID poiUuid = UuidUtil.toUuid(poiId);
        List<PoiImageResponse> images = jdbcTemplate.query(sql, new PoiImageRowMapper(), poiUuid);
        logger.info("[DB] 查询成功，数量: {}", images.size());
        return images;
    }

    /**
     * 根据图片 ID 删除
     */
    public void deleteById(String imageId) {
        logger.info("[DB] 删除 POI 图片: imageId={}", imageId);

        String sql = "DELETE FROM poi_image WHERE id = ?";
        UUID imageUuid = UuidUtil.toUuid(imageId);
        int rows = jdbcTemplate.update(sql, imageUuid);
        logger.info("[DB] 删除成功，影响行数: {}", rows);
    }

    /**
     * 根据 POI ID 删除所有图片
     */
    public void deleteByPoiId(String poiId) {
        logger.info("[DB] 根据 POI ID 删除所有图片: poiId={}", poiId);

        String sql = "DELETE FROM poi_image WHERE poi_id = ?";
        UUID poiUuid = UuidUtil.toUuid(poiId);
        int rows = jdbcTemplate.update(sql, poiUuid);
        logger.info("[DB] 删除成功，影响行数: {}", rows);
    }

    /**
     * 从提交图片复制到 POI 图片
     * @param submissionImageList 提交图片列表（包含 imageUrl 和 sortOrder）
     * @param poiId 目标 POI ID
     * @return 复制的图片数量
     */
    public int copyFromSubmissionImages(List<PoiSubmissionImageResponse> submissionImageList, String poiId) {
        logger.info("[DB] 开始复制 submission 图片到 poi: poiId={}, count={}", poiId, submissionImageList.size());

        UUID poiUuid = UuidUtil.toUuid(poiId);
        int copiedCount = 0;

        for (PoiSubmissionImageResponse subImage : submissionImageList) {
            String sql = "INSERT INTO poi_image (poi_id, image_url, sort_order) VALUES (?, ?, ?)";
            jdbcTemplate.update(sql, poiUuid, subImage.getImageUrl(), subImage.getSortOrder());
            copiedCount++;
            logger.info("[DB] 复制图片: imageUrl={}, sortOrder={}", subImage.getImageUrl(), subImage.getSortOrder());
        }

        logger.info("[DB] 图片复制完成: poiId={}, copiedCount={}", poiId, copiedCount);
        return copiedCount;
    }

    /**
     * POI 图片行映射器
     */
    private static class PoiImageRowMapper implements RowMapper<PoiImageResponse> {
        @Override
        public PoiImageResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
            PoiImageResponse response = new PoiImageResponse();
            response.setId(rs.getString("id"));
            response.setPoiId(rs.getString("poi_id"));
            response.setImageUrl(rs.getString("image_url"));
            response.setSortOrder(rs.getInt("sort_order"));

            java.sql.Timestamp createdAtTs = rs.getTimestamp("created_at");
            if (createdAtTs != null) {
                response.setCreatedAt(createdAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }

            return response;
        }
    }
}
