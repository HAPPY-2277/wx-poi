package com.poi.repository;

import com.poi.dto.PoiSubmissionImageResponse;
import com.poi.util.UuidUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/**
 * 提交图片数据访问层
 */
@Repository
public class PoiSubmissionImageRepository {

    private static final Logger logger = LoggerFactory.getLogger(PoiSubmissionImageRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public PoiSubmissionImageRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * 插入提交图片
     */
    public String insert(String submissionId, String imageUrl, Integer sortOrder) {
        logger.info("[DB] 插入提交图片: submissionId={}, imageUrl={}, sortOrder={}", submissionId, imageUrl, sortOrder);

        String sql = "INSERT INTO poi_submission_image (submission_id, image_url, sort_order) VALUES (?, ?, ?) RETURNING id";

        UUID submissionUuid = UuidUtil.toUuid(submissionId);
        String imageId = jdbcTemplate.queryForObject(sql, String.class, submissionUuid, imageUrl, sortOrder);
        logger.info("[DB] 提交图片插入成功: imageId={}", imageId);
        return imageId;
    }

    /**
     * 根据提交 ID 查询图片列表
     */
    public List<PoiSubmissionImageResponse> findBySubmissionId(String submissionId) {
        logger.info("[DB] 根据提交 ID 查询图片: submissionId={}", submissionId);

        String sql = "SELECT id, submission_id, image_url, sort_order, created_at " +
                     "FROM poi_submission_image WHERE submission_id = ? ORDER BY sort_order ASC, created_at ASC";

        UUID submissionUuid = UuidUtil.toUuid(submissionId);
        List<PoiSubmissionImageResponse> images = jdbcTemplate.query(sql, new PoiSubmissionImageRowMapper(), submissionUuid);
        logger.info("[DB] 查询成功，数量: {}", images.size());
        return images;
    }

    /**
     * 根据图片 ID 删除
     */
    public void deleteById(String imageId) {
        logger.info("[DB] 删除提交图片: imageId={}", imageId);

        String sql = "DELETE FROM poi_submission_image WHERE id = ?";
        UUID imageUuid = UuidUtil.toUuid(imageId);
        int rows = jdbcTemplate.update(sql, imageUuid);
        logger.info("[DB] 删除成功，影响行数: {}", rows);
    }

    /**
     * 根据提交 ID 删除所有图片
     */
    public void deleteBySubmissionId(String submissionId) {
        logger.info("[DB] 根据提交 ID 删除所有图片: submissionId={}", submissionId);

        String sql = "DELETE FROM poi_submission_image WHERE submission_id = ?";
        UUID submissionUuid = UuidUtil.toUuid(submissionId);
        int rows = jdbcTemplate.update(sql, submissionUuid);
        logger.info("[DB] 删除成功，影响行数: {}", rows);
    }

    /**
     * 提交图片行映射器
     */
    private static class PoiSubmissionImageRowMapper implements RowMapper<PoiSubmissionImageResponse> {
        @Override
        public PoiSubmissionImageResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
            PoiSubmissionImageResponse response = new PoiSubmissionImageResponse();
            response.setId(rs.getString("id"));
            response.setSubmissionId(rs.getString("submission_id"));
            response.setImageUrl(rs.getString("image_url"));
            response.setSortOrder(rs.getInt("sort_order"));

            java.sql.Timestamp createdAtTs = rs.getTimestamp("created_at");
            if (createdAtTs != null) {
                response.setCreatedAt(createdAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }

            return response;
        }
    }
}
