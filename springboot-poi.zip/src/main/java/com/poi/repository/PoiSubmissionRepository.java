package com.poi.repository;

import com.poi.dto.PoiSubmission;
import com.poi.util.UuidUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

/**
 * POI 提交记录数据访问层
 */
@Repository
public class PoiSubmissionRepository {

    private static final Logger logger = LoggerFactory.getLogger(PoiSubmissionRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public PoiSubmissionRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public PoiSubmission findSubmissionById(String id) {
        logger.info("[DB] 查询提交记录: id={}", id);
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                     "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                     "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        List<PoiSubmission> results = jdbcTemplate.query(sql, new PoiSubmissionRowMapper(), idUuid);
        return results.isEmpty() ? null : results.get(0);
    }

    public List<PoiSubmission> findSubmissionsByTaskId(String taskId) {
        logger.info("[DB] 查询任务下的提交记录: taskId={}", taskId);
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                     "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                     "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE task_id = ? ORDER BY created_at DESC";
        UUID taskUuid = UuidUtil.toUuid(taskId);
        return jdbcTemplate.query(sql, new PoiSubmissionRowMapper(), taskUuid);
    }

    public List<PoiSubmission> findSubmissionsByPoiId(String poiId) {
        logger.info("[DB] 查询POI下的提交记录: poiId={}", poiId);
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                     "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                     "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE poi_id = ? ORDER BY created_at DESC";
        UUID poiUuid = UuidUtil.toUuid(poiId);
        return jdbcTemplate.query(sql, new PoiSubmissionRowMapper(), poiUuid);
    }

    public List<PoiSubmission> findSubmissionsBySubmitterId(String submitterId) {
        logger.info("[DB] 查询提交者的提交记录: submitterId={}", submitterId);
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                     "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                     "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE submitter_id = ? ORDER BY created_at DESC";
        UUID submitterUuid = UuidUtil.toUuid(submitterId);
        return jdbcTemplate.query(sql, new PoiSubmissionRowMapper(), submitterUuid);
    }

    public PoiSubmission findPendingSubmissionByTaskId(String taskId) {
        logger.info("[DB] 查询任务待审核提交: taskId={}", taskId);
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                     "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                     "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE task_id = ? AND status = 'PENDING_REVIEW'";
        UUID taskUuid = UuidUtil.toUuid(taskId);
        List<PoiSubmission> results = jdbcTemplate.query(sql, new PoiSubmissionRowMapper(), taskUuid);
        return results.isEmpty() ? null : results.get(0);
    }

    public PoiSubmission findActiveSubmissionByPoiId(String poiId) {
        logger.info("[DB] 查询POI的生效版本: poiId={}", poiId);
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                     "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                     "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE poi_id = ? AND is_active = true";
        UUID poiUuid = UuidUtil.toUuid(poiId);
        List<PoiSubmission> results = jdbcTemplate.query(sql, new PoiSubmissionRowMapper(), poiUuid);
        return results.isEmpty() ? null : results.get(0);
    }

    public String insertSubmission(String poiId, String submitterId, String submissionType,
                                String name, String category, String description,
                                Double longitude, Double latitude, String address,
                                String status, Boolean isActive, String taskId) {
        logger.info("[DB] 插入提交记录: submitterId={}, taskId={}", submitterId, taskId);
        String sql = "INSERT INTO poi_submission (poi_id, submitter_id, submission_type, name, category, " +
                     "description, longitude, latitude, address, status, is_active, task_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id";
        UUID poiUuid = poiId != null ? UuidUtil.toUuid(poiId) : null;
        UUID submitterUuid = UuidUtil.toUuid(submitterId);
        UUID taskUuid = UuidUtil.toUuid(taskId);
        String submissionId = jdbcTemplate.queryForObject(sql, String.class, poiUuid, submitterUuid, 
                submissionType, name, category, description, longitude, latitude, address, status, isActive, taskUuid);
        logger.info("[DB] 提交记录插入成功，返回 submissionId={}", submissionId);
        return submissionId;
    }

    public void updateSubmissionStatus(String id, String status) {
        logger.info("[DB] 更新提交状态: id={}, status={}", id, status);
        String sql = "UPDATE poi_submission SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        jdbcTemplate.update(sql, status, idUuid);
    }

    public void updateSubmissionActive(String id, Boolean isActive) {
        logger.info("[DB] 更新提交生效状态: id={}, isActive={}", id, isActive);
        String sql = "UPDATE poi_submission SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        jdbcTemplate.update(sql, isActive, idUuid);
    }

    public void updateSubmissionReviewInfo(String id, String status, Boolean isActive,
                                          String reviewerId, String reviewComment) {
        logger.info("[DB] 更新提交审核信息: id={}, status={}", id, status);
        String sql = "UPDATE poi_submission SET status = ?, is_active = ?, reviewer_id = ?, " +
                     "review_comment = ?, reviewed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        UUID reviewerUuid = UuidUtil.toUuid(reviewerId);
        jdbcTemplate.update(sql, status, isActive, reviewerUuid, reviewComment, idUuid);
    }

    public boolean existsSubmissionById(String id) {
        String sql = "SELECT COUNT(*) FROM poi_submission WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, idUuid);
        return count != null && count > 0;
    }

    public void updateSubmissionPoiId(String id, String poiId) {
        logger.info("[DB] 回填提交的POI ID: id={}, poiId={}", id, poiId);
        String sql = "UPDATE poi_submission SET poi_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        UUID poiUuid = UuidUtil.toUuid(poiId);
        jdbcTemplate.update(sql, poiUuid, idUuid);
    }

    public List<PoiSubmission> findPendingReviewSubmissions() {
        logger.info("[DB] 查询待审核提交列表");
        String sql = "SELECT id, poi_id, submitter_id, submission_type, name, category, description, " +
                "longitude, latitude, address, status, is_active, review_comment, reviewer_id, " +
                "reviewed_at, created_at, updated_at, task_id FROM poi_submission WHERE status = 'PENDING_REVIEW' ORDER BY created_at DESC";
        return jdbcTemplate.query(sql, new PoiSubmissionRowMapper());
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    private static class PoiSubmissionRowMapper implements RowMapper<PoiSubmission> {
        @Override
        public PoiSubmission mapRow(ResultSet rs, int rowNum) throws SQLException {
            PoiSubmission submission = new PoiSubmission();
            submission.setId(rs.getString("id"));
            submission.setPoiId(rs.getString("poi_id"));
            submission.setSubmitterId(rs.getString("submitter_id"));
            submission.setSubmissionType(rs.getString("submission_type"));
            submission.setName(rs.getString("name"));
            submission.setCategory(rs.getString("category"));
            submission.setDescription(rs.getString("description"));
            submission.setLongitude(rs.getDouble("longitude"));
            submission.setLatitude(rs.getDouble("latitude"));
            submission.setAddress(rs.getString("address"));
            submission.setStatus(rs.getString("status"));
            submission.setIsActive(rs.getBoolean("is_active"));
            submission.setReviewComment(rs.getString("review_comment"));
            submission.setReviewerId(rs.getString("reviewer_id"));
            
            // Handle timestamp conversion safely
            java.sql.Timestamp reviewedAtTs = rs.getTimestamp("reviewed_at");
            if (reviewedAtTs != null) {
                submission.setReviewedAt(reviewedAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            java.sql.Timestamp createdAtTs = rs.getTimestamp("created_at");
            if (createdAtTs != null) {
                submission.setCreatedAt(createdAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            java.sql.Timestamp updatedAtTs = rs.getTimestamp("updated_at");
            if (updatedAtTs != null) {
                submission.setUpdatedAt(updatedAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            submission.setTaskId(rs.getString("task_id"));
            return submission;
        }
    }
}