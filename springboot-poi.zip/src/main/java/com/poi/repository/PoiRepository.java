package com.poi.repository;

import com.poi.dto.PoiResponse;
import com.poi.util.UuidUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

/**
 * POI 数据访问层
 * 使用 JdbcTemplate 操作数据库
 */
@Repository
public class PoiRepository {

    private static final Logger logger = LoggerFactory.getLogger(PoiRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public PoiRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * 插入新 POI 并返回 poiId
     * 注意：poi 表已删除 status 列，INSERT 不再包含 status
     */
    public String insertPoi(String name, String category, String description,
                          Double longitude, Double latitude, String address,
                          String collectorId) {
        logger.info("[DB] 插入新 POI: name={}, category={}, collectorId={}", name, category, collectorId);

        String sql = "INSERT INTO poi (name, category, description, longitude, latitude, address, collector_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?) " +
                     "RETURNING id";

        UUID collectorUuid = UuidUtil.toUuid(collectorId);
        String poiId = jdbcTemplate.queryForObject(sql, String.class, name, category, description, longitude, latitude, address, collectorUuid);
        logger.info("[DB] POI 插入成功，返回 poiId={}", poiId);
        return poiId;
    }

    /**
     * 更新 POI
     */
    public void updatePoi(String id, String name, String category, String description,
                          Double longitude, Double latitude, String address, String collectorId) {
        logger.info("[DB] 更新 POI: id={}", id);

        String sql = "UPDATE poi SET name = ?, category = ?, description = ?, longitude = ?, " +
                     "latitude = ?, address = ?, collector_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";

        UUID idUuid = UuidUtil.toUuid(id);
        UUID collectorUuid = UuidUtil.toUuid(collectorId);
        int rows = jdbcTemplate.update(sql, name, category, description, longitude,
                latitude, address, collectorUuid, idUuid);
        logger.info("[DB] POI 更新成功，影响行数: {}", rows);
    }

    /**
     * 查询所有 POI
     */
    public List<PoiResponse> findAll() {
        logger.info("[DB] 查询所有 POI");

        String sql = "SELECT id, name, category, description, longitude, latitude, address, " +
                     "collector_id, created_at, updated_at " +
                     "FROM poi ORDER BY created_at DESC";

        return jdbcTemplate.query(sql, new PoiRowMapper());
    }

    /**
     * 根据 ID 查询 POI
     */
    public PoiResponse findById(String id) {
        logger.info("[DB] 根据 ID 查询 POI: id={}", id);

        String sql = "SELECT id, name, category, description, longitude, latitude, address, " +
                     "collector_id, created_at, updated_at " +
                     "FROM poi WHERE id = ?";

        UUID idUuid = UuidUtil.toUuid(id);
        List<PoiResponse> results = jdbcTemplate.query(sql, new PoiRowMapper(), idUuid);
        return results.isEmpty() ? null : results.get(0);
    }

    /**
     * 根据 collectorId 查询 POI 列表
     */
    public List<PoiResponse> findByCollectorId(String collectorId) {
        logger.info("[DB] 根据 collectorId 查询 POI: collectorId={}", collectorId);

        String sql = "SELECT id, name, category, description, longitude, latitude, address, " +
                     "collector_id, created_at, updated_at " +
                     "FROM poi WHERE collector_id = ? ORDER BY created_at DESC";

        UUID collectorUuid = UuidUtil.toUuid(collectorId);
        return jdbcTemplate.query(sql, new PoiRowMapper(), collectorUuid);
    }

    /**
     * 获取 JdbcTemplate（供其他服务使用）
     */
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    /**
     * POI 行映射器
     * 将数据库记录映射为 POIResponse 对象
     */
    private static class PoiRowMapper implements RowMapper<PoiResponse> {
        @Override
        public PoiResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
            PoiResponse response = new PoiResponse();
            response.setId(rs.getString("id"));
            response.setName(rs.getString("name"));
            response.setCategory(rs.getString("category"));
            response.setDescription(rs.getString("description"));
            response.setLongitude(rs.getDouble("longitude"));
            response.setLatitude(rs.getDouble("latitude"));
            response.setAddress(rs.getString("address"));
            response.setCollectorId(rs.getString("collector_id"));
            
            // Handle timestamp conversion safely
            java.sql.Timestamp createdAtTs = rs.getTimestamp("created_at");
            if (createdAtTs != null) {
                response.setCreatedAt(createdAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            java.sql.Timestamp updatedAtTs = rs.getTimestamp("updated_at");
            if (updatedAtTs != null) {
                response.setUpdatedAt(updatedAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            return response;
        }
    }
}