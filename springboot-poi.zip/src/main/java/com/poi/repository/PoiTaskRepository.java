package com.poi.repository;

import com.poi.dto.PoiTask;
import com.poi.util.UuidUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

/**
 * POI 任务数据访问层
 */
@Repository
public class PoiTaskRepository {

    private static final Logger logger = LoggerFactory.getLogger(PoiTaskRepository.class);
    private final JdbcTemplate jdbcTemplate;

    public PoiTaskRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public PoiTask findTaskById(String id) {
        logger.info("[DB] 查询任务: id={}", id);
        String sql = "SELECT id, publisher_id, poi_id, description, status, assignee_count, " +
                     "created_at, updated_at, task_type, target_name, target_category, " +
                     "target_longitude, target_latitude, target_address FROM poi_task WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        List<PoiTask> results = jdbcTemplate.query(sql, new PoiTaskRowMapper(), idUuid);
        return results.isEmpty() ? null : results.get(0);
    }

    public List<PoiTask> findTasksByPublisherId(String publisherId) {
        logger.info("[DB] 查询发布者的任务: publisherId={}", publisherId);
        String sql = "SELECT id, publisher_id, poi_id, description, status, assignee_count, " +
                     "created_at, updated_at, task_type, target_name, target_category, " +
                     "target_longitude, target_latitude, target_address FROM poi_task WHERE publisher_id = ? ORDER BY created_at DESC";
        UUID publisherUuid = UuidUtil.toUuid(publisherId);
        return jdbcTemplate.query(sql, new PoiTaskRowMapper(), publisherUuid);
    }

    public List<PoiTask> findTasksByStatus(String status) {
        logger.info("[DB] 查询指定状态的任务: status={}", status);
        String sql = "SELECT id, publisher_id, poi_id, description, status, assignee_count, " +
                     "created_at, updated_at, task_type, target_name, target_category, " +
                     "target_longitude, target_latitude, target_address FROM poi_task WHERE status = ? ORDER BY created_at DESC";
        return jdbcTemplate.query(sql, new PoiTaskRowMapper(), status);
    }

    public List<PoiTask> findTasksByCollectorId(String collectorId) {
        logger.info("[DB] 查询采集者的任务开始: collectorId={}", collectorId);
        
        // 记录类型转换信息
        logger.info("[DB] 开始将 collectorId(String) 转换为 UUID");
        UUID collectorUuid = UuidUtil.toUuid(collectorId);
        logger.info("[DB] collectorId 类型转换完成: String={}, UUID={}", collectorId, collectorUuid);
        
        // 记录SQL信息
        logger.info("[DB] 准备执行SQL查询");
        String sql = "SELECT t.id, t.publisher_id, t.poi_id, t.description, t.status, t.assignee_count, " +
                     "t.created_at, t.updated_at, t.task_type, t.target_name, t.target_category, " +
                     "t.target_longitude, t.target_latitude, t.target_address " +
                     "FROM poi_task t JOIN poi_task_assignee a ON t.id = a.task_id " +
                     "WHERE a.collector_id = ? ORDER BY t.created_at DESC";
        
        // 执行查询
        logger.info("[DB] 执行SQL: JOIN poi_task 与 poi_task_assignee");
        List<PoiTask> tasks = jdbcTemplate.query(sql, new PoiTaskRowMapper(), collectorUuid);
        
        // 记录结果
        logger.info("[DB] 查询采集者的任务完成: collectorId={}, 返回任务数量={}", collectorId, tasks.size());
        return tasks;
    }

    /**
     * 插入任务并返回新创建的 taskId
     */
    public String insertTask(String publisherId, String poiId, String description, String status,
                          Integer assigneeCount, String taskType, String targetName,
                          String targetCategory, Double targetLongitude, Double targetLatitude,
                          String targetAddress) {
        logger.info("[DB] 插入任务: publisherId={}, taskType={}", publisherId, taskType);
        String sql = "INSERT INTO poi_task (publisher_id, poi_id, description, status, assignee_count, " +
                     "task_type, target_name, target_category, target_longitude, target_latitude, target_address) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                     "RETURNING id";

        UUID pubUuid = UuidUtil.toUuid(publisherId);
        UUID poiUuid = (poiId != null && !poiId.isEmpty()) ? UuidUtil.toUuid(poiId) : null;

        String taskId = jdbcTemplate.queryForObject(sql, String.class, pubUuid, poiUuid, description, status, assigneeCount,
                taskType, targetName, targetCategory, targetLongitude, targetLatitude, targetAddress);
        logger.info("[DB] 任务插入成功，返回 taskId={}", taskId);
        return taskId;
    }

    public void updateTaskStatus(String id, String status) {
        logger.info("[DB] 更新任务状态: id={}, status={}", id, status);
        String sql = "UPDATE poi_task SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        jdbcTemplate.update(sql, status, idUuid);
    }

    public void updateTaskPoiId(String id, String poiId) {
        logger.info("[DB] 更新任务的POI ID: id={}, poiId={}", id, poiId);
        String sql = "UPDATE poi_task SET poi_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        UUID poiUuid = UuidUtil.toUuid(poiId);
        jdbcTemplate.update(sql, poiUuid, idUuid);
    }

    public boolean existsTaskById(String id) {
        String sql = "SELECT COUNT(*) FROM poi_task WHERE id = ?";
        UUID idUuid = UuidUtil.toUuid(id);
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, idUuid);
        return count != null && count > 0;
    }

    private static class PoiTaskRowMapper implements RowMapper<PoiTask> {
        @Override
        public PoiTask mapRow(ResultSet rs, int rowNum) throws SQLException {
            PoiTask task = new PoiTask();
            task.setId(rs.getString("id"));
            task.setPublisherId(rs.getString("publisher_id"));
            task.setPoiId(rs.getString("poi_id"));
            task.setDescription(rs.getString("description"));
            task.setStatus(rs.getString("status"));
            task.setAssigneeCount(rs.getInt("assignee_count"));
            
            // Handle timestamp conversion safely
            java.sql.Timestamp createdAtTs = rs.getTimestamp("created_at");
            if (createdAtTs != null) {
                task.setCreatedAt(createdAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            java.sql.Timestamp updatedAtTs = rs.getTimestamp("updated_at");
            if (updatedAtTs != null) {
                task.setUpdatedAt(updatedAtTs.toInstant().atZone(java.time.ZoneId.systemDefault()));
            }
            
            task.setTaskType(rs.getString("task_type"));
            task.setTargetName(rs.getString("target_name"));
            task.setTargetCategory(rs.getString("target_category"));
            task.setTargetLongitude(rs.getDouble("target_longitude"));
            task.setTargetLatitude(rs.getDouble("target_latitude"));
            task.setTargetAddress(rs.getString("target_address"));
            return task;
        }
    }
}