package com.poi.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.poi.config.WeChatProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * 微信 API 客户端
 * 专门负责调用微信官方 jscode2session 接口获取 openid
 *
 * 重要说明：
 * 1. 为什么必须由后端调用微信 API 获取 openid？
 *    - 安全考虑：appid 和 secret 是敏感信息，不能暴露给前端
 *    - session_key 是敏感信息，不能传给前端
 *    - 防止前端伪造 openid
 *
 * 2. 为什么不返回 session_key 给前端？
 *    - session_key 用于解密用户敏感数据（如手机号）
 *    - 不返回可以避免泄露风险
 *    - 当前业务不需要使用 session_key
 *
 * 3. 为什么不能直接把微信响应按 Map.class 接收？
 *    - 微信 API 返回的 Content-Type 是 text/plain，不是 application/json
 *    - Spring 的 RestTemplate 默认无法将 text/plain 直接转换为 Map
 *    - 会导致 HttpMessageConverter 错误
 *
 * 4. 为什么要先按 String 接收再手动解析？
 *    - 避免 Content-Type 导致的转换问题
 *    - 可以打印响应详情便于调试
 *    - 可以区分网络异常和解析异常
 *
 * 5. Mock 模式说明：
 *    - 开发环境可通过 wechat.mock-login=true 开启
 *    - Mock 模式下，同一个 code 会生成同一个 mock_openid_xxx
 *    - 方便本机联调，不依赖真实微信 API
 */
@Component
public class WeChatApiClient {

    private static final Logger logger = LoggerFactory.getLogger(WeChatApiClient.class);

    /**
     * 微信 jscode2session 接口地址
     */
    private static final String JSCODE2SESSION_URL = "https://api.weixin.qq.com/sns/jscode2session";

    private final WeChatProperties weChatProperties;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public WeChatApiClient(WeChatProperties weChatProperties) {
        this.weChatProperties = weChatProperties;
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * 调用微信 jscode2session 接口获取 openid
     *
     * @param code 微信小程序 wx.login() 返回的临时 code
     * @return 用户的 openid
     * @throws RuntimeException 如果调用失败或微信返回错误
     */
    public String getOpenid(String code) {
        // 检查是否开启 Mock 模式
        if (weChatProperties.isMockLogin()) {
            return getMockOpenid(code);
        }

        logger.info("[WECHAT] 开始调用 jscode2session 获取 openid");

        // 1. 校验配置
        validateConfig();

        // 2. 校验 code
        if (code == null || code.trim().isEmpty()) {
            logger.error("[WECHAT] code 不能为空");
            throw new RuntimeException("微信登录失败：code 不能为空");
        }

        // 3. 构建请求 URL
        String url = buildRequestUrl(code);
        logger.info("[WECHAT] 发送请求到: {}", JSCODE2SESSION_URL);

        try {
            // 4. 先按 String 接收响应体，避免 Content-Type 问题
            ResponseEntity<String> responseEntity = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    HttpEntity.EMPTY,
                    String.class
            );

            // 5. 打印响应调试信息
            printResponseDebugInfo(responseEntity);

            // 6. 解析响应 JSON
            return parseResponse(responseEntity.getBody());

        } catch (HttpClientErrorException e) {
            // HTTP 4xx 错误（客户端错误，如 400、401、403 等）
            logger.error("[WECHAT] HTTP 客户端错误: 状态码={}, 响应={}", e.getStatusCode(), e.getResponseBodyAsString());
            throw new RuntimeException("微信登录失败：HTTP 客户端错误 (状态码：" + e.getStatusCode() + ")");
        } catch (HttpServerErrorException e) {
            // HTTP 5xx 错误（服务器端错误）
            logger.error("[WECHAT] HTTP 服务器错误: 状态码={}, 响应={}", e.getStatusCode(), e.getResponseBodyAsString());
            throw new RuntimeException("微信登录失败：微信服务器错误 (状态码：" + e.getStatusCode() + ")");
        } catch (Exception e) {
            logger.error("[WECHAT] 调用微信接口失败: {}", e.getMessage());
            throw new RuntimeException("微信登录失败：网络请求异常", e);
        }
    }

    /**
     * 生成 Mock openid
     * 同一个 code 必须生成同一个 openid，不允许随机生成
     *
     * @param code 前端传入的 code
     * @return mock openid，格式为 mock_openid_{code}
     */
    private String getMockOpenid(String code) {
        // 打印明显日志
        logger.warn("=================================================");
        logger.warn("[WECHAT-MOCK] 当前为 MOCK 登录模式");
        logger.warn("[WECHAT-MOCK] code={}", code);
        logger.warn("[WECHAT-MOCK] 请注意：此模式仅用于本机联调！");
        logger.warn("=================================================");

        // 校验 code
        if (code == null || code.trim().isEmpty()) {
            logger.error("[WECHAT-MOCK] code 不能为空");
            throw new RuntimeException("微信登录失败：code 不能为空");
        }

        // 生成稳定的 mock openid
        String mockOpenid = "mock_openid_" + code;
        logger.warn("[WECHAT-MOCK] mockOpenid={}", mockOpenid);
        logger.warn("=================================================");

        return mockOpenid;
    }

    /**
     * 打印响应调试信息
     */
    private void printResponseDebugInfo(ResponseEntity<String> responseEntity) {
        HttpStatusCode statusCode = responseEntity.getStatusCode();
        String contentType = responseEntity.getHeaders().getContentType() != null
                ? responseEntity.getHeaders().getContentType().toString()
                : "unknown";
        String body = responseEntity.getBody();
        String bodySummary = body != null && body.length() > 200
                ? body.substring(0, 200) + "..."
                : body;

        logger.info("[WECHAT] 响应状态码: {}", statusCode.value());
        logger.info("[WECHAT] 响应 Content-Type: {}", contentType);
        logger.info("[WECHAT] 响应体: {}", bodySummary);
    }

    /**
     * 校验微信配置是否完整
     */
    private void validateConfig() {
        // 获取 miniapp 内部的配置
        WeChatProperties.Miniapp miniapp = weChatProperties.getMiniapp();
        if (miniapp == null) {
            logger.error("[WECHAT] 微信 Miniapp 配置未找到");
            throw new RuntimeException("微信登录失败：Miniapp 配置未找到");
        }

        String appid = miniapp.getAppid();
        String secret = miniapp.getSecret();

        if (appid == null || appid.trim().isEmpty() || "your-appid".equals(appid)) {
            logger.error("[WECHAT] 微信 AppID 未配置");
            throw new RuntimeException("微信登录失败：AppID 未配置");
        }

        if (secret == null || secret.trim().isEmpty() || "your-secret".equals(secret)) {
            logger.error("[WECHAT] 微信 AppSecret 未配置");
            throw new RuntimeException("微信登录失败：AppSecret 未配置");
        }

        logger.info("[WECHAT] 微信配置校验通过");
    }

    /**
     * 构建请求 URL
     */
    private String buildRequestUrl(String code) {
        // 获取 miniapp 内部的配置
        WeChatProperties.Miniapp miniapp = weChatProperties.getMiniapp();
        String appid = miniapp.getAppid();
        String secret = miniapp.getSecret();

        // 注意：不在日志中打印完整的 appid 和 secret
        logger.info("[WECHAT] appid: {}", maskSensitiveInfo(appid));
        logger.info("[WECHAT] code: {}", maskSensitiveInfo(code));

        return String.format("%s?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code",
                JSCODE2SESSION_URL, appid, secret, code);
    }

    /**
     * 解析微信接口响应
     * 先按 String 接收，再手动解析为 JSON
     */
    private String parseResponse(String responseBody) {
        if (responseBody == null || responseBody.trim().isEmpty()) {
            logger.error("[WECHAT] 微信接口返回为空");
            throw new RuntimeException("微信登录失败：接口返回为空");
        }

        try {
            // 使用 Jackson 手动解析 JSON
            @SuppressWarnings("unchecked")
            Map<String, Object> response = objectMapper.readValue(responseBody, Map.class);

            // 检查是否有错误码
            if (response.containsKey("errcode")) {
                int errCode = ((Number) response.get("errcode")).intValue();
                String errMsg = (String) response.get("errmsg");

                if (errCode != 0) {
                    logger.error("[WECHAT] API 错误: errcode={}, errmsg={}", errCode, errMsg);
                    throw new RuntimeException("微信登录失败：" + errMsg + " (错误码：" + errCode + ")");
                }
            }

            // 提取 openid
            String openid = (String) response.get("openid");
            if (openid == null || openid.trim().isEmpty()) {
                logger.error("[WECHAT] 微信接口未返回 openid");
                throw new RuntimeException("微信登录失败：未获取到 openid");
            }

            logger.info("[WECHAT] 获取 openid 成功: {}", maskSensitiveInfo(openid));
            return openid;

        } catch (RuntimeException e) {
            // 重新抛出业务异常
            throw e;
        } catch (Exception e) {
            logger.error("[WECHAT] 解析微信响应失败: {}", e.getMessage());
            throw new RuntimeException("微信登录失败：响应解析异常", e);
        }
    }

    /**
     * 脱敏敏感信息
     */
    private String maskSensitiveInfo(String info) {
        if (info == null || info.length() <= 6) {
            return info;
        }
        return info.substring(0, 3) + "***" + info.substring(info.length() - 3);
    }
}