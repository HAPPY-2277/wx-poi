package com.poi.exception;

/**
 * 类型安全异常
 * 用于在类型检查失败时抛出
 */
public class TypeSafeException extends RuntimeException {
    
    private final String fieldName;
    private final String errorType;
    private final String actualValue;
    private final String expectedType;
    
    public TypeSafeException(String fieldName, String errorType, String actualValue, String expectedType, String message) {
        super(message);
        this.fieldName = fieldName;
        this.errorType = errorType;
        this.actualValue = actualValue;
        this.expectedType = expectedType;
    }
    
    public String getFieldName() {
        return fieldName;
    }
    
    public String getErrorType() {
        return errorType;
    }
    
    public String getActualValue() {
        return actualValue;
    }
    
    public String getExpectedType() {
        return expectedType;
    }
}
