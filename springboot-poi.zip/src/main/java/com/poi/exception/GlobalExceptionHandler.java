package com.poi.exception;

import com.poi.common.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/**
 * 全局异常处理器
 * 处理类型安全异常和其他运行时异常
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    /**
     * 处理类型安全异常
     */
    @ExceptionHandler(TypeSafeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiResponse<Map<String, Object>> handleTypeSafeException(TypeSafeException e) {
        logger.error("[TYPE] 类型安全异常: 字段={} 错误={} 实际值={} 期望类型={} 消息={}", 
                e.getFieldName(), e.getErrorType(), e.getActualValue(), e.getExpectedType(), e.getMessage());
        
        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("field", e.getFieldName());
        errorDetails.put("errorType", e.getErrorType());
        errorDetails.put("actualValue", e.getActualValue());
        errorDetails.put("expectedType", e.getExpectedType());
        errorDetails.put("message", e.getMessage());
        
        return ApiResponse.error(400, "请求参数类型错误：" + e.getMessage(), errorDetails);
    }
    
    /**
     * 处理其他运行时异常
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ApiResponse<Void> handleRuntimeException(RuntimeException e) {
        logger.error("[EXCEPTION] 运行时异常: {}", e.getMessage(), e);
        return ApiResponse.error(500, "服务器内部错误：" + e.getMessage());
    }
    
    /**
     * 处理非法参数异常
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiResponse<Void> handleIllegalArgumentException(IllegalArgumentException e) {
        logger.error("[EXCEPTION] 非法参数异常: {}", e.getMessage());
        return ApiResponse.error(400, "参数错误：" + e.getMessage());
    }
}
