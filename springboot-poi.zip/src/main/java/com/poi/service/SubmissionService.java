package com.poi.service;

import com.poi.dto.PoiSubmission;
import com.poi.dto.PoiSubmissionImageResponse;
import com.poi.dto.PoiTask;
import com.poi.enums.PoiCategory;
import com.poi.enums.SubmissionStatus;
import com.poi.enums.SubmissionType;
import com.poi.enums.TaskStatus;
import com.poi.enums.TaskType;
import com.poi.repository.PoiImageRepository;
import com.poi.repository.PoiRepository;
import com.poi.repository.PoiSubmissionImageRepository;
import com.poi.repository.PoiSubmissionRepository;
import com.poi.repository.PoiTaskAssigneeRepository;
import com.poi.repository.PoiTaskRepository;
import com.poi.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * 提交服务层
 * 处理提交审核相关业务逻辑
 */
@Service
public class SubmissionService {

    private static final Logger logger = LoggerFactory.getLogger(SubmissionService.class);

    /**
     * 允许提交的角色
     */
    private static final String[] ALLOWED_SUBMITTER_ROLES = {"collector", "verifier", "admin"};

    /**
     * 允许审核的角色
     */
    private static final String[] ALLOWED_REVIEWER_ROLES = {"verifier", "admin"};

    private final PoiSubmissionRepository submissionRepository;
    private final PoiTaskRepository taskRepository;
    private final PoiTaskAssigneeRepository assigneeRepository;
    private final PoiRepository poiRepository;
    private final PoiImageRepository poiImageRepository;
    private final PoiSubmissionImageRepository submissionImageRepository;
    private final UserRepository userRepository;

    public SubmissionService(PoiSubmissionRepository submissionRepository,
                            PoiTaskRepository taskRepository,
                            PoiTaskAssigneeRepository assigneeRepository,
                            PoiRepository poiRepository,
                            PoiImageRepository poiImageRepository,
                            PoiSubmissionImageRepository submissionImageRepository,
                            UserRepository userRepository) {
        this.submissionRepository = submissionRepository;
        this.taskRepository = taskRepository;
        this.assigneeRepository = assigneeRepository;
        this.poiRepository = poiRepository;
        this.poiImageRepository = poiImageRepository;
        this.submissionImageRepository = submissionImageRepository;
        this.userRepository = userRepository;
    }

    /**
     * 采集者提交数据
     */
    @Transactional
    public String createSubmission(String taskId, String submitterId, String name, String category,
                                 String description, Double longitude, Double latitude, String address) {
        logger.info("[SUBMISSION] 开始创建提交 taskId={} submitterId={} category={}", taskId, submitterId, category);

        // 校验提交者身份和角色
        verifySubmitterIdentity(submitterId);

        // 校验任务存在
        PoiTask task = taskRepository.findTaskById(taskId);
        if (task == null) {
            logger.error("[SUBMISSION] 任务不存在 taskId={}", taskId);
            throw new RuntimeException("任务不存在");
        }

        // 校验当前用户是任务的assignee
        if (!assigneeRepository.existsAssigneeInTask(taskId, submitterId)) {
            logger.error("[SUBMISSION] 当前用户不是任务采集者 taskId={} submitterId={}", taskId, submitterId);
            throw new RuntimeException("当前用户不是该任务的采集者");
        }

        // 校验任务状态允许提交
        if (!TaskStatus.PENDING_COLLECTION.name().equals(task.getStatus())) {
            logger.error("[SUBMISSION] 任务状态不允许提交 taskId={} status={}", taskId, task.getStatus());
            throw new RuntimeException("任务当前状态不允许提交");
        }

        // 校验分类值
        validateCategory(category);

        // 检查是否已有待审核提交（唯一约束）
        PoiSubmission pendingSubmission = submissionRepository.findPendingSubmissionByTaskId(taskId);
        if (pendingSubmission != null) {
            logger.error("[SUBMISSION] 任务已有待审核提交 taskId={}", taskId);
            throw new RuntimeException("该任务已有待审核的提交，请等待审核完成");
        }

        // 推导提交类型
        String submissionType;
        String poiId = null;
        if (TaskType.CREATE_NEW.name().equals(task.getTaskType())) {
            submissionType = SubmissionType.CREATE.name();
        } else {
            submissionType = SubmissionType.UPDATE.name();
            poiId = task.getPoiId();
        }

        // 插入提交记录
        String status = SubmissionStatus.PENDING_REVIEW.name();
        String submissionId = submissionRepository.insertSubmission(poiId, submitterId, submissionType,
                name, category, description, longitude, latitude, address, status, false, taskId);

        logger.info("[SUBMISSION] 提交创建成功 taskId={} submitterId={} category={} submissionId={}", taskId, submitterId, category, submissionId);

        // 更新任务状态为待审核
        taskRepository.updateTaskStatus(taskId, TaskStatus.PENDING_REVIEW.name());
        logger.info("[SUBMISSION] 任务状态更新为待审核 taskId={}", taskId);

        logger.info("[SUBMISSION] 创建提交完成 taskId={} submissionId={}", taskId, submissionId);
        return submissionId;
    }

    /**
     * 审核通过
     */
    @Transactional
    public void approveSubmission(String submissionId, String reviewerId, String reviewComment) {
        logger.info("[REVIEW] 开始审核通过 submissionId={} reviewerId={}", submissionId, reviewerId);

        // 校验审核者身份和角色
        verifyReviewerIdentity(reviewerId);

        // 获取提交记录
        PoiSubmission submission = submissionRepository.findSubmissionById(submissionId);
        if (submission == null) {
            logger.error("[REVIEW] 提交不存在 submissionId={}", submissionId);
            throw new RuntimeException("提交不存在");
        }

        // 校验提交状态
        if (!SubmissionStatus.PENDING_REVIEW.name().equals(submission.getStatus())) {
            logger.error("[REVIEW] 提交状态不允许审核 submissionId={} status={}", submissionId, submission.getStatus());
            throw new RuntimeException("提交当前状态不允许审核");
        }

        // 获取任务
        PoiTask task = taskRepository.findTaskById(submission.getTaskId());
        if (task == null) {
            logger.error("[REVIEW] 任务不存在 taskId={}", submission.getTaskId());
            throw new RuntimeException("任务不存在");
        }

        // 校验任务状态
        if (!TaskStatus.PENDING_REVIEW.name().equals(task.getStatus())) {
            logger.error("[REVIEW] 任务状态不允许审核 taskId={} status={}", task.getId(), task.getStatus());
            throw new RuntimeException("任务当前状态不允许审核");
        }

        if (SubmissionType.CREATE.name().equals(submission.getSubmissionType())) {
            // CREATE_NEW: 新增poi
            logger.info("[REVIEW] CREATE_NEW 审核通过，开始创建POI，分类={}", submission.getCategory());

            // 查询提交的图片
            List<PoiSubmissionImageResponse> submissionImages = submissionImageRepository.findBySubmissionId(submissionId);
            logger.info("[IMAGE] 查询到 submission 图片数量: {}", submissionImages.size());

            // 插入poi并直接获取 poiId
            String newPoiId = poiRepository.insertPoi(
                    submission.getName(),
                    submission.getCategory(),
                    submission.getDescription(),
                    submission.getLongitude(),
                    submission.getLatitude(),
                    submission.getAddress(),
                    submission.getSubmitterId()
            );

            logger.info("[REVIEW] CREATE_NEW 审核通过，获取到真实 poiId={}, 分类={}", newPoiId, submission.getCategory());

            // 回填submission.poi_id
            submissionRepository.updateSubmissionPoiId(submissionId, newPoiId);
            logger.info("[REVIEW] 回填提交POI ID submissionId={} poiId={}", submissionId, newPoiId);

            // 复制图片到 poi_image
            if (!submissionImages.isEmpty()) {
                logger.info("[IMAGE] 开始复制 submission 图片到 poi");
                int copiedCount = poiImageRepository.copyFromSubmissionImages(submissionImages, newPoiId);
                logger.info("[IMAGE] 图片复制成功: count={}", copiedCount);
            } else {
                logger.info("[IMAGE] 无图片需要复制");
            }

            // 注意：CREATE_NEW 类型的任务不回填 task.poi_id（数据库约束不允许）
            logger.info("[REVIEW] CREATE_NEW 类型任务，不更新 task.poi_id");

            logger.info("[REVIEW] CREATE_NEW 审核通过，已创建 poiId={}", newPoiId);

        } else {
            // UPDATE_EXISTING: 更新poi
            logger.info("[REVIEW] UPDATE_EXISTING 审核通过，开始更新POI");

            // 查询提交的图片
            List<PoiSubmissionImageResponse> submissionImages = submissionImageRepository.findBySubmissionId(submissionId);
            logger.info("[IMAGE] 查询到 submission 图片数量: {}", submissionImages.size());

            // 停用旧的生效版本
            PoiSubmission oldActive = submissionRepository.findActiveSubmissionByPoiId(submission.getPoiId());
            if (oldActive != null) {
                submissionRepository.updateSubmissionActive(oldActive.getId(), false);
                logger.info("[REVIEW] 停用旧版本 submissionId={}", oldActive.getId());
            }

            // 更新poi主表
            poiRepository.updatePoi(
                    submission.getPoiId(),
                    submission.getName(),
                    submission.getCategory(),
                    submission.getDescription(),
                    submission.getLongitude(),
                    submission.getLatitude(),
                    submission.getAddress(),
                    submission.getSubmitterId()
            );

            // 复制图片到 poi_image
            if (!submissionImages.isEmpty()) {
                logger.info("[IMAGE] 开始复制 submission 图片到 poi");
                int copiedCount = poiImageRepository.copyFromSubmissionImages(submissionImages, submission.getPoiId());
                logger.info("[IMAGE] 图片复制成功: count={}", copiedCount);
            } else {
                logger.info("[IMAGE] 无图片需要复制");
            }

            logger.info("[REVIEW] UPDATE_EXISTING 审核通过，已更新 poiId={}", submission.getPoiId());
        }

        // 更新提交状态
        submissionRepository.updateSubmissionReviewInfo(submissionId,
                SubmissionStatus.APPROVED.name(), true, reviewerId, reviewComment);
        logger.info("[REVIEW] 提交状态更新为 APPROVED submissionId={}", submissionId);

        // 更新任务状态为完成
        taskRepository.updateTaskStatus(task.getId(), TaskStatus.COMPLETED.name());
        logger.info("[REVIEW] 任务状态更新为 COMPLETED taskId={}", task.getId());

        logger.info("[REVIEW] 审核通过完成 submissionId={}", submissionId);
    }

    /**
     * 审核驳回
     */
    @Transactional
    public void rejectSubmission(String submissionId, String reviewerId, String reviewComment) {
        logger.info("[REVIEW] 开始审核驳回 submissionId={} reviewerId={}", submissionId, reviewerId);

        // 校验审核者身份和角色
        verifyReviewerIdentity(reviewerId);

        // 获取提交记录
        PoiSubmission submission = submissionRepository.findSubmissionById(submissionId);
        if (submission == null) {
            logger.error("[REVIEW] 提交不存在 submissionId={}", submissionId);
            throw new RuntimeException("提交不存在");
        }

        // 校验提交状态
        if (!SubmissionStatus.PENDING_REVIEW.name().equals(submission.getStatus())) {
            logger.error("[REVIEW] 提交状态不允许驳回 submissionId={} status={}", submissionId, submission.getStatus());
            throw new RuntimeException("提交当前状态不允许驳回");
        }

        // 更新提交状态
        submissionRepository.updateSubmissionReviewInfo(submissionId,
                SubmissionStatus.REJECTED.name(), false, reviewerId, reviewComment);
        logger.info("[REVIEW] 提交状态更新为 REJECTED submissionId={}", submissionId);

        // 获取任务并更新状态
        PoiTask task = taskRepository.findTaskById(submission.getTaskId());
        if (task != null) {
            taskRepository.updateTaskStatus(task.getId(), TaskStatus.PENDING_COLLECTION.name());
            logger.info("[REVIEW] 任务状态退回 PENDING_COLLECTION taskId={}", task.getId());
        }

        logger.info("[REVIEW] 审核驳回完成 submissionId={}", submissionId);
    }

    /**
     * 驳回后重新提交
     */
    @Transactional
    public void resubmitAfterReject(String taskId, String submitterId, String name, String category,
                                   String description, Double longitude, Double latitude, String address) {
        logger.info("[SUBMISSION] 开始重新提交 taskId={} submitterId={} category={}", taskId, submitterId, category);

        // 校验提交者身份和角色
        verifySubmitterIdentity(submitterId);

        // 校验任务存在
        PoiTask task = taskRepository.findTaskById(taskId);
        if (task == null) {
            logger.error("[SUBMISSION] 任务不存在 taskId={}", taskId);
            throw new RuntimeException("任务不存在");
        }

        // 校验当前用户是任务的assignee
        if (!assigneeRepository.existsAssigneeInTask(taskId, submitterId)) {
            logger.error("[SUBMISSION] 当前用户不是任务采集者 taskId={} submitterId={}", taskId, submitterId);
            throw new RuntimeException("当前用户不是该任务的采集者");
        }

        // 校验任务状态允许重新提交
        if (!TaskStatus.PENDING_COLLECTION.name().equals(task.getStatus())) {
            logger.error("[SUBMISSION] 任务状态不允许重新提交 taskId={} status={}", taskId, task.getStatus());
            throw new RuntimeException("任务当前状态不允许重新提交");
        }

        // 校验分类值
        validateCategory(category);

        // 检查是否已有待审核提交
        PoiSubmission pendingSubmission = submissionRepository.findPendingSubmissionByTaskId(taskId);
        if (pendingSubmission != null) {
            logger.error("[SUBMISSION] 任务已有待审核提交 taskId={}", taskId);
            throw new RuntimeException("该任务已有待审核的提交");
        }

        // 推导提交类型
        String submissionType;
        String poiId = null;
        if (TaskType.CREATE_NEW.name().equals(task.getTaskType())) {
            submissionType = SubmissionType.CREATE.name();
        } else {
            submissionType = SubmissionType.UPDATE.name();
            poiId = task.getPoiId();
        }

        // 插入新的提交记录
        String status = SubmissionStatus.PENDING_REVIEW.name();
        submissionRepository.insertSubmission(poiId, submitterId, submissionType,
                name, category, description, longitude, latitude, address, status, false, taskId);

        logger.info("[SUBMISSION] 重新提交创建成功 taskId={}", taskId);

        // 更新任务状态为待审核
        taskRepository.updateTaskStatus(taskId, TaskStatus.PENDING_REVIEW.name());
        logger.info("[SUBMISSION] 任务状态更新为待审核 taskId={}", taskId);

        logger.info("[SUBMISSION] 重新提交完成 taskId={}", taskId);
    }

    /**
     * 获取提交详情
     */
    public PoiSubmission getSubmissionById(String submissionId) {
        logger.info("[SUBMISSION] 获取提交详情 submissionId={}", submissionId);
        PoiSubmission submission = submissionRepository.findSubmissionById(submissionId);
        if (submission == null) {
            logger.warn("[SUBMISSION] 提交不存在 submissionId={}", submissionId);
            throw new RuntimeException("提交不存在");
        }
        populateSubmissionImages(submission);
        return submission;
    }

    /**
     * 获取任务的提交列表
     */
    public List<PoiSubmission> getSubmissionsByTaskId(String taskId) {
        logger.info("[SUBMISSION] 获取任务提交列表 taskId={}", taskId);
        List<PoiSubmission> submissions = submissionRepository.findSubmissionsByTaskId(taskId);
        for (PoiSubmission submission : submissions) {
            populateSubmissionImages(submission);
        }
        return submissions;
    }

    /**
     * 获取提交者的提交记录
     */
    public List<PoiSubmission> getSubmissionsBySubmitterId(String submitterId) {
        logger.info("[SUBMISSION] 获取提交者提交列表 submitterId={}", submitterId);
        List<PoiSubmission> submissions = submissionRepository.findSubmissionsBySubmitterId(submitterId);
        for (PoiSubmission submission : submissions) {
            populateSubmissionImages(submission);
        }
        return submissions;
    }

    /**
     * 获取待审核提交列表
     */
    public List<PoiSubmission> getPendingReviewSubmissions() {
        logger.info("[SUBMISSION] 获取待审核提交列表");
        List<PoiSubmission> submissions = submissionRepository.findPendingReviewSubmissions();
        for (PoiSubmission submission : submissions) {
            populateSubmissionImages(submission);
        }
        return submissions;
    }

    /**
     * 填充提交的 图片列表
     */
    private void populateSubmissionImages(PoiSubmission submission) {
        logger.info("[IMAGE] 查询 submission 图片: submissionId={}", submission.getId());
        List<PoiSubmissionImageResponse> images = submissionImageRepository.findBySubmissionId(submission.getId());
        submission.setImages(images);
        logger.info("[IMAGE] submission 图片填充完成: submissionId={}, count={}", submission.getId(), images.size());
    }

    /**
     * 校验提交者身份和角色
     */
    private void verifySubmitterIdentity(String submitterId) {
        logger.info("[AUTH] 开始校验提交者身份 submitterId={}", submitterId);
        
        // 校验 submitterId 不为空
        if (submitterId == null || submitterId.trim().isEmpty()) {
            logger.error("[AUTH] submitterId 不能为空");
            throw new RuntimeException("提交者ID不能为空");
        }
        
        // 校验 submitterId 是合法 UUID
        try {
            UUID.fromString(submitterId);
        } catch (IllegalArgumentException e) {
            logger.error("[AUTH] submitterId 格式非法: submitterId={}", submitterId);
            throw new RuntimeException("提交者ID格式不正确");
        }
        
        // 查询用户角色
        String role = userRepository.findRoleByUserId(submitterId);
        if (role == null) {
            logger.error("[AUTH] 提交者不存在 submitterId={}", submitterId);
            throw new RuntimeException("提交者不存在");
        }
        
        logger.info("[AUTH] 提交者身份核验: submitterId={}, role={}", submitterId, role);

        boolean allowed = false;
        for (String allowedRole : ALLOWED_SUBMITTER_ROLES) {
            if (allowedRole.equalsIgnoreCase(role)) {
                allowed = true;
                break;
            }
        }
        if (!allowed) {
            logger.error("[AUTH] 提交者角色不合规 submitterId={}, role={}", submitterId, role);
            throw new RuntimeException("您的角色不允许提交数据");
        }
        logger.info("[AUTH] 提交者身份核验通过 submitterId={}, role={}", submitterId, role);
    }

    /**
     * 校验审核者身份和角色
     */
    private void verifyReviewerIdentity(String reviewerId) {
        logger.info("[AUTH] 开始校验审核者身份 reviewerId={}", reviewerId);
        
        // 校验 reviewerId 不为空
        if (reviewerId == null || reviewerId.trim().isEmpty()) {
            logger.error("[AUTH] reviewerId 不能为空");
            throw new RuntimeException("审核者ID不能为空");
        }
        
        // 校验 reviewerId 是合法 UUID
        try {
            UUID.fromString(reviewerId);
        } catch (IllegalArgumentException e) {
            logger.error("[AUTH] reviewerId 格式非法: reviewerId={}", reviewerId);
            throw new RuntimeException("审核者ID格式不正确");
        }
        
        // 查询用户角色
        String role = userRepository.findRoleByUserId(reviewerId);
        if (role == null) {
            logger.error("[AUTH] 审核者不存在 reviewerId={}", reviewerId);
            throw new RuntimeException("审核者不存在");
        }
        
        logger.info("[AUTH] 审核者身份核验: reviewerId={}, role={}", reviewerId, role);

        boolean allowed = false;
        for (String allowedRole : ALLOWED_REVIEWER_ROLES) {
            if (allowedRole.equalsIgnoreCase(role)) {
                allowed = true;
                break;
            }
        }
        if (!allowed) {
            logger.error("[AUTH] 审核者角色不合规 reviewerId={}, role={}", reviewerId, role);
            throw new RuntimeException("只有核验者或管理员可以审核");
        }
        logger.info("[AUTH] 审核者身份核验通过 reviewerId={}, role={}", reviewerId, role);
    }

    /**
     * 校验分类值是否有效
     */
    private void validateCategory(String category) {
        if (category == null || category.trim().isEmpty()) {
            logger.error("[SUBMISSION] 分类不能为空");
            throw new RuntimeException("分类不能为空");
        }
        if (!PoiCategory.isValid(category)) {
            logger.error("[SUBMISSION] 分类值无效: category={}", category);
            throw new RuntimeException("分类值无效，允许的值为: " + String.join(", ", PoiCategory.getAllValues()));
        }
    }
}