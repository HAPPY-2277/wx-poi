package com.poi.service;

import com.poi.dto.PoiImageResponse;
import com.poi.dto.PoiRequest;
import com.poi.dto.PoiResponse;
import com.poi.repository.PoiImageRepository;
import com.poi.repository.PoiRepository;
import com.poi.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * POI 业务服务层
 * 处理 POI 相关业务逻辑
 *
 * 重要说明：
 * 1. 创建新 POI 必须通过 submission 流程，不允许直接写入 poi 主表
 * 2. poi 主表只保存审核通过的正式数据
 */
@Service
public class PoiService {

    private static final Logger logger = LoggerFactory.getLogger(PoiService.class);

    /**
     * UUID 格式正则表达式
     */
    private static final Pattern UUID_PATTERN = Pattern.compile(
            "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
    );

    private final PoiRepository poiRepository;
    private final PoiImageRepository poiImageRepository;
    private final UserRepository userRepository;

    public PoiService(PoiRepository poiRepository, PoiImageRepository poiImageRepository, UserRepository userRepository) {
        this.poiRepository = poiRepository;
        this.poiImageRepository = poiImageRepository;
        this.userRepository = userRepository;
    }

    /**
     * 上传 POI - 已禁用
     *
     * 注意：创建新 POI 必须通过任务流程：
     * 1. 核验者发布 CREATE_NEW 任务
     * 2. 采集者领取任务并提交数据
     * 3. 核验者审核通过
     * 4. 审核通过后才会在 poi 主表创建正式记录
     *
     * 此接口暂时禁用，直接调用会抛出异常。
     *
     * @param request POI 请求对象
     * @deprecated 请通过任务流程创建 POI
     */
    @Deprecated
    public void uploadPoi(PoiRequest request) {
        logger.error("[POI] 禁止直接调用 uploadPoi，请通过任务流程创建 POI");
        throw new RuntimeException("创建新 POI 必须通过任务流程，请先发布任务");
    }

    /**
     * 获取 POI 列表
     */
    public List<PoiResponse> getPoiList() {
        logger.info("[POI] 获取 POI 列表");
        List<PoiResponse> poiList = poiRepository.findAll();
        for (PoiResponse poi : poiList) {
            populateImages(poi);
        }
        return poiList;
    }

    /**
     * 获取 POI 详情
     * @param id POI ID
     * @return POI 详情
     * @throws RuntimeException 如果 POI 不存在
     */
    public PoiResponse getPoiById(String id) {
        logger.info("[POI] 获取 POI 详情: id={}", id);

        if (!UUID_PATTERN.matcher(id).matches()) {
            logger.error("[POI] 校验失败：id 格式非法");
            throw new RuntimeException("ID 格式不正确");
        }

        PoiResponse poi = poiRepository.findById(id);

        if (poi == null) {
            logger.warn("[POI] POI 不存在: id={}", id);
            throw new RuntimeException("POI 不存在");
        }

        populateImages(poi);
        return poi;
    }

    /**
     * 获取指定采集者的 POI 列表
     * @param collectorId 采集者 ID
     * @return POI 列表（可能为空数组）
     */
    public List<PoiResponse> getPoiListByCollectorId(String collectorId) {
        logger.info("[POI] 获取采集者的 POI 列表: collectorId={}", collectorId);

        if (!UUID_PATTERN.matcher(collectorId).matches()) {
            logger.error("[POI] 校验失败：collectorId 格式非法");
            throw new RuntimeException("采集者 ID 格式不正确");
        }

        if (!userExists(collectorId)) {
            logger.warn("[POI] 用户不存在: collectorId={}", collectorId);
            throw new RuntimeException("采集者不存在");
        }

        List<PoiResponse> poiList = poiRepository.findByCollectorId(collectorId);
        for (PoiResponse poi : poiList) {
            populateImages(poi);
        }
        return poiList;
    }

    /**
     * 填充 POI 的图片列表
     */
    private void populateImages(PoiResponse poi) {
        logger.info("[IMAGE] 查询 poi 图片: poiId={}", poi.getId());
        List<PoiImageResponse> images = poiImageRepository.findByPoiId(poi.getId());
        poi.setImages(images);
        logger.info("[IMAGE] poi 图片填充完成: poiId={}, count={}", poi.getId(), images.size());
    }

    /**
     * 检查用户是否存在
     */
    private boolean userExists(String userId) {
        logger.info("[POI] 检查用户是否存在: userId={}", userId);
        String sql = "SELECT COUNT(*) FROM users WHERE id = ?";
        UUID userUuid = UUID.fromString(userId);
        Integer count = userRepository.getJdbcTemplate().queryForObject(sql, Integer.class, userUuid);
        boolean exists = count != null && count > 0;
        logger.info("[POI] 用户存在检查结果: exists={}", exists);
        return exists;
    }
}