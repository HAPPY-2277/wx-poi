package com.poi.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.UUID;

/**
 * 文件存储服务
 * 提供本地文件存储能力，支持 MultipartFile 和 Base64 两种方式
 */
@Service
public class FileStorageService {

    private static final Logger logger = LoggerFactory.getLogger(FileStorageService.class);

    private static final String POI_UPLOAD_DIR = "uploads/poi";
    private static final String SUBMISSION_UPLOAD_DIR = "uploads/submission";

    /**
     * 保存 POI 图片（MultipartFile 方式）
     * @param file 上传的文件
     * @return 保存后的 imageUrl 路径
     */
    public String savePoiImage(MultipartFile file) {
        return saveFile(file, POI_UPLOAD_DIR);
    }

    /**
     * 保存 Submission 图片（MultipartFile 方式）
     * @param file 上传的文件
     * @return 保存后的 imageUrl 路径
     */
    public String saveSubmissionImage(MultipartFile file) {
        return saveFile(file, SUBMISSION_UPLOAD_DIR);
    }

    /**
     * 保存 POI 图片（Base64 方式）
     * @param filename 文件名
     * @param base64Data Base64 编码的图片数据
     * @return 保存后的 imageUrl 路径
     */
    public String savePoiImageFromBase64(String filename, String base64Data) {
        return saveFileFromBase64(filename, base64Data, POI_UPLOAD_DIR);
    }

    /**
     * 保存 Submission 图片（Base64 方式）
     * @param filename 文件名
     * @param base64Data Base64 编码的图片数据
     * @return 保存后的 imageUrl 路径
     */
    public String saveSubmissionImageFromBase64(String filename, String base64Data) {
        return saveFileFromBase64(filename, base64Data, SUBMISSION_UPLOAD_DIR);
    }

    /**
     * 保存文件到指定目录（MultipartFile 方式）
     * @param file 上传的文件
     * @param subDir 子目录
     * @return 保存后的 imageUrl 路径
     */
    private String saveFile(MultipartFile file, String subDir) {
        logger.info("[FILE] 开始保存文件(MultipartFile): originalName={}, size={}, contentType={}",
                file.getOriginalFilename(), file.getSize(), file.getContentType());

        try {
            String originalFilename = file.getOriginalFilename();
            String extension = getFileExtension(originalFilename);

            String newFileName = UUID.randomUUID().toString() + extension;

            Path uploadDir = Paths.get(subDir);
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
                logger.info("[FILE] 创建上传目录: {}", uploadDir.toAbsolutePath());
            }

            Path filePath = uploadDir.resolve(newFileName);
            Files.copy(file.getInputStream(), filePath);

            String imageUrl = "/" + subDir + "/" + newFileName;

            logger.info("[FILE] 文件保存成功: path={}, imageUrl={}", filePath.toAbsolutePath(), imageUrl);
            return imageUrl;

        } catch (IOException e) {
            logger.error("[FILE] 文件保存失败: {}", e.getMessage());
            throw new RuntimeException("文件保存失败: " + e.getMessage(), e);
        }
    }

    /**
     * 保存文件到指定目录（Base64 方式）
     * @param filename 文件名
     * @param base64Data Base64 编码的图片数据
     * @param subDir 子目录
     * @return 保存后的 imageUrl 路径
     */
    private String saveFileFromBase64(String filename, String base64Data, String subDir) {
        logger.info("[FILE] 开始保存文件(Base64): filename={}", filename);

        try {
            // 移除可能存在的 data:image/xxx;base64, 前缀
            String cleanBase64 = base64Data;
            if (base64Data.contains(",")) {
                cleanBase64 = base64Data.split(",")[1];
            }

            // 解码 Base64
            byte[] imageBytes = Base64.getDecoder().decode(cleanBase64);
            logger.info("[FILE] Base64 解码成功, 字节大小={} bytes", imageBytes.length);

            String extension = getFileExtension(filename);
            String newFileName = UUID.randomUUID().toString() + extension;

            Path uploadDir = Paths.get(subDir);
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
                logger.info("[FILE] 创建上传目录: {}", uploadDir.toAbsolutePath());
            }

            Path filePath = uploadDir.resolve(newFileName);
            Files.write(filePath, imageBytes);

            String imageUrl = "/" + subDir + "/" + newFileName;

            logger.info("[FILE] 文件保存成功(Base64): path={}, imageUrl={}", filePath.toAbsolutePath(), imageUrl);
            return imageUrl;

        } catch (IllegalArgumentException e) {
            logger.error("[FILE] Base64 解码失败: {}", e.getMessage());
            throw new RuntimeException("图片数据解码失败: " + e.getMessage(), e);
        } catch (IOException e) {
            logger.error("[FILE] 文件保存失败: {}", e.getMessage());
            throw new RuntimeException("文件保存失败: " + e.getMessage(), e);
        }
    }

    /**
     * 获取文件扩展名
     */
    private String getFileExtension(String filename) {
        if (filename == null || filename.isEmpty()) {
            return ".jpg";
        }
        int dotIndex = filename.lastIndexOf('.');
        if (dotIndex > 0) {
            return filename.substring(dotIndex).toLowerCase();
        }
        return ".jpg";
    }
}
