package com.poi.service;

import com.poi.dto.PoiTask;
import com.poi.enums.PoiCategory;
import com.poi.enums.TaskStatus;
import com.poi.enums.TaskType;
import com.poi.repository.PoiTaskAssigneeRepository;
import com.poi.repository.PoiTaskRepository;
import com.poi.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * 任务服务层
 * 处理任务相关业务逻辑
 */
@Service
public class TaskService {

    private static final Logger logger = LoggerFactory.getLogger(TaskService.class);

    /**
     * 允许发布任务的角色
     */
    private static final String[] ALLOWED_PUBLISHER_ROLES = {"verifier", "admin"};

    /**
     * 允许创建 POI 的角色列表
     */
    private static final String[] ALLOWED_ROLES = {"collector", "verifier", "admin"};

    private final PoiTaskRepository taskRepository;
    private final PoiTaskAssigneeRepository assigneeRepository;
    private final UserRepository userRepository;
    private final JdbcTemplate jdbcTemplate;

    public TaskService(PoiTaskRepository taskRepository,
                       PoiTaskAssigneeRepository assigneeRepository,
                       UserRepository userRepository,
                       JdbcTemplate jdbcTemplate) {
        this.taskRepository = taskRepository;
        this.assigneeRepository = assigneeRepository;
        this.userRepository = userRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * 核验者发布任务
     * @param publisherId 发布者ID（核验者）
     * @param taskType 任务类型 CREATE_NEW/UPDATE_EXISTING
     * @param poiId POI ID（UPDATE_EXISTING时必填）
     * @param description 任务描述
     * @param targetName 目标名称
     * @param targetCategory 目标分类
     * @param targetLongitude 目标经度
     * @param targetLatitude 目标纬度
     * @param targetAddress 目标地址
     * @param assigneeIds 采集者ID列表
     */
    @Transactional
    public void createTask(String publisherId, String taskType, String poiId, String description,
                          String targetName, String targetCategory, Double targetLongitude,
                          Double targetLatitude, String targetAddress, List<String> assigneeIds) {
        logger.info("[TASK] 开始发布任务 publisherId={}, taskType={}, targetCategory={}", publisherId, taskType, targetCategory);

        // 校验发布者身份和角色
        verifyPublisherIdentity(publisherId);

        // 校验任务类型与poiId的关系
        validateTaskTypeAndPoiId(taskType, poiId);

        // 校验分类值
        validateCategory(targetCategory);

        // 校验采集者列表
        validateAssignees(assigneeIds);

        // 插入任务并直接获取 taskId
        String status = TaskStatus.PENDING_COLLECTION.name();
        String taskId = taskRepository.insertTask(publisherId, poiId, description, status,
                assigneeIds.size(), taskType, targetName, targetCategory,
                targetLongitude, targetLatitude, targetAddress);

        logger.info("[TASK] 任务创建成功，获取到真实 taskId={}", taskId);
        logger.info("[TASK] 任务分类: targetCategory={}", targetCategory);

        // 批量插入任务分配（直接使用刚获取的 taskId）
        logger.info("[TASK] 开始分配采集者 taskId={}, assigneeCount={}", taskId, assigneeIds.size());
        assigneeRepository.batchInsertTaskAssignees(taskId, assigneeIds);
        logger.info("[TASK] 任务分配完成 taskId={}", taskId);

        logger.info("[TASK] 发布任务完成 taskId={}, publisherId={}, taskType={}", taskId, publisherId, taskType);
    }

    /**
     * 校验分类值是否有效
     */
    private void validateCategory(String category) {
        if (category == null || category.trim().isEmpty()) {
            logger.error("[TASK] 分类不能为空");
            throw new RuntimeException("分类不能为空");
        }
        if (!PoiCategory.isValid(category)) {
            logger.error("[TASK] 分类值无效: category={}", category);
            throw new RuntimeException("分类值无效，允许的值为: " + String.join(", ", PoiCategory.getAllValues()));
        }
    }

    /**
     * 获取任务详情
     */
    public PoiTask getTaskById(String taskId) {
        logger.info("[TASK] 获取任务详情 taskId={}", taskId);
        PoiTask task = taskRepository.findTaskById(taskId);
        if (task == null) {
            logger.warn("[TASK] 任务不存在 taskId={}", taskId);
            throw new RuntimeException("任务不存在");
        }
        return task;
    }

    /**
     * 获取发布者的任务列表
     */
    public List<PoiTask> getTasksByPublisherId(String publisherId) {
        logger.info("[TASK] 获取发布者任务列表 publisherId={}", publisherId);
        return taskRepository.findTasksByPublisherId(publisherId);
    }

    /**
     * 获取采集者的任务列表
     */
    public List<PoiTask> getTasksByCollectorId(String collectorId) {
        logger.info("[TASK] 获取采集者任务列表开始 collectorId={}", collectorId);
        
        // 记录类型转换信息
        logger.info("[TASK] 准备将 collectorId(String) 转换为 UUID");
        try {
            UUID.fromString(collectorId);
            logger.info("[TASK] collectorId 类型转换校验通过");
        } catch (IllegalArgumentException e) {
            logger.error("[TASK] collectorId 类型转换失败: {}", e.getMessage());
            throw e;
        }
        
        // 调用Repository层
        logger.info("[TASK] 调用 PoiTaskRepository.findTasksByCollectorId()");
        List<PoiTask> tasks = taskRepository.findTasksByCollectorId(collectorId);
        
        // 记录查询结果
        logger.info("[TASK] 获取采集者任务列表完成 collectorId={}, 任务数量={}", collectorId, tasks.size());
        return tasks;
    }

    /**
     * 获取待审核任务列表
     */
    public List<PoiTask> getPendingReviewTasks() {
        logger.info("[TASK] 获取待审核任务列表");
        return taskRepository.findTasksByStatus(TaskStatus.PENDING_REVIEW.name());
    }

    /**
     * 更新任务状态
     */
    public void updateTaskStatus(String taskId, String status) {
        logger.info("[TASK] 更新任务状态 taskId={}, status={}", taskId, status);
        taskRepository.updateTaskStatus(taskId, status);
    }

    /**
     * 校验发布者身份和角色
     */
    private void verifyPublisherIdentity(String publisherId) {
        logger.info("[AUTH] 开始校验发布者身份 publisherId={}", publisherId);
        
        // 校验 publisherId 不为空
        if (publisherId == null || publisherId.trim().isEmpty()) {
            logger.error("[AUTH] publisherId 不能为空");
            throw new RuntimeException("发布者ID不能为空");
        }
        
        // 校验 publisherId 是合法 UUID
        try {
            UUID.fromString(publisherId);
        } catch (IllegalArgumentException e) {
            logger.error("[AUTH] publisherId 格式非法: publisherId={}", publisherId);
            throw new RuntimeException("发布者ID格式不正确");
        }
        
        // 查询用户角色
        String role = userRepository.findRoleByUserId(publisherId);
        if (role == null) {
            logger.error("[AUTH] 发布者不存在 publisherId={}", publisherId);
            throw new RuntimeException("发布者不存在");
        }
        
        logger.info("[AUTH] 发布者身份核验: publisherId={}, role={}", publisherId, role);

        boolean allowed = false;
        for (String allowedRole : ALLOWED_PUBLISHER_ROLES) {
            if (allowedRole.equalsIgnoreCase(role)) {
                allowed = true;
                break;
            }
        }
        if (!allowed) {
            logger.error("[AUTH] 发布者角色不合规 publisherId={}, role={}", publisherId, role);
            throw new RuntimeException("只有核验者或管理员可以发布任务");
        }
        logger.info("[AUTH] 发布者身份核验通过 publisherId={}, role={}", publisherId, role);
    }

    /**
     * 校验任务类型与poiId的关系
     */
    private void validateTaskTypeAndPoiId(String taskType, String poiId) {
        if (TaskType.CREATE_NEW.name().equals(taskType)) {
            if (poiId != null && !poiId.isEmpty()) {
                logger.error("[TASK] CREATE_NEW任务不应该有poiId");
                throw new RuntimeException("新建任务不应该指定POI ID");
            }
            logger.info("[TASK] CREATE_NEW任务校验通过，poiId为空");
        } else if (TaskType.UPDATE_EXISTING.name().equals(taskType)) {
            if (poiId == null || poiId.isEmpty()) {
                logger.error("[TASK] UPDATE_EXISTING任务必须有poiId");
                throw new RuntimeException("更新任务必须指定POI ID");
            }
            
            // 校验 poiId 格式
            try {
                UUID.fromString(poiId);
            } catch (IllegalArgumentException e) {
                logger.error("[TASK] poiId 格式非法: poiId={}", poiId);
                throw new RuntimeException("POI ID格式不正确");
            }
            
            logger.info("[DB] 开始校验POI存在性: poiId={}", poiId);
            String sql = "SELECT COUNT(*) FROM poi WHERE id = ?";
            try {
                UUID uuid = UUID.fromString(poiId);
                Integer count = jdbcTemplate.queryForObject(sql, Integer.class, uuid);
                if (count == null || count == 0) {
                    logger.error("[TASK] POI不存在 poiId={}", poiId);
                    throw new RuntimeException("指定的POI不存在");
                }
                logger.info("[DB] POI存在性校验通过: poiId={}", poiId);
            } catch (IllegalArgumentException e) {
                logger.error("[TASK] POI ID格式非法: poiId={}", poiId);
                throw new RuntimeException("POI ID格式不正确");
            }
        }
    }

    /**
     * 校验采集者列表
     */
    private void validateAssignees(List<String> assigneeIds) {
        if (assigneeIds == null || assigneeIds.isEmpty()) {
            logger.error("[TASK] 采集者列表不能为空");
            throw new RuntimeException("采集者列表不能为空");
        }
        for (String collectorId : assigneeIds) {
            // 校验 collectorId 格式
            if (collectorId == null || collectorId.trim().isEmpty()) {
                logger.error("[TASK] collectorId 不能为空");
                throw new RuntimeException("采集者ID不能为空");
            }
            try {
                UUID.fromString(collectorId);
            } catch (IllegalArgumentException e) {
                logger.error("[TASK] collectorId 格式非法: collectorId={}", collectorId);
                throw new RuntimeException("采集者ID格式不正确");
            }
            
            // 查询用户角色
            String role = userRepository.findRoleByUserId(collectorId);
            if (role == null) {
                logger.error("[TASK] 采集者不存在 collectorId={}", collectorId);
                throw new RuntimeException("采集者不存在: " + collectorId);
            }
            
            boolean allowed = false;
            for (String allowedRole : ALLOWED_ROLES) {
                if (allowedRole.equalsIgnoreCase(role)) {
                    allowed = true;
                    break;
                }
            }
            if (!allowed) {
                logger.error("[AUTH] 采集者角色不合规 collectorId={}, role={}", collectorId, role);
                throw new RuntimeException("用户角色不允许被分配任务: " + collectorId);
            }
        }
    }
}