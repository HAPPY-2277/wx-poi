package com.poi.service;

import com.poi.client.WeChatApiClient;
import com.poi.dto.WechatLoginResponse;
import com.poi.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * 认证服务
 * 处理登录/注册核心逻辑
 * 
 * 重要说明：
 * 1. 登录和注册职责分离：登录只负责检查用户是否存在并更新登录状态，
 *    注册必须通过单独接口完成，登录时不再自动注册。
 * 2. 当前版本为真实微信登录模式：
 *    - 前端只传微信小程序 wx.login() 获取的临时 code
 *    - 后端调用微信官方 jscode2session 接口获取 openid
 *    - 使用真实的 openid 作为用户标识
 * 3. 为什么必须由后端调用微信 API？
 *    - 安全考虑：appid 和 secret 是敏感信息，不能暴露给前端
 *    - 防止前端伪造 openid
 *    - session_key 是敏感信息，不应传给前端
 * 4. 为什么登录不自动注册？
 *    - 保持逻辑清晰，职责分离
 *    - 避免误操作导致的用户创建
 *    - 让前端明确控制注册流程
 * 5. 为什么注册单独调用？
 *    - 便于前端在注册前进行额外的用户信息收集
 *    - 提供更清晰的用户体验
 */
@Service
public class AuthService {

    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);
    private final UserRepository userRepository;
    private final WeChatApiClient weChatApiClient;

    public AuthService(UserRepository userRepository, WeChatApiClient weChatApiClient) {
        this.userRepository = userRepository;
        this.weChatApiClient = weChatApiClient;
    }

    /**
     * 登录
     * 只负责登录检查，用户不存在时返回提示，不自动注册
     * @param code 微信小程序 wx.login() 返回的临时 code
     * @return 登录结果
     */
    public WechatLoginResponse login(String code) {
        logger.info("[AUTH] 开始登录流程");
        
        // 1. 调用微信 API 获取 openid
        logger.info("[AUTH] 开始调用微信 API 获取 openid");
        String openid = weChatApiClient.getOpenid(code);
        logger.info("[AUTH] 获取到 openid: {}", maskSensitiveInfo(openid));

        WechatLoginResponse response = new WechatLoginResponse();

        // 2. 查询用户信息（包含 id、role、nickname）
        logger.info("[DB] 根据 openid 查询用户信息");
        java.util.Map<String, Object> userInfo = userRepository.findUserInfoByOpenid(openid);

        if (userInfo != null) {
            // 3. 用户存在，执行登录逻辑
            logger.info("[DB] 用户存在，更新登录状态");
            userRepository.updateLoginStatus(openid);
            
            // 获取用户信息（注意：id 在数据库中是 UUID 类型，需要使用 toString() 转换）
            Object idObj = userInfo.get("id");
            String userId = idObj != null ? idObj.toString() : null;
            String role = (String) userInfo.get("role");
            String nickname = (String) userInfo.get("nickname");
            
            // 设置响应（根据文档要求：登录成功时返回 userId、nickname、role）
            response.setIsNewUser(false);
            response.setLoginToken(generateMockToken(openid));
            response.setUserId(userId);
            response.setNickname(nickname);
            response.setRole(role);
            // avatar 暂未从微信获取，设为 null
            
            // 输出包含 role 和 nickname 的登录成功日志
            logger.info("[AUTH] 登录成功 userId={} role={} nickname={}", userId, role, nickname);
        } else {
            // 4. 用户不存在，返回需要注册的提示，不修改数据库
            response.setIsNewUser(true);
            response.setLoginToken(null);
            // 用户不存在时，其他字段不设置（保持默认 null）
            
            logger.info("[AUTH] 用户不存在，需要注册");
        }

        logger.info("[AUTH] 登录流程结束");
        return response;
    }

    /**
     * 注册
     * 单独的注册接口，创建新用户
     * @param code 微信小程序 wx.login() 返回的临时 code
     * @param nickname 用户昵称，最大12个字符
     * @param role 用户角色（collector/verifier）
     * @return 注册结果
     */
    public WechatLoginResponse register(String code, String nickname, String role) {
        logger.info("[AUTH] 开始注册流程");
        
        // 1. 调用微信 API 获取 openid
        logger.info("[AUTH] 开始调用微信 API 获取 openid");
        String openid = weChatApiClient.getOpenid(code);
        logger.info("[AUTH] 获取到 openid: {}", maskSensitiveInfo(openid));

        // 2. 检查用户是否已存在
        logger.info("[DB] 根据 openid 查询用户");
        boolean userExists = userRepository.existsByOpenid(openid);
        if (userExists) {
            logger.warn("[AUTH] 用户已存在，无法重复注册");
            throw new RuntimeException("注册失败：用户已存在，请直接登录");
        }

        // 3. 校验 nickname 长度（最大12个字符）
        logger.info("[AUTH] 校验 nickname: {}", nickname);
        if (nickname == null || nickname.trim().isEmpty()) {
            logger.warn("[AUTH] nickname 为空");
            throw new RuntimeException("参数错误：nickname不能为空");
        }
        if (nickname.length() > 12) {
            logger.warn("[AUTH] nickname 长度超过限制: {} > 12", nickname.length());
            throw new RuntimeException("昵称长度不能超过12个字符");
        }

        // 4. 校验 role 参数（当前真实角色：collector/verifier/admin）
        logger.info("[AUTH] 校验 role: {}", role);
        if (role == null || role.trim().isEmpty()) {
            logger.warn("[AUTH] role 为空");
            throw new RuntimeException("参数错误：role不能为空");
        }
        if (!"collector".equalsIgnoreCase(role) && !"verifier".equalsIgnoreCase(role) && !"admin".equalsIgnoreCase(role)) {
            logger.warn("[AUTH] role 参数错误: {}", role);
            throw new RuntimeException("参数错误：role必须是collector、verifier或admin");
        }
        role = role.toLowerCase(); // 统一转为小写

        // 5. 执行注册（注意：这里传入的是微信 API 返回的 openid，不是前端传来的 code）
        logger.info("[DB] 开始插入新用户: nickname={}, role={}", nickname, role);
        userRepository.registerUser(openid, nickname, role);
        logger.info("[DB] 注册用户成功");

        // 6. 查询刚创建的用户信息（获取userId）
        logger.info("[DB] 查询刚创建的用户信息");
        java.util.Map<String, Object> userInfo = userRepository.findUserInfoByOpenid(openid);
        Object idObj = userInfo.get("id");
        String userId = idObj != null ? idObj.toString() : null;

        // 7. 构建响应（根据文档要求：注册成功时返回完整信息）
        WechatLoginResponse response = new WechatLoginResponse();
        response.setIsNewUser(true);
        response.setLoginToken(generateMockToken(openid));
        response.setUserId(userId);
        response.setNickname(nickname);
        response.setRole(role);
        // avatar 暂未从微信获取，设为 null

        logger.info("[AUTH] 注册成功，userId={}, nickname={}, role={}", userId, nickname, role);
        logger.info("[AUTH] 注册流程结束");
        return response;
    }

    /**
     * 生成模拟 token
     * @param openid 用户 openid
     * @return 模拟 token
     * 注意：这是临时方案，未来可以替换成 JWT
     */
    private String generateMockToken(String openid) {
        String token = "mock-token-" + UUID.randomUUID().toString();
        logger.info("[AUTH] 生成 mock token: {}", maskSensitiveInfo(token));
        return token;
    }
    
    /**
     * 脱敏敏感信息
     * @param info 敏感信息
     * @return 脱敏后的信息
     */
    private String maskSensitiveInfo(String info) {
        if (info == null || info.length() <= 6) {
            return info;
        }
        return info.substring(0, 3) + "***" + info.substring(info.length() - 3);
    }
}