package com.poi.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * OpenAPI / Swagger 配置类
 *
 * 配置说明：
 * 1. Spring Boot 3 项目使用 springdoc-openapi-starter-webmvc-ui
 * 2. Swagger UI 访问地址：/swagger-ui.html
 * 3. OpenAPI JSON 访问地址：/v3/api-docs
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI poiApplicationOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("POI Application API")
                        .description("POI 任务管理与提交审核系统 API 文档\n\n" +
                                "## 核心业务流程\n" +
                                "1. 核验者发布任务（CREATE_NEW / UPDATE_EXISTING）\n" +
                                "2. 采集者领取任务并提交数据\n" +
                                "3. 核验者审核（通过 / 驳回）\n" +
                                "4. 审核通过后，poi 主表才会被更新\n\n" +
                                "## 身份核验\n" +
                                "- 发布任务：仅 verifier / admin\n" +
                                "- 提交数据：collector / verifier / admin\n" +
                                "- 审核：仅 verifier / admin")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("POI Team")
                                .email("poi@example.com"))
                        .license(new License()
                                .name("Apache 2.0")
                                .url("https://www.apache.org/licenses/LICENSE-2.0")))
                .servers(List.of(
                        new Server().url("http://localhost:8080").description("本地开发环境")
                ));
    }
}