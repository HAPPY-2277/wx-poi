package com.poi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 微信小程序配置类
 * 使用 @ConfigurationProperties 从 application.yml 读取配置
 */
@Component
@ConfigurationProperties(prefix = "wechat")
public class WeChatProperties {

    /**
     * 微信小程序 AppID
     * 从环境变量 WECHAT_MINIAPP_APPID 获取，默认为占位符
     */
    private String appid;

    /**
     * 微信小程序 AppSecret
     * 从环境变量 WECHAT_MINIAPP_SECRET 获取，默认为占位符
     */
    private String secret;

    /**
     * 开发环境 Mock 模式开关
     * true = 使用 Mock openid 进行登录（仅用于本机联调）
     * false = 使用真实微信 API（生产环境）
     */
    private boolean mockLogin = false;

    /**
     * 内部类：微信小程序配置
     */
    private Miniapp miniapp = new Miniapp();

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public boolean isMockLogin() {
        return mockLogin;
    }

    public void setMockLogin(boolean mockLogin) {
        this.mockLogin = mockLogin;
    }

    public Miniapp getMiniapp() {
        return miniapp;
    }

    public void setMiniapp(Miniapp miniapp) {
        this.miniapp = miniapp;
    }

    /**
     * 内部类：微信小程序详细配置
     */
    public static class Miniapp {
        private String appid;
        private String secret;

        public String getAppid() {
            return appid;
        }

        public void setAppid(String appid) {
            this.appid = appid;
        }

        public String getSecret() {
            return secret;
        }

        public void setSecret(String secret) {
            this.secret = secret;
        }
    }
}