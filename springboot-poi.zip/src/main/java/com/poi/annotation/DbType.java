package com.poi.annotation;

/**
 * 数据库类型枚举
 */
public enum DbType {
    UUID,
    STRING,
    INTEGER,
    DOUBLE,
    BOOLEAN
}
