package com.poi.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 类型安全注解
 * 用于标记需要类型检查和自动转换的字段
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface TypeSafe {
    
    /**
     * 目标数据库列类型
     */
    DbType value() default DbType.UUID;
    
    /**
     * 字段是否必需
     */
    boolean required() default true;
    
    /**
     * 描述信息（用于错误信息）
     */
    String description() default "";
}
