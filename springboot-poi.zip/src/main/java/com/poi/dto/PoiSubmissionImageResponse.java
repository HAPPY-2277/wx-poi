package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;

/**
 * 提交图片响应 DTO
 */
@Schema(description = "提交图片响应")
public class PoiSubmissionImageResponse {
    @Schema(description = "图片ID")
    private String id;

    @Schema(description = "提交ID")
    private String submissionId;

    @Schema(description = "图片URL")
    private String imageUrl;

    @Schema(description = "排序顺序")
    private Integer sortOrder;

    @Schema(description = "内容类型")
    private String contentType;

    @Schema(description = "创建时间")
    private ZonedDateTime createdAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSubmissionId() {
        return submissionId;
    }

    public void setSubmissionId(String submissionId) {
        this.submissionId = submissionId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
