package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * 图片上传 DTO
 * 使用 JSON + base64 编码传输图片
 */
@Schema(description = "图片上传请求 DTO")
public class ImageUploadDTO {

    @NotBlank(message = "文件名不能为空")
    @Schema(description = "文件名", example = "test.jpg", required = true)
    private String filename;

    @NotBlank(message = "内容类型不能为空")
    @Pattern(regexp = "^image/(jpeg|jpg|png|gif|bmp)$", message = "不支持的图片类型")
    @Schema(description = "图片内容类型", example = "image/jpeg", required = true)
    private String contentType;

    @NotBlank(message = "图片数据不能为空")
    @Schema(description = "Base64 编码的图片数据", example = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAAAAAAAD/...", required = true)
    private String base64Data;

    public ImageUploadDTO() {
    }

    public ImageUploadDTO(String filename, String contentType, String base64Data) {
        this.filename = filename;
        this.contentType = contentType;
        this.base64Data = base64Data;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getBase64Data() {
        return base64Data;
    }

    public void setBase64Data(String base64Data) {
        this.base64Data = base64Data;
    }
}
