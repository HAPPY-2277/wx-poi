package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 登录/注册响应
 * 用于统一返回登录或注册的结果
 */
@Schema(description = "登录/注册响应")
public class WechatLoginResponse {
    @Schema(description = "是否新用户")
    private Boolean isNewUser;
    @Schema(description = "登录令牌")
    private String loginToken;
    @Schema(description = "用户ID(UUID)")
    private String userId;
    @Schema(description = "用户昵称")
    private String nickname;
    @Schema(description = "用户角色(collector/verifier/admin)")
    private String role;
    @Schema(description = "头像URL(暂无，返回null)")
    private String avatar;

    public Boolean getIsNewUser() {
        return isNewUser;
    }

    public void setIsNewUser(Boolean isNewUser) {
        this.isNewUser = isNewUser;
    }

    public String getLoginToken() {
        return loginToken;
    }

    public void setLoginToken(String loginToken) {
        this.loginToken = loginToken;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
}