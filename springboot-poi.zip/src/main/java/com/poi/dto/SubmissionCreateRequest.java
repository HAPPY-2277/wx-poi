package com.poi.dto;

import com.poi.annotation.DbType;
import com.poi.annotation.TypeSafe;

/**
 * 提交创建请求 DTO
 */
public class SubmissionCreateRequest {
    
    @TypeSafe(value = DbType.UUID, description = "任务ID")
    private String taskId;
    
    @TypeSafe(value = DbType.UUID, description = "提交者ID")
    private String submitterId;
    
    private String name;
    private String category;
    private String description;
    private Double longitude;
    private Double latitude;
    private String address;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getSubmitterId() {
        return submitterId;
    }

    public void setSubmitterId(String submitterId) {
        this.submitterId = submitterId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
