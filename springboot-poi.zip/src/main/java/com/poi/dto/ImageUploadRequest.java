package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

/**
 * 批量图片上传请求 DTO
 */
@Schema(description = "批量图片上传请求")
public class ImageUploadRequest {

    @NotEmpty(message = "图片列表不能为空")
    @Valid
    @Schema(description = "图片列表", required = true)
    private List<ImageUploadDTO> images;

    public ImageUploadRequest() {
    }

    public ImageUploadRequest(List<ImageUploadDTO> images) {
        this.images = images;
    }

    public List<ImageUploadDTO> getImages() {
        return images;
    }

    public void setImages(List<ImageUploadDTO> images) {
        this.images = images;
    }
}
