package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 上传 POI 图片请求 DTO
 * 注意：暂时不实现上传逻辑，仅预留接口结构
 */
@Schema(description = "上传POI图片请求")
public class UploadPoiImageRequest {
    @Schema(description = "POI ID")
    private String poiId;

    @Schema(description = "图片URL（后续支持 multipart 上传）")
    private String imageUrl;

    @Schema(description = "排序顺序", example = "0")
    private Integer sortOrder = 0;

    public String getPoiId() {
        return poiId;
    }

    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }
}
