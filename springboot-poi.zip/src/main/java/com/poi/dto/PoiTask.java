package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;

/**
 * POI 任务 DTO
 * 对应数据库表 poi_task
 */
@Schema(description = "任务信息")
public class PoiTask {
    @Schema(description = "任务ID")
    private String id;

    @Schema(description = "发布者ID")
    private String publisherId;

    @Schema(description = "关联POI ID（UPDATE_EXISTING类型任务必填）")
    private String poiId;

    @Schema(description = "任务描述")
    private String description;

    @Schema(description = "任务状态：PENDING_COLLECTION/PENDING_REVIEW/COMPLETED")
    private String status;

    @Schema(description = "已分配采集者数量")
    private Integer assigneeCount;

    @Schema(description = "创建时间")
    private ZonedDateTime createdAt;

    @Schema(description = "更新时间")
    private ZonedDateTime updatedAt;

    @Schema(description = "任务类型：CREATE_NEW/UPDATE_EXISTING")
    private String taskType;

    @Schema(description = "目标名称")
    private String targetName;

    @Schema(description = "目标分类")
    private String targetCategory;

    @Schema(description = "目标经度")
    private Double targetLongitude;

    @Schema(description = "目标纬度")
    private Double targetLatitude;

    @Schema(description = "目标地址")
    private String targetAddress;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPublisherId() {
        return publisherId;
    }

    public void setPublisherId(String publisherId) {
        this.publisherId = publisherId;
    }

    public String getPoiId() {
        return poiId;
    }

    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getAssigneeCount() {
        return assigneeCount;
    }

    public void setAssigneeCount(Integer assigneeCount) {
        this.assigneeCount = assigneeCount;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public ZonedDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(ZonedDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
    }

    public String getTargetCategory() {
        return targetCategory;
    }

    public void setTargetCategory(String targetCategory) {
        this.targetCategory = targetCategory;
    }

    public Double getTargetLongitude() {
        return targetLongitude;
    }

    public void setTargetLongitude(Double targetLongitude) {
        this.targetLongitude = targetLongitude;
    }

    public Double getTargetLatitude() {
        return targetLatitude;
    }

    public void setTargetLatitude(Double targetLatitude) {
        this.targetLatitude = targetLatitude;
    }

    public String getTargetAddress() {
        return targetAddress;
    }

    public void setTargetAddress(String targetAddress) {
        this.targetAddress = targetAddress;
    }
}
