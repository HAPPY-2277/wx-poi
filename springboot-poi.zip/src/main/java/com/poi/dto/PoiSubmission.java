package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;
import java.util.List;

/**
 * POI 提交记录 DTO
 * 对应数据库表 poi_submission
 */
@Schema(description = "POI提交记录")
public class PoiSubmission {
    @Schema(description = "提交ID")
    private String id;

    @Schema(description = "关联的POI ID")
    private String poiId;

    @Schema(description = "提交者ID")
    private String submitterId;

    @Schema(description = "提交类型：CREATE/UPDATE")
    private String submissionType;

    @Schema(description = "POI名称")
    private String name;

    @Schema(description = "POI分类")
    private String category;

    @Schema(description = "POI描述")
    private String description;

    @Schema(description = "经度")
    private Double longitude;

    @Schema(description = "纬度")
    private Double latitude;

    @Schema(description = "地址")
    private String address;

    @Schema(description = "状态：PENDING_REVIEW/APPROVED/REJECTED")
    private String status;

    @Schema(description = "是否生效")
    private Boolean isActive;

    @Schema(description = "审核评论")
    private String reviewComment;

    @Schema(description = "审核者ID")
    private String reviewerId;

    @Schema(description = "审核时间")
    private ZonedDateTime reviewedAt;

    @Schema(description = "创建时间")
    private ZonedDateTime createdAt;

    @Schema(description = "更新时间")
    private ZonedDateTime updatedAt;

    @Schema(description = "关联任务ID")
    private String taskId;

    @Schema(description = "图片列表")
    private List<PoiSubmissionImageResponse> images;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPoiId() {
        return poiId;
    }

    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }

    public String getSubmitterId() {
        return submitterId;
    }

    public void setSubmitterId(String submitterId) {
        this.submitterId = submitterId;
    }

    public String getSubmissionType() {
        return submissionType;
    }

    public void setSubmissionType(String submissionType) {
        this.submissionType = submissionType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getReviewComment() {
        return reviewComment;
    }

    public void setReviewComment(String reviewComment) {
        this.reviewComment = reviewComment;
    }

    public String getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(String reviewerId) {
        this.reviewerId = reviewerId;
    }

    public ZonedDateTime getReviewedAt() {
        return reviewedAt;
    }

    public void setReviewedAt(ZonedDateTime reviewedAt) {
        this.reviewedAt = reviewedAt;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public ZonedDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(ZonedDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public List<PoiSubmissionImageResponse> getImages() {
        return images;
    }

    public void setImages(List<PoiSubmissionImageResponse> images) {
        this.images = images;
    }
}
