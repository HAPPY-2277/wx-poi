package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;
import java.util.List;

/**
 * POI 响应 DTO
 */
@Schema(description = "POI响应")
public class PoiResponse {
    @Schema(description = "POI ID")
    private String id;

    @Schema(description = "POI名称")
    private String name;

    @Schema(description = "POI分类")
    private String category;

    @Schema(description = "POI描述")
    private String description;

    @Schema(description = "经度")
    private Double longitude;

    @Schema(description = "纬度")
    private Double latitude;

    @Schema(description = "地址")
    private String address;

    @Schema(description = "采集者ID")
    private String collectorId;

    @Schema(description = "创建时间")
    private ZonedDateTime createdAt;

    @Schema(description = "更新时间")
    private ZonedDateTime updatedAt;

    @Schema(description = "图片列表")
    private List<PoiImageResponse> images;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCollectorId() {
        return collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public ZonedDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(ZonedDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<PoiImageResponse> getImages() {
        return images;
    }

    public void setImages(List<PoiImageResponse> images) {
        this.images = images;
    }
}
