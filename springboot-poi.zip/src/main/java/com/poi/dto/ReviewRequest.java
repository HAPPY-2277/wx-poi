package com.poi.dto;

import com.poi.annotation.DbType;
import com.poi.annotation.TypeSafe;

/**
 * 审核请求 DTO
 */
public class ReviewRequest {
    
    @TypeSafe(value = DbType.UUID, description = "审核者ID")
    private String reviewerId;
    
    private String reviewComment;

    public String getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(String reviewerId) {
        this.reviewerId = reviewerId;
    }

    public String getReviewComment() {
        return reviewComment;
    }

    public void setReviewComment(String reviewComment) {
        this.reviewComment = reviewComment;
    }
}
