package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 上传提交图片请求 DTO
 * 注意：暂时不实现上传逻辑，仅预留接口结构
 */
@Schema(description = "上传提交图片请求")
public class UploadSubmissionImageRequest {
    @Schema(description = "提交ID")
    private String submissionId;

    @Schema(description = "图片URL（后续支持 multipart 上传）")
    private String imageUrl;

    @Schema(description = "排序顺序", example = "0")
    private Integer sortOrder = 0;

    public String getSubmissionId() {
        return submissionId;
    }

    public void setSubmissionId(String submissionId) {
        this.submissionId = submissionId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }
}
