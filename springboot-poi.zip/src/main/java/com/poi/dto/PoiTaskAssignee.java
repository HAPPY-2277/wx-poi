package com.poi.dto;

import java.time.ZonedDateTime;

/**
 * POI 任务分配关系 DTO
 * 对应数据库表 poi_task_assignee
 */
public class PoiTaskAssignee {
    private String id;
    private String taskId;
    private String collectorId;
    private ZonedDateTime createdAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getCollectorId() {
        return collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }
}