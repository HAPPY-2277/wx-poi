package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;

/**
 * POI 图片响应 DTO
 */
@Schema(description = "POI图片响应")
public class PoiImageResponse {
    @Schema(description = "图片ID")
    private String id;

    @Schema(description = "POI ID")
    private String poiId;

    @Schema(description = "图片URL")
    private String imageUrl;

    @Schema(description = "排序顺序")
    private Integer sortOrder;

    @Schema(description = "内容类型")
    private String contentType;

    @Schema(description = "创建时间")
    private ZonedDateTime createdAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPoiId() {
        return poiId;
    }

    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
