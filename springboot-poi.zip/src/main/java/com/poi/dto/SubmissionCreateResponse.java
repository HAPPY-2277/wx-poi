package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 提交创建响应 DTO
 */
@Schema(description = "提交创建响应")
public class SubmissionCreateResponse {

    @Schema(description = "提交ID", example = "uuid")
    private String submissionId;

    public SubmissionCreateResponse() {
    }

    public SubmissionCreateResponse(String submissionId) {
        this.submissionId = submissionId;
    }

    public String getSubmissionId() {
        return submissionId;
    }

    public void setSubmissionId(String submissionId) {
        this.submissionId = submissionId;
    }
}
