package com.poi.dto;

import com.poi.annotation.DbType;
import com.poi.annotation.TypeSafe;

/**
 * POI 上传请求 DTO
 */
public class PoiRequest {
    private String name;
    private String category;
    private String description;
    private Double longitude;
    private Double latitude;
    private String address;
    
    @TypeSafe(value = DbType.UUID, description = "采集者ID")
    private String collectorId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCollectorId() {
        return collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }
}
