package com.poi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;

@Schema(description = "用户信息响应")
public class UserResponse {
    @Schema(description = "用户ID(UUID)")
    private String id;
    @Schema(description = "用户昵称")
    private String nickname;
    @Schema(description = "用户角色(collector/verifier/admin)")
    private String role;
    @Schema(description = "是否在线")
    private boolean isOnline;
    @Schema(description = "最后登录时间")
    private ZonedDateTime lastLoginAt;
    @Schema(description = "创建时间")
    private ZonedDateTime createdAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isOnline() {
        return isOnline;
    }

    public void setOnline(boolean online) {
        isOnline = online;
    }

    public ZonedDateTime getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(ZonedDateTime lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }
}