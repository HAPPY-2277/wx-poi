package com.poi.enums;

/**
 * 提交状态枚举
 */
public enum SubmissionStatus {
    PENDING_REVIEW, APPROVED, REJECTED, DISPUTED
}