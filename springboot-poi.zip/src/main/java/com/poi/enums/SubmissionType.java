package com.poi.enums;

/**
 * 提交类型枚举
 */
public enum SubmissionType {
    CREATE, UPDATE
}