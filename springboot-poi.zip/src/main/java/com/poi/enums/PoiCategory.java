package com.poi.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * POI 分类枚举
 * 统一使用这5个固定分类值
 */
public enum PoiCategory {
    RESIDENTIAL("住宅"),
    COMMERCIAL("商业"),
    PUBLIC_SERVICE("公共服务"),
    TRANSPORTATION("交通"),
    RECREATION("休闲娱乐");

    private final String displayName;

    PoiCategory(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * 获取所有允许的分类值
     */
    public static List<String> getAllValues() {
        return Arrays.stream(values())
                .map(Enum::name)
                .collect(Collectors.toList());
    }

    /**
     * 校验分类值是否有效
     */
    public static boolean isValid(String category) {
        if (category == null) {
            return false;
        }
        try {
            valueOf(category.toUpperCase());
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
