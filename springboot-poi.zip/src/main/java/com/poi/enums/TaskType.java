package com.poi.enums;

/**
 * 任务类型枚举
 */
public enum TaskType {
    CREATE_NEW, UPDATE_EXISTING
}