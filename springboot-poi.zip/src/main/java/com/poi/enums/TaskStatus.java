package com.poi.enums;

/**
 * 任务状态枚举
 */
public enum TaskStatus {
    PENDING_COLLECTION, PENDING_REVIEW, COMPLETED
}