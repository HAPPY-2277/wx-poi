package com.poi.controller;

import com.poi.common.ApiResponse;
import com.poi.dto.WechatLoginRequest;
import com.poi.dto.WechatLoginResponse;
import com.poi.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 认证控制器
 * 处理登录/注册请求
 * 
 * 重要说明：
 * 1. 登录和注册职责分离：登录只负责检查，注册需要单独调用接口
 * 2. Controller 层只负责接收请求、参数校验、调用服务层、返回响应
 * 3. 不应该在 Controller 中写复杂业务逻辑，业务逻辑都放在 Service 层
 * 4. 当前版本为真实微信登录模式：
 *    - 前端只传微信小程序 wx.login() 获取的临时 code
 *    - 后端调用微信官方 jscode2session 接口获取真实 openid
 *    - 使用真实的 openid 作为用户标识
 */
@Tag(name = "用户认证", description = "登录、注册接口")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * 登录接口
     * 只负责登录检查，用户不存在时返回提示，不自动注册
     * @param request 登录请求，包含 code
     * @return 登录结果
     */
    @Operation(summary = "微信登录", description = "用户通过微信小程序code登录，用户不存在时提示先注册")
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "登录成功或需要注册", 
            content = @Content(
                mediaType = "application/json", 
                schema = @Schema(implementation = WechatLoginResponse.class)
            )
        )
    })
    @PostMapping("/login")
    public ApiResponse<WechatLoginResponse> login(@RequestBody WechatLoginRequest request) {
        // 获取 HTTP 请求信息
        HttpServletRequest httpRequest = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String clientIP = getClientIP(httpRequest);
        
        logger.info("[HTTP] 收到请求 POST /api/auth/login from {}", clientIP);
        logger.info("[HTTP] 请求体: {}", maskSensitiveInfoInRequest(request));
        logger.info("[AUTH] 开始处理登录");
        
        try {
            // 检查 code 是否为空
            if (request.getCode() == null || request.getCode().isEmpty()) {
                logger.warn("[AUTH] 登录请求缺少 code");
                return ApiResponse.error(400, "登录失败：code 不能为空");
            }
            
            // 脱敏打印 code
            String maskedCode = maskSensitiveInfo(request.getCode());
            logger.info("[AUTH] 收到 code: {}", maskedCode);
            
            // 调用服务层处理登录逻辑
            WechatLoginResponse response = authService.login(request.getCode());
            
            // 判断是否需要注册
            if (Boolean.TRUE.equals(response.getIsNewUser())) {
                logger.info("[AUTH] 用户不存在，需要注册");
                logger.info("[RETURN] 数据: isNewUser={}", response.getIsNewUser());
                return ApiResponse.success(response, "用户不存在，请先注册");
            }
            
            logger.info("[AUTH] 登录成功");
            logger.info("[RETURN] 数据: isNewUser={}, userId={}, nickname={}, role={}", 
                response.getIsNewUser(), response.getUserId(), response.getNickname(), response.getRole());
            return ApiResponse.success(response, "登录成功");
        } catch (Exception e) {
            logger.error("[AUTH] 登录失败: {}", e.getMessage());
            return ApiResponse.error(500, "登录失败：" + e.getMessage());
        }
    }

    /**
     * 注册接口
     * 单独的注册接口，创建新用户
     * @param request 注册请求，包含 code 和 nickname
     * @return 注册结果
     */
    @Operation(summary = "微信注册", description = "新用户通过微信小程序code和昵称进行注册")
    @PostMapping("/register")
    public ApiResponse<WechatLoginResponse> register(@RequestBody WechatLoginRequest request) {
        // 获取 HTTP 请求信息
        HttpServletRequest httpRequest = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String clientIP = getClientIP(httpRequest);
        
        logger.info("[HTTP] 收到请求 POST /api/auth/register from {}", clientIP);
        logger.info("[HTTP] 请求体: {}", maskSensitiveInfoInRequest(request));
        logger.info("[AUTH] 开始处理注册");
        
        try {
            // 检查 code 是否为空
            if (request.getCode() == null || request.getCode().isEmpty()) {
                logger.warn("[AUTH] 注册请求缺少 code");
                return ApiResponse.error(400, "注册失败：code 不能为空");
            }
            
            // 脱敏打印 code
            String maskedCode = maskSensitiveInfo(request.getCode());
            logger.info("[AUTH] 收到 code: {}, nickname: {}", maskedCode, request.getNickname());
            
            // 调用服务层处理注册逻辑（传入 nickname 和 role）
            WechatLoginResponse response = authService.register(request.getCode(), request.getNickname(), request.getRole());
            
            logger.info("[AUTH] 注册成功");
            logger.info("[RETURN] 数据: isNewUser={}, userId={}, nickname={}, role={}", 
                response.getIsNewUser(), response.getUserId(), response.getNickname(), response.getRole());
            return ApiResponse.success(response, "注册成功");
        } catch (Exception e) {
            logger.error("[AUTH] 注册失败: {}", e.getMessage());
            return ApiResponse.error(400, "注册失败：" + e.getMessage());
        }
    }
    
    /**
     * 获取客户端 IP 地址
     * @param request HTTP 请求
     * @return 客户端 IP
     */
    private String getClientIP(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty()) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty()) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty()) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }
    
    /**
     * 脱敏敏感信息
     * @param info 敏感信息
     * @return 脱敏后的信息
     */
    private String maskSensitiveInfo(String info) {
        if (info == null || info.length() <= 6) {
            return info;
        }
        return info.substring(0, 3) + "***" + info.substring(info.length() - 3);
    }
    
    /**
     * 脱敏请求体中的敏感信息
     * @param request 登录请求对象
     * @return 脱敏后的请求体 JSON 字符串
     */
    private String maskSensitiveInfoInRequest(WechatLoginRequest request) {
        try {
            // 直接构建 JSON 字符串，避免使用复杂的 ObjectMapper
            StringBuilder sb = new StringBuilder();
            sb.append("{");
            
            // 脱敏 code
            if (request.getCode() != null) {
                sb.append("\"code\":\"").append(maskSensitiveInfo(request.getCode())).append("\"");
            }
            if (request.getNickname() != null) {
                if (sb.length() > 1) sb.append(", ");
                sb.append("\"nickname\":\"").append(request.getNickname()).append("\"");
            }
            if (request.getRole() != null) {
                if (sb.length() > 1) sb.append(", ");
                sb.append("\"role\":\"").append(request.getRole()).append("\"");
            }
            
            sb.append("}");
            return sb.toString();
        } catch (Exception e) {
            logger.error("[HTTP] 构建请求体 JSON 失败: {}", e.getMessage());
            return "{}";
        }
    }
}