package com.poi.controller;

import com.poi.common.ApiResponse;
import com.poi.dto.PoiRequest;
import com.poi.dto.PoiResponse;
import com.poi.service.PoiService;
import com.poi.util.TypeSafeUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * POI 控制器
 * 处理 POI 相关 HTTP 请求
 */
@Tag(name = "POI管理", description = "POI查询接口")
@RestController
@RequestMapping("/api/poi")
public class PoiController {

    private static final Logger logger = LoggerFactory.getLogger(PoiController.class);
    private final PoiService poiService;

    public PoiController(PoiService poiService) {
        this.poiService = poiService;
    }

    /**
     * 上传 POI（已禁用）
     * POST /api/poi
     * 已禁用，创建POI必须通过任务流程
     */
    @Operation(summary = "上传POI", description = "已禁用，请通过任务流程创建POI")
    @PostMapping
    public ApiResponse<Void> uploadPoi(@RequestBody PoiRequest request) {
        logger.info("[HTTP] 收到请求 POST /api/poi");
        
        try {
            // 类型安全检查
            TypeSafeUtils.validateAndConvert(request, "POST /api/poi");
            
            poiService.uploadPoi(request);
            return ApiResponse.success(null, "POI 上传成功");
        } catch (Exception e) {
            logger.error("[POI] 上传失败: {}", e.getMessage());
            return ApiResponse.error(400, "POI 上传失败：" + e.getMessage());
        }
    }

    /**
     * 获取 POI 列表
     * GET /api/poi
     */
    @Operation(summary = "获取POI列表", description = "获取所有POI列表")
    @GetMapping
    public ApiResponse<List<PoiResponse>> getPoiList() {
        logger.info("[HTTP] 收到请求 GET /api/poi");
        
        try {
            List<PoiResponse> poiList = poiService.getPoiList();
            return ApiResponse.success(poiList, "获取成功");
        } catch (Exception e) {
            logger.error("[POI] 获取列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取 POI 列表失败：" + e.getMessage());
        }
    }

    /**
     * 获取 POI 详情
     * GET /api/poi/{id}
     */
    @Operation(summary = "获取POI详情", description = "根据POI ID获取详细信息")
    @GetMapping("/{id}")
    public ApiResponse<PoiResponse> getPoiById(@Parameter(description = "POI ID") @PathVariable String id) {
        logger.info("[HTTP] 收到请求 GET /api/poi/{}", id);
        
        try {
            PoiResponse poi = poiService.getPoiById(id);
            return ApiResponse.success(poi, "获取成功");
        } catch (Exception e) {
            logger.error("[POI] 获取详情失败: {}", e.getMessage());
            return ApiResponse.error(404, e.getMessage());
        }
    }

    /**
     * 获取指定采集者的 POI 列表
     * GET /api/poi/collector/{collectorId}
     * 返回该采集者提交的所有 POI
     */
    @Operation(summary = "获取采集者POI", description = "获取指定采集者提交的所有POI")
    @GetMapping("/collector/{collectorId}")
    public ApiResponse<List<PoiResponse>> getPoiListByCollectorId(@Parameter(description = "采集者ID") @PathVariable String collectorId) {
        logger.info("[HTTP] 收到请求 GET /api/poi/collector/{}", collectorId);
        
        try {
            List<PoiResponse> poiList = poiService.getPoiListByCollectorId(collectorId);
            return ApiResponse.success(poiList, "获取成功");
        } catch (Exception e) {
            logger.error("[POI] 获取采集者 POI 列表失败: {}", e.getMessage());
            return ApiResponse.error(404, e.getMessage());
        }
    }
}