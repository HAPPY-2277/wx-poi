package com.poi.controller;

import com.poi.common.ApiResponse;
import com.poi.dto.ImageUploadDTO;
import com.poi.dto.ImageUploadRequest;
import com.poi.dto.PoiImageResponse;
import com.poi.dto.PoiSubmissionImageResponse;
import com.poi.repository.PoiImageRepository;
import com.poi.repository.PoiSubmissionImageRepository;
import com.poi.service.FileStorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 图片上传控制器
 * 提供图片上传基础能力（使用 JSON + Base64 编码传输）
 */
@Tag(name = "图片上传", description = "图片上传接口（JSON + Base64 编码）")
@RestController
@RequestMapping("/api")
public class ImageController {

    private static final Logger logger = LoggerFactory.getLogger(ImageController.class);

    private final FileStorageService fileStorageService;
    private final PoiImageRepository poiImageRepository;
    private final PoiSubmissionImageRepository submissionImageRepository;

    // 支持的图片类型
    private static final List<String> ALLOWED_CONTENT_TYPES = List.of(
            "image/jpeg", "image/jpg", "image/png", "image/gif", "image/bmp"
    );

    public ImageController(FileStorageService fileStorageService,
                         PoiImageRepository poiImageRepository,
                         PoiSubmissionImageRepository submissionImageRepository) {
        this.fileStorageService = fileStorageService;
        this.poiImageRepository = poiImageRepository;
        this.submissionImageRepository = submissionImageRepository;
    }

    /**
     * 上传 Submission 图片（JSON + Base64）
     * POST /api/submission/{submissionId}/images
     */
    @Operation(summary = "上传提交图片", 
               description = "使用 JSON + Base64 编码上传图片到指定提交",
               requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                   description = "图片上传请求体",
                   content = @Content(
                       mediaType = "application/json",
                       schema = @Schema(implementation = ImageUploadRequest.class)
                   )
               ))
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200",
            description = "上传成功",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = PoiSubmissionImageResponse.class)
            )
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "400",
            description = "上传失败（参数校验失败或文件处理错误）",
            content = @Content
        )
    })
    @PostMapping(value = "/submission/{submissionId}/images", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<List<PoiSubmissionImageResponse>> uploadSubmissionImages(
            @Parameter(description = "提交ID", required = true) @PathVariable String submissionId,
            @Valid @RequestBody ImageUploadRequest request) {

        logger.info("[UPLOAD] ==================== 开始上传 Submission 图片 ====================");
        logger.info("[UPLOAD] 请求路径: POST /api/submission/{}/images", submissionId);
        logger.info("[UPLOAD] 接收到图片数量: {}", request.getImages().size());

        // 校验 submissionId
        validateId(submissionId, "submissionId");

        List<PoiSubmissionImageResponse> results = new ArrayList<>();
        int sortOrder = 0;

        for (ImageUploadDTO imageDTO : request.getImages()) {
            logger.info("[UPLOAD] 处理图片 #{}, filename={}, contentType={}", 
                    sortOrder + 1, imageDTO.getFilename(), imageDTO.getContentType());

            // 校验图片数据
            validateImageDTO(imageDTO);

            try {
                // 保存文件（Base64 方式）
                logger.info("[FILE] 开始保存文件: filename={}", imageDTO.getFilename());
                String imageUrl = fileStorageService.saveSubmissionImageFromBase64(
                        imageDTO.getFilename(), 
                        imageDTO.getBase64Data()
                );
                logger.info("[FILE] 文件保存成功, imageUrl={}", imageUrl);

                // 插入数据库记录
                logger.info("[DB] 开始插入图片记录: submissionId={}, imageUrl={}", submissionId, imageUrl);
                String imageId = submissionImageRepository.insert(submissionId, imageUrl, sortOrder);
                logger.info("[DB] 图片记录插入成功, imageId={}", imageId);

                // 构建响应
                PoiSubmissionImageResponse response = new PoiSubmissionImageResponse();
                response.setId(imageId);
                response.setSubmissionId(submissionId);
                response.setImageUrl(imageUrl);
                response.setSortOrder(sortOrder);
                response.setContentType(imageDTO.getContentType());
                results.add(response);

                sortOrder++;
                logger.info("[IMAGE] Submission 图片上传成功, imageId={}", imageId);

            } catch (Exception e) {
                logger.error("[IMAGE] Submission 图片上传失败: {}", e.getMessage());
                logger.error("[IMAGE] 异常类型: {}", e.getClass().getName());
                logger.error("[IMAGE] 完整堆栈:", e);
                return ApiResponse.error(400, "图片上传失败：" + e.getMessage());
            }
        }

        logger.info("[UPLOAD] ==================== 上传完成, 成功上传 {} 张图片 ====================", results.size());
        return ApiResponse.success(results, "图片上传成功");
    }

    /**
     * 上传 POI 图片（JSON + Base64）
     * POST /api/poi/{poiId}/images
     */
    @Operation(summary = "上传POI图片", 
               description = "使用 JSON + Base64 编码上传图片到指定POI",
               requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                   description = "图片上传请求体",
                   content = @Content(
                       mediaType = "application/json",
                       schema = @Schema(implementation = ImageUploadRequest.class)
                   )
               ))
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200",
            description = "上传成功",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = PoiImageResponse.class)
            )
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "400",
            description = "上传失败（参数校验失败或文件处理错误）",
            content = @Content
        )
    })
    @PostMapping(value = "/poi/{poiId}/images", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<List<PoiImageResponse>> uploadPoiImages(
            @Parameter(description = "POI ID", required = true) @PathVariable String poiId,
            @Valid @RequestBody ImageUploadRequest request) {

        logger.info("[UPLOAD] ==================== 开始上传 POI 图片 ====================");
        logger.info("[UPLOAD] 请求路径: POST /api/poi/{}/images", poiId);
        logger.info("[UPLOAD] 接收到图片数量: {}", request.getImages().size());

        // 校验 poiId
        validateId(poiId, "poiId");

        List<PoiImageResponse> results = new ArrayList<>();
        int sortOrder = 0;

        for (ImageUploadDTO imageDTO : request.getImages()) {
            logger.info("[UPLOAD] 处理图片 #{}, filename={}, contentType={}", 
                    sortOrder + 1, imageDTO.getFilename(), imageDTO.getContentType());

            // 校验图片数据
            validateImageDTO(imageDTO);

            try {
                // 保存文件（Base64 方式）
                logger.info("[FILE] 开始保存文件: filename={}", imageDTO.getFilename());
                String imageUrl = fileStorageService.savePoiImageFromBase64(
                        imageDTO.getFilename(), 
                        imageDTO.getBase64Data()
                );
                logger.info("[FILE] 文件保存成功, imageUrl={}", imageUrl);

                // 插入数据库记录
                logger.info("[DB] 开始插入图片记录: poiId={}, imageUrl={}", poiId, imageUrl);
                String imageId = poiImageRepository.insert(poiId, imageUrl, sortOrder);
                logger.info("[DB] 图片记录插入成功, imageId={}", imageId);

                // 构建响应
                PoiImageResponse response = new PoiImageResponse();
                response.setId(imageId);
                response.setPoiId(poiId);
                response.setImageUrl(imageUrl);
                response.setSortOrder(sortOrder);
                response.setContentType(imageDTO.getContentType());
                results.add(response);

                sortOrder++;
                logger.info("[IMAGE] POI 图片上传成功, imageId={}", imageId);

            } catch (Exception e) {
                logger.error("[IMAGE] POI 图片上传失败: {}", e.getMessage());
                logger.error("[IMAGE] 异常类型: {}", e.getClass().getName());
                logger.error("[IMAGE] 完整堆栈:", e);
                return ApiResponse.error(400, "图片上传失败：" + e.getMessage());
            }
        }

        logger.info("[UPLOAD] ==================== 上传完成, 成功上传 {} 张图片 ====================", results.size());
        return ApiResponse.success(results, "图片上传成功");
    }

    /**
     * 查询 Submission 图片列表
     * GET /api/submission/{submissionId}/images
     */
    @Operation(summary = "查询提交图片列表", description = "获取指定提交的所有图片")
    @GetMapping("/submission/{submissionId}/images")
    public ApiResponse<List<PoiSubmissionImageResponse>> getSubmissionImages(
            @Parameter(description = "提交ID") @PathVariable String submissionId) {

        logger.info("[IMAGE] 查询提交图片列表: submissionId={}", submissionId);
        List<PoiSubmissionImageResponse> images = submissionImageRepository.findBySubmissionId(submissionId);
        logger.info("[IMAGE] 查询成功, 数量: {}", images.size());
        return ApiResponse.success(images, "获取成功");
    }

    /**
     * 查询 POI 图片列表
     * GET /api/poi/{poiId}/images
     */
    @Operation(summary = "查询POI图片列表", description = "获取指定POI的所有图片")
    @GetMapping("/poi/{poiId}/images")
    public ApiResponse<List<PoiImageResponse>> getPoiImages(
            @Parameter(description = "POI ID") @PathVariable String poiId) {

        logger.info("[IMAGE] 查询POI图片列表: poiId={}", poiId);
        List<PoiImageResponse> images = poiImageRepository.findByPoiId(poiId);
        logger.info("[IMAGE] 查询成功, 数量: {}", images.size());
        return ApiResponse.success(images, "获取成功");
    }

    /**
     * 删除 Submission 图片
     * DELETE /api/submission/images/{imageId}
     */
    @Operation(summary = "删除提交图片", description = "根据图片ID删除提交图片")
    @DeleteMapping("/submission/images/{imageId}")
    public ApiResponse<Void> deleteSubmissionImage(
            @Parameter(description = "图片ID") @PathVariable String imageId) {

        logger.info("[IMAGE] 删除提交图片: imageId={}", imageId);
        submissionImageRepository.deleteById(imageId);
        logger.info("[IMAGE] 删除成功: imageId={}", imageId);
        return ApiResponse.success(null, "删除成功");
    }

    /**
     * 删除 POI 图片
     * DELETE /api/poi/images/{imageId}
     */
    @Operation(summary = "删除POI图片", description = "根据图片ID删除POI图片")
    @DeleteMapping("/poi/images/{imageId}")
    public ApiResponse<Void> deletePoiImage(
            @Parameter(description = "图片ID") @PathVariable String imageId) {

        logger.info("[IMAGE] 删除POI图片: imageId={}", imageId);
        poiImageRepository.deleteById(imageId);
        logger.info("[IMAGE] 删除成功: imageId={}", imageId);
        return ApiResponse.success(null, "删除成功");
    }

    /**
     * 校验 ID 参数
     */
    private void validateId(String id, String paramName) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException(paramName + " 不能为空");
        }
        // 简单的 UUID 格式校验
        if (!id.matches("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")) {
            throw new IllegalArgumentException(paramName + " 格式不正确，应为 UUID 格式");
        }
    }

    /**
     * 校验图片上传 DTO
     */
    private void validateImageDTO(ImageUploadDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("图片数据不能为空");
        }

        // 校验文件名
        if (dto.getFilename() == null || dto.getFilename().trim().isEmpty()) {
            throw new IllegalArgumentException("文件名不能为空");
        }

        // 校验内容类型
        if (dto.getContentType() == null || dto.getContentType().trim().isEmpty()) {
            throw new IllegalArgumentException("内容类型不能为空");
        }
        if (!ALLOWED_CONTENT_TYPES.contains(dto.getContentType().toLowerCase())) {
            throw new IllegalArgumentException("不支持的图片类型: " + dto.getContentType() + 
                    "，支持的类型: " + String.join(", ", ALLOWED_CONTENT_TYPES));
        }

        // 校验 Base64 数据
        if (dto.getBase64Data() == null || dto.getBase64Data().trim().isEmpty()) {
            throw new IllegalArgumentException("图片数据不能为空");
        }
    }
}
