package com.poi.controller;

import com.poi.common.ApiResponse;
import com.poi.dto.PoiSubmission;
import com.poi.dto.SubmissionCreateRequest;
import com.poi.dto.SubmissionCreateResponse;
import com.poi.dto.ReviewRequest;
import com.poi.service.SubmissionService;
import com.poi.util.TypeSafeUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 提交控制器
 * 处理提交审核相关 HTTP 请求
 */
@Tag(name = "提交审核", description = "数据提交、审核接口")
@RestController
@RequestMapping("/api/submission")
public class SubmissionController {

    private static final Logger logger = LoggerFactory.getLogger(SubmissionController.class);
    private final SubmissionService submissionService;

    public SubmissionController(SubmissionService submissionService) {
        this.submissionService = submissionService;
    }

    /**
     * 采集者提交数据
     * POST /api/submission
     */
    @Operation(summary = "提交数据", description = "采集者提交POI数据")
    @PostMapping
    public ApiResponse<SubmissionCreateResponse> createSubmission(@RequestBody SubmissionCreateRequest request) {
        logger.info("[HTTP] 收到请求 POST /api/submission, category={}", request.getCategory());
        
        try {
            // 类型安全检查
            TypeSafeUtils.validateAndConvert(request, "POST /api/submission");
            
            String submissionId = submissionService.createSubmission(
                    request.getTaskId(),
                    request.getSubmitterId(),
                    request.getName(),
                    request.getCategory(),
                    request.getDescription(),
                    request.getLongitude(),
                    request.getLatitude(),
                    request.getAddress()
            );
            
            SubmissionCreateResponse response = new SubmissionCreateResponse(submissionId);
            return ApiResponse.success(response, "提交成功");
        } catch (Exception e) {
            logger.error("[SUBMISSION] 创建提交失败: {}", e.getMessage());
            return ApiResponse.error(400, "提交失败：" + e.getMessage());
        }
    }

    /**
     * 获取提交详情
     * GET /api/submission/{id}
     */
    @Operation(summary = "获取提交详情", description = "根据提交ID获取提交详细信息")
    @GetMapping("/{id}")
    public ApiResponse<PoiSubmission> getSubmissionById(@Parameter(description = "提交ID") @PathVariable String id) {
        logger.info("[HTTP] 收到请求 GET /api/submission/{}", id);
        
        try {
            PoiSubmission submission = submissionService.getSubmissionById(id);
            return ApiResponse.success(submission, "获取成功");
        } catch (Exception e) {
            logger.error("[SUBMISSION] 获取提交详情失败: {}", e.getMessage());
            return ApiResponse.error(404, e.getMessage());
        }
    }

    /**
     * 获取任务的提交列表
     * GET /api/submission/task/{taskId}
     */
    @Operation(summary = "获取任务提交列表", description = "获取指定任务的所有提交记录")
    @GetMapping("/task/{taskId}")
    public ApiResponse<List<PoiSubmission>> getSubmissionsByTaskId(@Parameter(description = "任务ID") @PathVariable String taskId) {
        logger.info("[HTTP] 收到请求 GET /api/submission/task/{}", taskId);
        
        try {
            List<PoiSubmission> submissions = submissionService.getSubmissionsByTaskId(taskId);
            return ApiResponse.success(submissions, "获取成功");
        } catch (Exception e) {
            logger.error("[SUBMISSION] 获取任务提交列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取失败：" + e.getMessage());
        }
    }

    /**
     * 获取提交者的提交记录（我的提交）
     * GET /api/submission/submitter/{submitterId}
     */
    @Operation(summary = "获取提交者提交记录", description = "获取指定提交者的所有提交记录")
    @GetMapping("/submitter/{submitterId}")
    public ApiResponse<List<PoiSubmission>> getSubmissionsBySubmitterId(@Parameter(description = "提交者ID") @PathVariable String submitterId) {
        logger.info("[HTTP] 收到请求 GET /api/submission/submitter/{}", submitterId);
        
        try {
            List<PoiSubmission> submissions = submissionService.getSubmissionsBySubmitterId(submitterId);
            return ApiResponse.success(submissions, "获取成功");
        } catch (Exception e) {
            logger.error("[SUBMISSION] 获取提交者提交列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取失败：" + e.getMessage());
        }
    }

    /**
     * 获取待审核提交列表
     * GET /api/submission/pending-review
     */
    @Operation(summary = "获取待审核提交", description = "获取所有状态为PENDING_REVIEW的提交")
    @GetMapping("/pending-review")
    public ApiResponse<List<PoiSubmission>> getPendingReviewSubmissions() {
        logger.info("[HTTP] 收到请求 GET /api/submission/pending-review");
        
        try {
            List<PoiSubmission> submissions = submissionService.getPendingReviewSubmissions();
            return ApiResponse.success(submissions, "获取成功");
        } catch (Exception e) {
            logger.error("[SUBMISSION] 获取待审核提交列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取失败：" + e.getMessage());
        }
    }

    /**
     * 审核通过
     * POST /api/submission/{id}/approve
     */
    @Operation(summary = "审核通过", description = "核验者审核通过提交，自动创建或更新POI")
    @PostMapping("/{id}/approve")
    public ApiResponse<Void> approveSubmission(@Parameter(description = "提交ID") @PathVariable String id, @RequestBody ReviewRequest request) {
        logger.info("[HTTP] 收到请求 POST /api/submission/{}/approve", id);
        
        try {
            // 类型安全检查
            TypeSafeUtils.validateAndConvert(request, "POST /api/submission/" + id + "/approve");
            
            submissionService.approveSubmission(id, request.getReviewerId(), request.getReviewComment());
            return ApiResponse.success(null, "审核通过");
        } catch (Exception e) {
            logger.error("[REVIEW] 审核通过失败: {}", e.getMessage());
            return ApiResponse.error(400, "审核失败：" + e.getMessage());
        }
    }

    /**
     * 审核驳回
     * POST /api/submission/{id}/reject
     */
    @Operation(summary = "审核驳回", description = "核验者驳回提交")
    @PostMapping("/{id}/reject")
    public ApiResponse<Void> rejectSubmission(@Parameter(description = "提交ID") @PathVariable String id, @RequestBody ReviewRequest request) {
        logger.info("[HTTP] 收到请求 POST /api/submission/{}/reject", id);
        
        try {
            // 类型安全检查
            TypeSafeUtils.validateAndConvert(request, "POST /api/submission/" + id + "/reject");
            
            submissionService.rejectSubmission(id, request.getReviewerId(), request.getReviewComment());
            return ApiResponse.success(null, "审核驳回");
        } catch (Exception e) {
            logger.error("[REVIEW] 审核驳回失败: {}", e.getMessage());
            return ApiResponse.error(400, "审核失败：" + e.getMessage());
        }
    }

    /**
     * 驳回后重新提交
     * POST /api/submission/resubmit
     */
    @Operation(summary = "重新提交", description = "驳回后重新提交数据")
    @PostMapping("/resubmit")
    public ApiResponse<Void> resubmitAfterReject(@RequestBody SubmissionCreateRequest request) {
        logger.info("[HTTP] 收到请求 POST /api/submission/resubmit, category={}", request.getCategory());
        
        try {
            // 类型安全检查
            TypeSafeUtils.validateAndConvert(request, "POST /api/submission/resubmit");
            
            submissionService.resubmitAfterReject(
                    request.getTaskId(),
                    request.getSubmitterId(),
                    request.getName(),
                    request.getCategory(),
                    request.getDescription(),
                    request.getLongitude(),
                    request.getLatitude(),
                    request.getAddress()
            );
            return ApiResponse.success(null, "重新提交成功");
        } catch (Exception e) {
            logger.error("[SUBMISSION] 重新提交失败: {}", e.getMessage());
            return ApiResponse.error(400, "重新提交失败：" + e.getMessage());
        }
    }

}