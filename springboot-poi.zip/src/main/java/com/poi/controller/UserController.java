package com.poi.controller;

import com.poi.common.ApiResponse;
import com.poi.dto.UserResponse;
import com.poi.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 用户控制器
 * 处理用户相关的HTTP请求
 */
@Tag(name = "用户管理", description = "用户查询接口")
@RestController
@RequestMapping("/api/users")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * 获取所有用户列表（返回完整基础信息）
     * GET /api/users/ids
     * 
     * @return 用户列表，包含id、nickname、role、isOnline、lastLoginAt、createdAt
     */
    @Operation(summary = "获取所有用户列表", description = "查询所有用户的完整基础信息")
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "获取成功", 
            content = @Content(
                mediaType = "application/json", 
                array = @ArraySchema(schema = @Schema(implementation = UserResponse.class))
            )
        )
    })
    @GetMapping("/ids")
    public ApiResponse<List<UserResponse>> getAllUsers() {
        logger.info("[HTTP] 收到获取所有用户列表请求");
        
        try {
            List<UserResponse> users = userRepository.findAllUsersDto();
            logger.info("[HTTP] 返回用户列表成功，数量={}", users.size());
            logger.info("[RETURN] 数据: {}", users);
            return ApiResponse.success(users, "获取用户列表成功");
        } catch (Exception e) {
            logger.error("[HTTP] 获取用户列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取用户列表失败：" + e.getMessage());
        }
    }

    /**
     * 获取所有采集者列表（返回完整基础信息）
     * GET /api/users/collector-ids
     * 
     * @return 采集者列表，包含id、nickname、role、isOnline、lastLoginAt、createdAt
     */
    @Operation(summary = "获取采集者列表", description = "查询所有role=collector的用户")
    @GetMapping("/collector-ids")
    public ApiResponse<List<UserResponse>> getCollectors() {
        logger.info("[HTTP] 收到获取collector用户列表请求");
        
        try {
            List<UserResponse> collectors = userRepository.findCollectorsDto();
            logger.info("[HTTP] 返回collector用户列表成功，数量={}", collectors.size());
            logger.info("[RETURN] 数据: {}", collectors);
            return ApiResponse.success(collectors, "获取采集者列表成功");
        } catch (Exception e) {
            logger.error("[HTTP] 获取采集者列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取采集者列表失败：" + e.getMessage());
        }
    }

    /**
     * 获取所有核验者列表（返回完整基础信息）
     * GET /api/users/verifier-ids
     * 
     * @return 核验者列表，包含id、nickname、role、isOnline、lastLoginAt、createdAt
     */
    @Operation(summary = "获取核验者列表", description = "查询所有role=verifier的用户")
    @GetMapping("/verifier-ids")
    public ApiResponse<List<UserResponse>> getVerifiers() {
        logger.info("[HTTP] 收到获取verifier用户列表请求");
        
        try {
            List<UserResponse> verifiers = userRepository.findVerifiersDto();
            logger.info("[HTTP] 返回verifier用户列表成功，数量={}", verifiers.size());
            logger.info("[RETURN] 数据: {}", verifiers);
            return ApiResponse.success(verifiers, "获取核验者列表成功");
        } catch (Exception e) {
            logger.error("[HTTP] 获取核验者列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取核验者列表失败：" + e.getMessage());
        }
    }
}