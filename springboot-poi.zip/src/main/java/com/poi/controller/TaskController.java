package com.poi.controller;

import com.poi.common.ApiResponse;
import com.poi.dto.PoiTask;
import com.poi.dto.TaskCreateRequest;
import com.poi.service.TaskService;
import com.poi.util.TypeSafeUtils;
import com.poi.util.UuidUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 任务控制器
 * 处理任务相关 HTTP 请求
 */
@Tag(name = "任务管理", description = "任务发布、查询接口")
@RestController
@RequestMapping("/api/task")
public class TaskController {

    private static final Logger logger = LoggerFactory.getLogger(TaskController.class);
    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    /**
     * 发布任务
     * POST /api/task
     */
    @Operation(summary = "发布任务", description = "核验者或管理员发布新任务")
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "任务发布成功",
            content = @Content(mediaType = "application/json")
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "400", 
            description = "发布失败",
            content = @Content(mediaType = "application/json")
        )
    })
    @PostMapping
    public ApiResponse<Void> createTask(@RequestBody TaskCreateRequest request) {
        logger.info("[HTTP] 收到请求 POST /api/task, targetCategory={}", request.getTargetCategory());

        try {
            // 类型安全检查
            TypeSafeUtils.validateAndConvert(request, "POST /api/task");
            
            // 额外验证 assigneeIds 列表
            if (request.getAssigneeIds() != null && !request.getAssigneeIds().isEmpty()) {
                TypeSafeUtils.validateUuidList(request.getAssigneeIds(), "assigneeIds", "POST /api/task");
            }
            
            taskService.createTask(
                    request.getPublisherId(),
                    request.getTaskType(),
                    request.getPoiId(),
                    request.getDescription(),
                    request.getTargetName(),
                    request.getTargetCategory(),
                    request.getTargetLongitude(),
                    request.getTargetLatitude(),
                    request.getTargetAddress(),
                    request.getAssigneeIds()
            );
            return ApiResponse.success(null, "任务发布成功");
        } catch (Exception e) {
            logger.error("[TASK] 发布任务失败: {}", e.getMessage());
            return ApiResponse.error(400, "任务发布失败: " + e.getMessage());
        }
    }

    /**
     * 获取任务详情
     * GET /api/task/{id}
     */
    @Operation(summary = "获取任务详情", description = "根据任务ID获取任务详细信息")
    @GetMapping("/{id}")
    public ApiResponse<PoiTask> getTaskById(@Parameter(description = "任务ID") @PathVariable String id) {
        logger.info("[HTTP] 收到请求 GET /api/task/{}", id);
        
        try {
            PoiTask task = taskService.getTaskById(id);
            return ApiResponse.success(task, "获取成功");
        } catch (Exception e) {
            logger.error("[TASK] 获取任务详情失败: {}", e.getMessage());
            return ApiResponse.error(404, e.getMessage());
        }
    }

    /**
     * 获取发布者的任务列表
     * GET /api/task/publisher/{publisherId}
     */
    @Operation(summary = "获取发布者任务列表", description = "获取指定发布者发布的所有任务")
    @GetMapping("/publisher/{publisherId}")
    public ApiResponse<List<PoiTask>> getTasksByPublisherId(@Parameter(description = "发布者ID") @PathVariable String publisherId) {
        logger.info("[HTTP] 收到请求 GET /api/task/publisher/{}", publisherId);
        
        try {
            List<PoiTask> tasks = taskService.getTasksByPublisherId(publisherId);
            return ApiResponse.success(tasks, "获取成功");
        } catch (Exception e) {
            logger.error("[TASK] 获取发布者任务列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取失败：" + e.getMessage());
        }
    }

    /**
     * 获取采集者的任务列表（我的任务）
     * GET /api/task/collector/{collectorId}
     */
    @Operation(summary = "获取采集者任务列表", description = "获取指定采集者分配到的所有任务")
    @GetMapping("/collector/{collectorId}")
    public ApiResponse<List<PoiTask>> getTasksByCollectorId(@Parameter(description = "采集者ID") @PathVariable String collectorId) {
        logger.info("[HTTP] 收到请求 GET /api/task/collector/{}", collectorId);
        
        try {
            // 记录参数信息
            logger.info("[TASK] 参数校验开始 collectorId={}", collectorId);
            
            // 类型安全检查
            if (!UuidUtil.isValidUuid(collectorId)) {
                logger.warn("[TASK] collectorId 格式非法: {}", collectorId);
                return ApiResponse.error(400, "collectorId 格式不正确");
            }
            logger.info("[TASK] 参数校验通过 collectorId={}", collectorId);
            
            // 调用Service层
            logger.info("[TASK] 调用 TaskService.getTasksByCollectorId()");
            List<PoiTask> tasks = taskService.getTasksByCollectorId(collectorId);
            
            // 记录返回结果
            logger.info("[RETURN] 获取采集者任务成功 collectorId={}, 任务数量={}", collectorId, tasks.size());
            return ApiResponse.success(tasks, "获取成功");
        } catch (Exception e) {
            logger.error("[TASK] 获取采集者任务列表失败 collectorId={}, 错误: {}", collectorId, e.getMessage());
            return ApiResponse.error(500, "获取失败：" + e.getMessage());
        }
    }

    /**
     * 获取待审核任务列表
     * GET /api/task/pending-review
     */
    @Operation(summary = "获取待审核任务", description = "获取所有状态为PENDING_REVIEW的任务")
    @GetMapping("/pending-review")
    public ApiResponse<List<PoiTask>> getPendingReviewTasks() {
        logger.info("[HTTP] 收到请求 GET /api/task/pending-review");
        
        try {
            List<PoiTask> tasks = taskService.getPendingReviewTasks();
            return ApiResponse.success(tasks, "获取成功");
        } catch (Exception e) {
            logger.error("[TASK] 获取待审核任务列表失败: {}", e.getMessage());
            return ApiResponse.error(500, "获取失败：" + e.getMessage());
        }
    }

}