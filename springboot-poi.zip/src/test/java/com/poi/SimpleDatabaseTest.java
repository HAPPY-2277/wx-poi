package com.poi;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SimpleDatabaseTest {

    @Test
    void testDatabaseConnection() {
        // 配置数据源
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl("jdbc:postgresql://localhost:5432/poi_db");
        dataSource.setUsername("postgres");
        dataSource.setPassword("s06010200");

        // 创建 JdbcTemplate
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        // 1. 验证数据库连接
        assertNotNull(jdbcTemplate, "JdbcTemplate 创建失败，数据库连接可能有问题");
        System.out.println("✅ 数据库连接成功");

        // 2. 验证 users 表是否存在
        String checkTableSql = "SELECT table_name FROM information_schema.tables WHERE table_name = 'users'";
        List<Map<String, Object>> tables = jdbcTemplate.queryForList(checkTableSql);
        assertTrue(tables.size() > 0, "users 表不存在");
        System.out.println("✅ users 表存在");

        // 3. 插入测试数据
        String testOpenId = "test_openid_" + UUID.randomUUID().toString();
        String insertSql = "INSERT INTO users (wechat_openid, role, is_online) VALUES (?, CAST(? AS user_role), ?)";
        int rowsAffected = jdbcTemplate.update(insertSql, testOpenId, "collector", true);
        assertTrue(rowsAffected > 0, "插入测试数据失败");
        System.out.println("✅ 插入测试数据成功");

        // 4. 查询并输出刚刚插入的数据
        String selectSql = "SELECT * FROM users WHERE wechat_openid = ?";
        List<Map<String, Object>> users = jdbcTemplate.queryForList(selectSql, testOpenId);
        assertTrue(users.size() > 0, "查询测试数据失败");
        System.out.println("✅ 查询测试数据成功");
        System.out.println("查询结果:");
        for (Map<String, Object> user : users) {
            System.out.println(user);
        }

        // 5. 验证查询结果
        Map<String, Object> user = users.get(0);
        assertNotNull(user, "查询结果为空");
        assertTrue(testOpenId.equals(user.get("wechat_openid")), "查询结果中的 wechat_openid 与插入的不一致");

        // 6. 删除测试数据
        String deleteSql = "DELETE FROM users WHERE wechat_openid = ?";
        int deleteRowsAffected = jdbcTemplate.update(deleteSql, testOpenId);
        if (deleteRowsAffected > 0) {
            System.out.println("✅ 测试数据已删除");
        }
    }
}