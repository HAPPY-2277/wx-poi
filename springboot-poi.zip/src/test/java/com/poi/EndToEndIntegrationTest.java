package com.poi;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.poi.dto.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.TestPropertySource;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 全流程集成测试
 * 测试完整业务闭环：注册 → 登录 → 查询用户 → 发布任务 → 查询任务 → 提交 → 审核 → 生成POI → 查询POI
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:application.yml")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EndToEndIntegrationTest {

    private static final Logger logger = LoggerFactory.getLogger(EndToEndIntegrationTest.class);

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    // 测试数据存储
    private static String verifierId;
    private static String collectorId;
    private static String taskId;
    private static String submissionId;
    private static String poiId;
    private static String verifierLoginToken;
    private static String collectorLoginToken;

    // 测试结果记录
    private static final List<String> successfulSteps = new ArrayList<>();
    private static final List<String> failedSteps = new ArrayList<>();
    private static final Map<String, String> extractedUuids = new HashMap<>();

    private String getBaseUrl() {
        return "http://localhost:" + port;
    }

    private <T> ResponseEntity<String> sendRequest(HttpMethod method, String url, Object requestBody) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

            HttpEntity<Object> entity;
            if (requestBody != null) {
                entity = new HttpEntity<>(requestBody, headers);
            } else {
                entity = new HttpEntity<>(headers);
            }

            String fullUrl = getBaseUrl() + url;
            logger.info("[HTTP] {} {}", method, fullUrl);
            if (requestBody != null) {
                logger.info("[HTTP] 请求体: {}", objectMapper.writeValueAsString(requestBody));
            }

            ResponseEntity<String> response = restTemplate.exchange(fullUrl, method, entity, String.class);

            logger.info("[HTTP] 状态码: {}", response.getStatusCode());
            logger.info("[HTTP] 响应: {}", response.getBody());

            return response;
        } catch (Exception e) {
            logger.error("[TEST] 请求失败: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    private JsonNode parseResponse(String responseBody) throws Exception {
        return objectMapper.readTree(responseBody);
    }

    @Test
    @Order(1)
    void test1_RegisterVerifier() {
        logger.info("[TEST] ===== 步骤1: 注册核验者 =====");
        try {
            WechatLoginRequest request = new WechatLoginRequest();
            request.setCode("verifier001");
            request.setNickname("测试核验者");
            request.setRole("verifier");

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/auth/register", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            JsonNode data = json.get("data");
            verifierId = data.get("userId").asText();
            verifierLoginToken = data.get("loginToken").asText();

            logger.info("[AUTH] 核验者注册成功");
            logger.info("[AUTH] userId: {}", verifierId);
            logger.info("[AUTH] nickname: {}", data.get("nickname").asText());
            logger.info("[AUTH] role: {}", data.get("role").asText());

            extractedUuids.put("verifierId", verifierId);
            successfulSteps.add("1. 注册核验者");

        } catch (Exception e) {
            logger.error("[TEST] 步骤1失败: {}", e.getMessage(), e);
            failedSteps.add("1. 注册核验者 - " + e.getMessage());
            fail("步骤1失败: " + e.getMessage());
        }
    }

    @Test
    @Order(2)
    void test2_RegisterCollector() {
        logger.info("[TEST] ===== 步骤2: 注册采集者 =====");
        try {
            WechatLoginRequest request = new WechatLoginRequest();
            request.setCode("collector001");
            request.setNickname("测试采集者");
            request.setRole("collector");

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/auth/register", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            JsonNode data = json.get("data");
            collectorId = data.get("userId").asText();
            collectorLoginToken = data.get("loginToken").asText();

            logger.info("[AUTH] 采集者注册成功");
            logger.info("[AUTH] userId: {}", collectorId);
            logger.info("[AUTH] nickname: {}", data.get("nickname").asText());
            logger.info("[AUTH] role: {}", data.get("role").asText());

            extractedUuids.put("collectorId", collectorId);
            successfulSteps.add("2. 注册采集者");

        } catch (Exception e) {
            logger.error("[TEST] 步骤2失败: {}", e.getMessage(), e);
            failedSteps.add("2. 注册采集者 - " + e.getMessage());
            fail("步骤2失败: " + e.getMessage());
        }
    }

    @Test
    @Order(3)
    void test3_LoginVerifier() {
        logger.info("[TEST] ===== 步骤3: 核验者登录 =====");
        try {
            WechatLoginRequest request = new WechatLoginRequest();
            request.setCode("verifier001");

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/auth/login", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            JsonNode data = json.get("data");
            assertFalse(data.get("isNewUser").asBoolean());
            assertEquals(verifierId, data.get("userId").asText());
            assertEquals("测试核验者", data.get("nickname").asText());
            assertEquals("verifier", data.get("role").asText());
            assertNotNull(data.get("loginToken").asText());

            logger.info("[AUTH] 核验者登录成功");
            logger.info("[AUTH] role: {}", data.get("role").asText());
            logger.info("[AUTH] nickname: {}", data.get("nickname").asText());
            logger.info("[AUTH] loginToken: {}", data.get("loginToken").asText());

            successfulSteps.add("3. 核验者登录");

        } catch (Exception e) {
            logger.error("[TEST] 步骤3失败: {}", e.getMessage(), e);
            failedSteps.add("3. 核验者登录 - " + e.getMessage());
            fail("步骤3失败: " + e.getMessage());
        }
    }

    @Test
    @Order(4)
    void test4_LoginCollector() {
        logger.info("[TEST] ===== 步骤4: 采集者登录 =====");
        try {
            WechatLoginRequest request = new WechatLoginRequest();
            request.setCode("collector001");

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/auth/login", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            JsonNode data = json.get("data");
            assertFalse(data.get("isNewUser").asBoolean());
            assertEquals(collectorId, data.get("userId").asText());
            assertEquals("测试采集者", data.get("nickname").asText());
            assertEquals("collector", data.get("role").asText());
            assertNotNull(data.get("loginToken").asText());

            logger.info("[AUTH] 采集者登录成功");
            logger.info("[AUTH] role: {}", data.get("role").asText());
            logger.info("[AUTH] nickname: {}", data.get("nickname").asText());

            successfulSteps.add("4. 采集者登录");

        } catch (Exception e) {
            logger.error("[TEST] 步骤4失败: {}", e.getMessage(), e);
            failedSteps.add("4. 采集者登录 - " + e.getMessage());
            fail("步骤4失败: " + e.getMessage());
        }
    }

    @Test
    @Order(5)
    void test5_QueryUsers() {
        logger.info("[TEST] ===== 步骤5: 查询用户列表 =====");
        try {
            // 查询所有用户
            ResponseEntity<String> response1 = sendRequest(HttpMethod.GET, "/api/users/ids", null);
            assertEquals(HttpStatus.OK, response1.getStatusCode());
            JsonNode json1 = parseResponse(response1.getBody());
            assertEquals(0, json1.get("code").asInt());
            assertTrue(json1.get("data").isArray());
            assertTrue(json1.get("data").size() >= 2);
            logger.info("[USER] 查询所有用户成功，数量: {}", json1.get("data").size());

            // 查询采集者列表
            ResponseEntity<String> response2 = sendRequest(HttpMethod.GET, "/api/users/collector-ids", null);
            assertEquals(HttpStatus.OK, response2.getStatusCode());
            JsonNode json2 = parseResponse(response2.getBody());
            assertEquals(0, json2.get("code").asInt());
            assertTrue(json2.get("data").isArray());
            assertTrue(json2.get("data").size() >= 1);
            logger.info("[USER] 查询采集者成功，数量: {}", json2.get("data").size());

            // 查询核验者列表
            ResponseEntity<String> response3 = sendRequest(HttpMethod.GET, "/api/users/verifier-ids", null);
            assertEquals(HttpStatus.OK, response3.getStatusCode());
            JsonNode json3 = parseResponse(response3.getBody());
            assertEquals(0, json3.get("code").asInt());
            assertTrue(json3.get("data").isArray());
            assertTrue(json3.get("data").size() >= 1);
            logger.info("[USER] 查询核验者成功，数量: {}", json3.get("data").size());

            successfulSteps.add("5. 查询用户列表");

        } catch (Exception e) {
            logger.error("[TEST] 步骤5失败: {}", e.getMessage(), e);
            failedSteps.add("5. 查询用户列表 - " + e.getMessage());
            fail("步骤5失败: " + e.getMessage());
        }
    }

    @Test
    @Order(6)
    void test6_CreateTask() {
        logger.info("[TEST] ===== 步骤6: 核验者发布任务 =====");
        try {
            TaskCreateRequest request = new TaskCreateRequest();
            request.setPublisherId(verifierId);
            request.setTaskType("CREATE_NEW");
            request.setDescription("测试新建POI任务");
            request.setTargetName("测试餐厅");
            request.setTargetCategory("RESTAURANT");
            request.setTargetLongitude(116.397428);
            request.setTargetLatitude(39.90923);
            request.setTargetAddress("北京市朝阳区");
            request.setAssigneeIds(Collections.singletonList(collectorId));

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/task", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            // 查询发布者的任务列表获取taskId
            ResponseEntity<String> taskListResponse = sendRequest(HttpMethod.GET, "/api/task/publisher/" + verifierId, null);
            JsonNode taskListJson = parseResponse(taskListResponse.getBody());
            assertEquals(0, taskListJson.get("code").asInt());
            assertTrue(taskListJson.get("data").isArray());
            assertTrue(taskListJson.get("data").size() >= 1);

            taskId = taskListJson.get("data").get(0).get("id").asText();
            logger.info("[TASK] 任务发布成功，taskId: {}", taskId);
            logger.info("[TASK] 任务类型: {}", taskListJson.get("data").get(0).get("taskType").asText());
            logger.info("[TASK] 任务分类: {}", taskListJson.get("data").get(0).get("targetCategory").asText());

            // 验证assignee创建
            logger.info("[TASK] assigneeIds已设置: {}", request.getAssigneeIds());

            extractedUuids.put("taskId", taskId);
            successfulSteps.add("6. 核验者发布任务");

        } catch (Exception e) {
            logger.error("[TEST] 步骤6失败: {}", e.getMessage(), e);
            failedSteps.add("6. 核验者发布任务 - " + e.getMessage());
            fail("步骤6失败: " + e.getMessage());
        }
    }

    @Test
    @Order(7)
    void test7_QueryCollectorTasks() {
        logger.info("[TEST] ===== 步骤7: 采集者查询任务 =====");
        try {
            ResponseEntity<String> response = sendRequest(HttpMethod.GET, "/api/task/collector/" + collectorId, null);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());
            assertTrue(json.get("data").isArray());
            assertTrue(json.get("data").size() >= 1);

            boolean found = false;
            for (JsonNode task : json.get("data")) {
                if (task.get("id").asText().equals(taskId)) {
                    found = true;
                    assertEquals("CREATE_NEW", task.get("taskType").asText());
                    assertEquals("RESTAURANT", task.get("targetCategory").asText());
                    break;
                }
            }
            assertTrue(found, "未找到刚才发布的任务");

            logger.info("[TASK] 采集者查询任务成功");
            logger.info("[TASK] 任务数量: {}", json.get("data").size());

            successfulSteps.add("7. 采集者查询任务");

        } catch (Exception e) {
            logger.error("[TEST] 步骤7失败: {}", e.getMessage(), e);
            failedSteps.add("7. 采集者查询任务 - " + e.getMessage());
            fail("步骤7失败: " + e.getMessage());
        }
    }

    @Test
    @Order(8)
    void test8_CreateSubmission() {
        logger.info("[TEST] ===== 步骤8: 采集者提交数据 =====");
        try {
            SubmissionCreateRequest request = new SubmissionCreateRequest();
            request.setTaskId(taskId);
            request.setSubmitterId(collectorId);
            request.setName("测试餐厅提交");
            request.setCategory("RESTAURANT");
            request.setDescription("这是一个测试提交");
            request.setLongitude(116.397428);
            request.setLatitude(39.90923);
            request.setAddress("北京市朝阳区");

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/submission", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            // 查询任务的提交列表获取submissionId
            ResponseEntity<String> submissionListResponse = sendRequest(HttpMethod.GET, "/api/submission/task/" + taskId, null);
            JsonNode submissionListJson = parseResponse(submissionListResponse.getBody());
            assertEquals(0, submissionListJson.get("code").asInt());
            assertTrue(submissionListJson.get("data").isArray());
            assertTrue(submissionListJson.get("data").size() >= 1);

            submissionId = submissionListJson.get("data").get(0).get("id").asText();
            logger.info("[SUBMISSION] 提交成功，submissionId: {}", submissionId);
            logger.info("[SUBMISSION] 提交状态: {}", submissionListJson.get("data").get(0).get("status").asText());

            extractedUuids.put("submissionId", submissionId);
            successfulSteps.add("8. 采集者提交数据");

        } catch (Exception e) {
            logger.error("[TEST] 步骤8失败: {}", e.getMessage(), e);
            failedSteps.add("8. 采集者提交数据 - " + e.getMessage());
            fail("步骤8失败: " + e.getMessage());
        }
    }

    @Test
    @Order(9)
    void test9_ApproveSubmission() {
        logger.info("[TEST] ===== 步骤9: 核验者审核通过 =====");
        try {
            ReviewRequest request = new ReviewRequest();
            request.setReviewerId(verifierId);
            request.setReviewComment("审核通过，数据正确");

            ResponseEntity<String> response = sendRequest(HttpMethod.POST, "/api/submission/" + submissionId + "/approve", request);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            JsonNode json = parseResponse(response.getBody());
            assertEquals(0, json.get("code").asInt());

            // 检查提交状态更新
            ResponseEntity<String> submissionResponse = sendRequest(HttpMethod.GET, "/api/submission/" + submissionId, null);
            JsonNode submissionJson = parseResponse(submissionResponse.getBody());
            assertEquals(0, submissionJson.get("code").asInt());
            assertEquals("APPROVED", submissionJson.get("data").get("status").asText());
            logger.info("[REVIEW] 提交审核状态已更新为: APPROVED");

            // 检查任务状态更新
            ResponseEntity<String> taskResponse = sendRequest(HttpMethod.GET, "/api/task/" + taskId, null);
            JsonNode taskJson = parseResponse(taskResponse.getBody());
            assertEquals(0, taskJson.get("code").asInt());
            logger.info("[TASK] 任务状态: {}", taskJson.get("data").get("status").asText());

            // 查询POI列表获取poiId
            ResponseEntity<String> poiListResponse = sendRequest(HttpMethod.GET, "/api/poi", null);
            JsonNode poiListJson = parseResponse(poiListResponse.getBody());
            assertEquals(0, poiListJson.get("code").asInt());
            assertTrue(poiListJson.get("data").isArray());
            assertTrue(poiListJson.get("data").size() >= 1);

            poiId = poiListJson.get("data").get(0).get("id").asText();
            logger.info("[POI] POI已创建，poiId: {}", poiId);

            extractedUuids.put("poiId", poiId);
            successfulSteps.add("9. 核验者审核通过");

        } catch (Exception e) {
            logger.error("[TEST] 步骤9失败: {}", e.getMessage(), e);
            failedSteps.add("9. 核验者审核通过 - " + e.getMessage());
            fail("步骤9失败: " + e.getMessage());
        }
    }

    @Test
    @Order(10)
    void test10_QueryPoi() {
        logger.info("[TEST] ===== 步骤10: 查询POI =====");
        try {
            // 查询POI列表
            ResponseEntity<String> response1 = sendRequest(HttpMethod.GET, "/api/poi", null);
            assertEquals(HttpStatus.OK, response1.getStatusCode());
            JsonNode json1 = parseResponse(response1.getBody());
            assertEquals(0, json1.get("code").asInt());
            assertTrue(json1.get("data").isArray());
            assertTrue(json1.get("data").size() >= 1);
            logger.info("[POI] 查询POI列表成功，数量: {}", json1.get("data").size());

            // 查询POI详情
            ResponseEntity<String> response2 = sendRequest(HttpMethod.GET, "/api/poi/" + poiId, null);
            assertEquals(HttpStatus.OK, response2.getStatusCode());
            JsonNode json2 = parseResponse(response2.getBody());
            assertEquals(0, json2.get("code").asInt());
            assertEquals(poiId, json2.get("data").get("id").asText());
            assertEquals("测试餐厅提交", json2.get("data").get("name").asText());
            assertEquals("RESTAURANT", json2.get("data").get("category").asText());
            logger.info("[POI] 查询POI详情成功");
            logger.info("[POI] POI名称: {}", json2.get("data").get("name").asText());
            logger.info("[POI] POI分类: {}", json2.get("data").get("category").asText());

            successfulSteps.add("10. 查询POI");

        } catch (Exception e) {
            logger.error("[TEST] 步骤10失败: {}", e.getMessage(), e);
            failedSteps.add("10. 查询POI - " + e.getMessage());
            fail("步骤10失败: " + e.getMessage());
        }
    }

    @Test
    @Order(11)
    void test11_GenerateReport() {
        logger.info("[TEST] ===== 生成测试报告 =====");
        logger.info("========================================");
        logger.info("          全流程集成测试报告            ");
        logger.info("========================================");
        logger.info("");
        logger.info("[成功步骤] ({}/{})", successfulSteps.size(), 10);
        for (String step : successfulSteps) {
            logger.info("  ✓ {}", step);
        }
        logger.info("");
        logger.info("[失败步骤] ({}/{})", failedSteps.size(), 10);
        if (failedSteps.isEmpty()) {
            logger.info("  无");
        } else {
            for (String step : failedSteps) {
                logger.info("  ✗ {}", step);
            }
        }
        logger.info("");
        logger.info("[提取的UUID]");
        for (Map.Entry<String, String> entry : extractedUuids.entrySet()) {
            logger.info("  {}: {}", entry.getKey(), entry.getValue());
        }
        logger.info("");
        logger.info("[业务闭环验证]");
        if (failedSteps.isEmpty()) {
            logger.info("  ✓ 完整业务闭环已验证通过！");
            logger.info("  注册 → 登录 → 查询用户 → 发布任务 → 查询任务 → 提交 → 审核 → 生成POI → 查询POI");
        } else {
            logger.info("  ✗ 业务闭环断裂于: {}", failedSteps.get(0));
        }
        logger.info("");
        logger.info("[总结]");
        logger.info("  总步骤: 10");
        logger.info("  成功: {}", successfulSteps.size());
        logger.info("  失败: {}", failedSteps.size());
        logger.info("  状态: {}", failedSteps.isEmpty() ? "PASS" : "FAIL");
        logger.info("========================================");

        // 最终断言确保所有步骤都成功
        assertTrue(failedSteps.isEmpty(), "有测试步骤失败: " + failedSteps);
    }
}
